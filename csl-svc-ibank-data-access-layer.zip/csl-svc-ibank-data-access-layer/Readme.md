#Data Access Layer 
 Common service for persistence layer.
  
##Standard to follow
1. Follow MailServiceFactory for factory class implementation
2. Don't use SsCSLUser, use CSLRequestContext instead to get header information
2. Change the name space in the hbm when you copy from NFS code base.
    Change http://hibernate.sourceforge.net/hibernate-mapping-3.0.dtd to http://www.hibernate.org/dtd/hibernate-mapping-3.0.dtd