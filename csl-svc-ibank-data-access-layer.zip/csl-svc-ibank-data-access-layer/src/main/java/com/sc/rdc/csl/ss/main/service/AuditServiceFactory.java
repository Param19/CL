package com.sc.rdc.csl.ss.main.service;

import java.util.HashMap;
import java.util.Map;
import com.sc.rdc.csl.ss.common.helper.Constants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sc.rdc.csl.ss.common.service.IAuditService;

import lombok.extern.slf4j.Slf4j;

@Component()
@Slf4j
@ConfigurationProperties("audit")
public class AuditServiceFactory {

	@Autowired
	@Qualifier("auditServiceVN")
	private IAuditService auditServiceVN;

	@Autowired
	@Qualifier("auditServiceMY")
	private IAuditService auditServiceMY;

	@Autowired
	@Qualifier("auditServiceHK")
	private IAuditService auditServiceHK;

	@Autowired
	@Qualifier("auditServiceIn")
	private IAuditService auditServiceIN;

	@Autowired
	@Qualifier("auditServiceSg")
	private IAuditService auditServiceSG;

	@Autowired
	@Qualifier("auditServiceAf")
	private IAuditService auditServiceAf;

	@Autowired
	@Qualifier("auditServiceAe")
	private IAuditService auditServiceAe;

	Map<String, IAuditService> services = new HashMap<>();

	public IAuditService getAuditService(String country) {

		switch (StringUtils.upperCase(country)) {
		case Constants.VN:
			return auditServiceVN;
		case Constants.MY:
			return auditServiceMY;
		case Constants.HK:
			return auditServiceHK;
		case Constants.IN:
			return auditServiceIN;
		case Constants.SG:
			return auditServiceSG;
		case Constants.AE:
			return auditServiceAe;
		case Constants.NG:
			return auditServiceAf;
		case Constants.KE:
			return auditServiceAf;
		case Constants.GH:
			return auditServiceAf;
		case Constants.BW:
			return auditServiceAf;
		case Constants.ZM:
			return auditServiceAf;
		case Constants.CI:
			return auditServiceAf;
		default:
			log.error("############ Country not supported ###########");
			return null;
		}
	}

}
