package com.sc.rdc.csl.ss.common.dto.account;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.Data;

@Data
@XmlType(name = "bndAccountDto")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BndAccountDto extends SsBaseDto {
   private String custId;
   private String investmentAcnt;
   private String acntOwnershipCode;
   private String curr;
   private String localCurrency;
   private BigDecimal currentFaceAmnt;
   private BigDecimal currentFaceAmntLocalCurrency;
   private BigDecimal availableFaceAmnt;
   private BigDecimal availableFaceAmntLocalCurrency;
   private BigDecimal currentTotalAmnt;
   private BigDecimal currentTotalAmntLocalCurrency;
   private BigDecimal availableTotalAmnt;
   private BigDecimal availableTotalAmntLocalCurrency;
   private String accountProductCode;
   private String accountStatus;
   private String pledgedAccount;
   private String odAccount;
 
}
         
                       