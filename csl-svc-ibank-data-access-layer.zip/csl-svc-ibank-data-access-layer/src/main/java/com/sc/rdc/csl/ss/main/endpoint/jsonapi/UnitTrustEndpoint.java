package com.sc.rdc.csl.ss.main.endpoint.jsonapi;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.unittrust.UnitTrustDto;

import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.main.service.UnitTrustServiceImpl;

import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class UnitTrustEndpoint extends ResourceRepositoryBase<UnitTrustDto, String> {

    @Autowired
    private UnitTrustServiceImpl unitTrustService;

    @Autowired
    private CSLRequestContext cslRequestContext;

    public UnitTrustEndpoint() {
        super(UnitTrustDto.class);
    }

    @Override
    public ResourceList<UnitTrustDto> findAll(QuerySpec querySpec) {

        log.info("Unit Trust Lists");
        List<UnitTrustDto> unitTrustDtos = unitTrustService.findAllUnitTrusts();
        if (unitTrustDtos.isEmpty()) {
            throw new BusinessException(ErrorConstant.UNIT_TRUST_NOT_FOUND_FOR_RELID);
        }
        return querySpec.apply(unitTrustDtos);
    }
}

