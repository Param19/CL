package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.COUNTRY_NOT_ALLOWED;

@Component()
@Slf4j
public class CustomerDetailFactory {

    Map<String, CustomerDetailService> map = new HashMap<>();

    @Qualifier("custDetailServiceHK")
    @Autowired
    private CustomerDetailService customerDetailServiceHK;

    @Qualifier("custDetailServiceAE")
    @Autowired
    private CustomerDetailService customerDetailServiceAE;

    @Qualifier("custDetailServicePK")
    @Autowired
    private CustomerDetailService customerDetailServicePK;
    
    @Qualifier("custDetailServiceSG")
    @Autowired
    private CustomerDetailService customerDetailServiceSG;
    
    @Qualifier("custDetailServiceIN")
    @Autowired
    private CustomerDetailService customerDetailServiceIN;


    public CustomerDetailService getCustomerDetail(String country) {
        if (map.size() == 0)
            initMap();
        CustomerDetailService customerDetailService = map.get(StringUtils.upperCase(country));
        if (customerDetailService != null)
            return customerDetailService;
        log.error("Country {} is not allowed to call Card Customer Service", country);
        throw new BusinessException(TemplateErrorCode.create(COUNTRY_NOT_ALLOWED, country, "CUSTOMER"));

    }

    private void initMap() {
        map.put(Constants.HK, customerDetailServiceHK);
        map.put(Constants.AE, customerDetailServiceAE);
        map.put(Constants.PK, customerDetailServicePK);
        map.put(Constants.SG, customerDetailServiceSG);
        map.put(Constants.IN, customerDetailServiceIN);
      }
}