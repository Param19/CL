package com.sc.rdc.csl.ss.main.endpoint.jsonapi;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.limit.TransactionLimit;
import com.sc.rdc.csl.ss.common.service.TransactionLimitBaseService;
import com.sc.rdc.csl.ss.main.helper.CommonEnricher;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.sc.rdc.csl.ss.common.helper.Constants.transactionTypeList;

@Component
@Slf4j
public class TransactionLimitEndpoint extends ResourceRepositoryBase<TransactionLimit, String> {

	@Autowired
	@Qualifier("transactionLimitServiceImpl")
	private TransactionLimitBaseService transactionLimitService;

	@Autowired
	@Qualifier("cslRequestContext")
	private CSLRequestContext cslRequestContext;

	private static final String PATH_TRANSACTION_TYPE = "transactionType";
	private static final String TRX_TYPE_G3_INTERBANK_TRANSFER  = "27";
	private static final String TRX_TYPE_CAS_FT = "30";
	private static final String TRX_TYPE_INTERBANK_TRANSFER = "18";
	public TransactionLimitEndpoint() {
		super(TransactionLimit.class);
	}

	@Override
	public ResourceList<TransactionLimit> findAll(QuerySpec querySpec) {

		for (FilterSpec filter: querySpec.getFilters()) {
			for (String path : filter.getAttributePath()){
				if (PATH_TRANSACTION_TYPE.equals(path)) {
					if (TRX_TYPE_G3_INTERBANK_TRANSFER.equals(filter.getValue()) ||
							TRX_TYPE_CAS_FT.equals(filter.getValue())) {
						filter.setValue(TRX_TYPE_INTERBANK_TRANSFER);
					}
				}
			}
		}
        
        //Added for China 
         Map<String, Object> filterMap = CommonEnricher.populateQuerySpec(querySpec);
        String filterValue = (String)filterMap.get("transactionType");
        log.info("Filter value: {}", filterValue);
        if(StringUtils.isNotEmpty(filterValue) && transactionTypeList.contains(filterValue)){
            log.info("Indise transactionTypeList.contains(filterValue): {}", filterValue);
            return querySpec.apply(transactionLimitService.getTransactionLimits(filterValue));
        }
		return querySpec.apply(transactionLimitService.getTransactionLimits(cslRequestContext.getUaas2id()));
	}

}
