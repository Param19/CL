package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.main.service.ProductServiceImpl;
import io.swagger.annotations.Api;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Slf4j
@Path("/products")
@Api("/products")
@Component
public class ProductEndpoint {

    @Autowired
    private ProductServiceImpl accountService;
    
    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext; 


    @GET
    @Path("/integrated-accounts")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto getIdaAccountSummary()  {
         return  accountService.getIdaAccountSummary(prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }
    
    @GET
    @Path("/bond-structurednotes")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto getBndAccountSummary()  {
         return  accountService.getBndAccountSummary(prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }
    
    
    @GET
    @Path("/unittrust-accounts")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto getInvAccountSummary()  {
         return  accountService.getInvAccountSummary(prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }

     private SsCSLUser prepareRequestDto(){
		SsCSLUser user = new SsCSLUser();
		user.setChannel(cslRequestContext.getChannel());
		user.setCountry(cslRequestContext.getCountry());
		user.setRelId(cslRequestContext.getRelId());
		user.setLanguage(cslRequestContext.getLanguage());
		user.setUaas2id(cslRequestContext.getUaas2id());
		return user;
    }
}
