package com.sc.rdc.csl.ss.dal.vn.dao;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.dal.vn.entity.CustomerEntity;

import lombok.extern.slf4j.Slf4j;

@Repository(value ="customerServiceDaoVN")
@Slf4j
public class CustomerServiceDao extends BaseDao{

    public CustomerEntity getCustomerProfile(SsCSLUser user) {
		String  relId = user.getRelId();
		String country = user.getCountry();
        log.info("CustomerServiceDao:getCustomerProfile,{}", user);
		if(!relId.startsWith(user.getCountry())){
			relId =country.concat(relId);
		}
        Query query = entityManagerVN.createQuery("SELECT new com.sc.rdc.csl.ss.dal.vn.entity.CustomerEntity(userInfo,userStat) FROM UserInfoEntity userInfo ,UserStatEntity userStat WHERE userInfo.relNo=userStat.userId AND userInfo.relNo = :relId AND userStat.coutnryCode = :country", CustomerEntity.class);
        query.setParameter("relId", relId);
        query.setParameter("country", user.getCountry());
        CustomerEntity customerProfile = (CustomerEntity) query.getSingleResult();
        log.debug("Received getCustomerProfile from DB:" + customerProfile);
        return customerProfile;
    }
}
