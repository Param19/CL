package com.sc.rdc.csl.ss.dal.hk.entity.account;


/**
 * @author honhoe
 * @since Jan 30, 2008 7:48:34 PM
 */
public class AccountConstant {

    // FilterCode
    public static final String FILTERCODE_ACCSTAT = "ACCSTAT";
    public static final String FILTERCODE_BLOCKCODE = "BLOCKCODE";
    public static final String FILTERCODE_RELCODE = "RELCODE";
    public static final String FILTERCODE_RAL_BLOCKCODE_CC = "RALBLOCKCC";

    // Account Category
    public static final String ACCOUNT_CAT_ACCOUNT = "ACCOUNT";
    public static final String ACCOUNT_CAT_CARD = "CARD";
    public static final String ACCOUNT_CAT_MCCL_CARD = "MCCLCARD";
    public static final String ACCOUNT_CAT_LOAN = "LOAN";
    public static final String ACCOUNT_CAT_OVERDRAFT = "OVERDRAFT";

    // Account Group
    public static final String ACCOUNT_GROUP_CARD = "CARD";
    public static final String ACCOUNT_GROUP_GOLD = "GOLD";
    public static final String ACCOUNT_GROUP_LOAN = "LOAN";
    public static final String ACCOUNT_GROUP_UNT = "UNT";
    public static final String ACCOUNT_GROUP_CALL = "CALL";
    public static final String ACCOUNT_GROUP_STMT = "STMT";
    public static final String ACCOUNT_GROUP_DBS = "DBS";
    public static final String ACCOUNT_GROUP_ELI = "ELI";
    public static final String ACCOUNT_GROUP_PD = "PD";
    public static final String ACCOUNT_GROUP_PASS = "PASS";
    public static final String ACCOUNT_GROUP_TIME = "TIME";
    public static final String ACCOUNT_GROUP_SWAP = "SWAP";
    public static final String ACCOUNT_GROUP_PI = "PI";
    public static final String ACCOUNT_GROUP_SEC = "SEC";
    public static final String ACCOUNT_GROUP_MORT = "MORT";
    public static final String ACCOUNT_GROUP_PTIME = "PTIME";    // MY - Premium Currency Investment
    public static final String ACCOUNT_GROUP_STIME = "STIME";    // MY - Structured Investment

    // Account Transaction Type
    public static final String TRANSACTION_TYPE_CREDIT = "C";
    public static final String TRANSACTION_TYPE_DEBIT = "D";

    // Cheque Status
    public static final String CHEQUE_RETURNED_ITEM_CHANGE = "RETURNED ITEM CHANGE";
    public static final String CHEQUE_OUT_CHQ_RET = "OUT CHQ RET";
    public static final String CHEQUE_CHQ_RETURNED = "IN-CLG CHQ RETURNED";
    public static final String CHEQUE_TXN_CODE_8531 = "8531";
    public static final String CHEQUE_TXN_CODE_8659 = "8659";
    public static final String CHEQUE_TXN_CODE_8725 = "8725";
    public static final String CHEQUE_TXN_CODE_8661 = "8661";
    public static final String CHEQUE_TXN_CODE_8052 = "8052";
    public static final String CHEQUE_TXN_CODE_8051 = "8051";
    public static final String CHEQUE_TXN_CODE_8556 = "8556";
    public static final String CHEQUE_TXN_CODE_8555 = "8555";
    
    public static final String CHEQUE_STATUS_TYPE_CLEARED = "0";
    public static final String CHEQUE_STATUS_TYPE_ENCASHED = "1";
    public static final String CHEQUE_STATUS_TYPE_PRESENTED = "2";
    public static final String CHEQUE_STATUS_TYPE_RETURNED = "3";
    public static final String CHEQUE_STATUS_TYPE_UNCONFIRMED = "4";
    public static final String CHEQUE_STATUS_TYPE_UNPRESENTED = "5";

    public static final String CHEQUE_STATUS_REFERENCE_TYPE = "SCB_CHEQUE_STATUS_TYPE";
    
    public static final String CHEQUE_STATUS_DESC_RETURNED = "IN-CLG CHQ RETURNED";
    public static final String CHEQUE_STATUS_DESC_RETURNED_ITEM_CHARGE = "RETURNED ITEM CHARGE";
    
    public static final String CHEQUE_MINIMUM_NUMBER = "000001";
    public static final String CHEQUE_MAXIMUM_NUMBER = "999999";
    public static final Integer CHEQUE_NUMBER_LENGTH = 6;

    // Loan Transaction Description
    public static final String LOAN_TRXN_DESC_OFFSET_INTEREST_DUES = "*OFFSET INTEREST DUES";

    // Account Order
    public static final Integer DEFAULT_ORDER = 1000;

    // product code / account type
    public static final String PRODUCT_CODE_SAVINGS_ACCOUNT = "RSV";
    public static final String PRODUCT_CODE_LOAN_ACCOUNT = "RLA";
    public static final String PRODUCT_CODE_FIXED_DEPOSIT_ACCOUNT = "CDA";
    public static final String PRODUCT_CODE_CREDIT_CARD = "CCA";
    public static final String PRODUCT_CODE_CURRENT_ACCOUNT = "DDA";
    public static final String PRODUCT_CODE_INVESTMENT_SERVICE_ACCOUNT = "ISA";
    public static final String PRODUCT_CODE_SECURITIES_ACCOUNT = "SXA";
    public static final String PRODUCT_CODE_DEBT_SECURITIES = "BND";
    public static final String PRODUCT_CODE_EQUITY_LINKED = "ELI";
    
    public static final String PRODUCT_GROUP_ACCOUNT = "ACCOUNT";
    public static final String PRODUCT_GROUP_CARD = "CARD";
    public static final String PRODUCT_GROUP_LOAN = "LOAN";
    
    // sub product code
    public static final String SUBPROCODE_MOA_C1 = "C1";
    public static final String SUBPROCODE_MOA_C11 = "C11";
    public static final String SUBPROCODE_MOA_C13 = "C13";
    public static final String SUBPROCODE_DDA_CA = "CA";

    public static final String SUBPROCODE_MCA_RM = "RM";
    public static final String SUBPROCODE_MCA_RN = "RN";
    public static final String SUBPROCODE_MCA_RO = "RO";
    public static final String SUBPROCODE_MCA_BN = "BN";
    public static final String SUBPROCODE_MCA_BO = "BO";

    public static final String OD_CLASS_M1 = "M1";
    public static final String OD_CLASS_M3 = "M3";

    //EStatement account type
    public static final String ACCOUNT_TYPE_TDA = "TDA";

    //Joint account relationship code
    public static final String ACCOUNT_RELCODE_JFB = "JFB";
    public static final String ACCOUNT_RELCODE_JOB = "JOB";
    public static final String ACCOUNT_RELCODE_JOE = "JOE";
    public static final String ACCOUNT_RELCODE_JFE = "JFE";
    public static final String ACCOUNT_RELCODE_GUR = "GUR";

    // Time deposit disposal code
    public static final String DISPOSAL_CODE_TA = "TA";
    public static final String DISPOSAL_CODE_TT = "TT";
    public static final String DISPOSAL_CODE_CO = "CO";

    // SME Account Include Indicator
    public static final String SME_ACCOUNT_INCLUDE_IND_I = "I";

    // OrgCode for Card
    public static final String ORG_CODE_MANHATTAN_CARD = "111";
    public static final String ORG_CODE_CUP_CARD = "22"; //CR2191

    public static final String FUNC_CODE_ACCTSUM = "ACCTSUM";
    public static final String FUNC_CODE_BALENQ = "BALENQ";
    public static final String FUNC_CODE_RALCARDACC = "RALCARDACC";
    public static final String FUNC_CODE_IAO = "IAO";
    
    public static final String HISTORY_7DAYS = "7";
    public static final String HISTORY_14DAYS = "14";
    public static final String HISTORY_30DAYS = "30";
    public static final String HISTORY_90DAYS = "90";

    public static final String ACCOUNT_STATUS_INACTIVE = "01";

    public static final String LOAN_PRODUCT_CODE_EXCLUDE_LIST = "RLA-BO,RLA-CB,RLA-EC,RLA-EI,RLA-EM,RLA-ER,RLA-FX,RLA-GH,RLA-GP,RLA-GT,RLA-HI,RLA-HO,RLA-HP,RLA-MC,RLA-MI,RLA-MR,RLA-OM";

    public static final String ACCGRP_DESC_CURRENT_ACCOUNT = "CURRENT ACCOUNT";
    
    public static final String DDA_INCLUSION_IND = "I";
    public static final String MCA_PARENT_ACCOUNT_CONTROL_FLAG = "P";
    public static final String MCA_CHILD_ACCOUNT_CONTROL_FLAG = "C";

}
