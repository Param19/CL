package com.sc.rdc.csl.ss.dal.ae.entity;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class LimitEntity extends BaseDto {

    private Long id;
	private String custSegment;
	private String limitTypeCd;
	private String txnTypeCd;
	private String ebid;
	private BigDecimal bankDefLimit;
	private BigDecimal custDefLimit;
	private String statusCd;
	private String actionCd;
	private String overdaylimit;
	private BigDecimal maxlimit;
	private BigDecimal custNewLimit;
	private String custNewLimitStr;
	private String referenceNo;

}
