/**
 * CASAMapping.java / Jun 16, 2017 / CSL-SVC-CASAS-1.0.0
 */
package com.sc.rdc.csl.ss.dal.pk.mapping;

import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.dto.customer.ReferenceDto;
import com.sc.rdc.csl.ss.dal.pk.entity.customer.CustomerDetailEntity;
import com.sc.rdc.csl.ss.dal.pk.entity.customer.ReferenceEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class CustomerPKDetailMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        orikaMapperFactory
                .classMap(CustomerDetailDto.class, CustomerDetailEntity.class)
                .field("rellId", "customerId").field("customerEBID","ebid")
                .field("segmentcode","segmentCode")
                .byDefault()
                .register();

        orikaMapperFactory
                .classMap(ReferenceDto.class, ReferenceEntity.class)
                .field("statusCd","statusCode")
                .byDefault()
                .register();
    }


}

