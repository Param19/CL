
package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.limit.TransactionLimit;
import com.sc.rdc.csl.ss.common.service.TransactionLimitBaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("transactionLimitServiceImpl")
public class TransactionLimitServiceImpl extends TransactionLimitBaseService {
    
    @Autowired
    private TransactionLimitServiceFactory transactionLimitServiceFactory;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Override
    public List<TransactionLimit> getTransactionLimits(String ebid) {
        return transactionLimitServiceFactory.getTransactionLimitService(cslRequestContext.getCountry()).getTransactionLimits(ebid);
    }

}
