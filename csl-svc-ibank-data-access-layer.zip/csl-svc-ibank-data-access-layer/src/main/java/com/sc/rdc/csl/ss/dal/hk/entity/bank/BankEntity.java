package com.sc.rdc.csl.ss.dal.hk.entity.bank;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BankEntity implements Serializable {


    private Long id;
    private String bankName;
    private String bankCode;
    private String bankBranch;
    private String branchName;
    private String country;
    private String bankAbbrName;
    private Integer ftLength;
    private Integer ccLength;
    private Integer loanLength;
    private Integer other1;
    private Integer other2;
    private Integer version;
    private String language;
    private Boolean isDisplayable;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankBranch() {
        return bankBranch;
    }

    public void setBankBranch(String bankBranch) {
        this.bankBranch = bankBranch;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getBankAbbrName() {
        return bankAbbrName;
    }

    public void setBankAbbrName(String bankAbbrName) {
        this.bankAbbrName = bankAbbrName;
    }

    public Integer getFtLength() {
        return ftLength;
    }

    public void setFtLength(Integer ftLength) {
        this.ftLength = ftLength;
    }

    public Integer getCcLength() {
        return ccLength;
    }

    public void setCcLength(Integer ccLength) {
        this.ccLength = ccLength;
    }

    public Integer getLoanLength() {
        return loanLength;
    }

    public void setLoanLength(Integer loanLength) {
        this.loanLength = loanLength;
    }

    public Integer getOther1() {
        return other1;
    }

    public void setOther1(Integer other1) {
        this.other1 = other1;
    }

    public Integer getOther2() {
        return other2;
    }

    public void setOther2(Integer other2) {
        this.other2 = other2;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Boolean getDisplayable() {
        return isDisplayable;
    }

    public void setDisplayable(Boolean displayable) {
        isDisplayable = displayable;
    }
}
