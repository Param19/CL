package com.sc.rdc.csl.ss.dal.sg.config;


import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.dal.sg.entity.ProfileEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class ProfileViewToTableMapperConfig implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory mapperFactory) {

        mapperFactory.classMap(Profile.class, com.sc.rdc.csl.ss.dal.sg.entity.CustomerStatusEntity.class)
                .exclude("relId")
                .constructorA()
                .constructorB()
                .mapNulls(false)
                .mapNullsInReverse(false)
                .field("custSeqNo", "customerProfileId")
                .field("notificationType", "notificationMode")
                .byDefault()
                .register();

        mapperFactory.classMap(Profile.class, com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerStatusEntity.class)
                .exclude("relId")
                .constructorA()
                .constructorB()
                .mapNulls(false)
                .mapNullsInReverse(false)
                .field("custSeqNo", "customerProfileId")
                .field("notificationType", "notificationMode")
                .byDefault()
                .register();

        mapperFactory.classMap(ProfileEntity.class, Profile.class)
                .constructorA()
                .constructorB()
                .mapNulls(false)
                .mapNullsInReverse(false)
                .byDefault()
                .register();
    }

}
