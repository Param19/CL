package com.sc.rdc.csl.ss.dal.af.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.helper.CommonHelper;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.helper.MailConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import com.sc.rdc.csl.ss.dal.af.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.af.dao.MailServiceDao;
import com.sc.rdc.csl.ss.dal.af.entity.CustomerVO;
import com.sc.rdc.csl.ss.dal.af.entity.MailVO;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Slf4j
@Service(value = "mailBoxServiceAF")
public class MailBoxService extends MailService {

    @Qualifier("mailServiceDaoAf")
    @Autowired
    private MailServiceDao mailServiceDao;

    @Qualifier("customerServiceDaoAf")
    @Autowired
    private CustomerServiceDao customerServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Transactional("transactionManagerAf")
    @Override
    @LogTimeTaken
    public SsBaseDto submitMailData(MailServiceEntityDto mailServiceEntityDto, SsCSLUser user) {

        log.info("Persisting Inbox message into Data base : {} : {}", user.getCountry(), mailServiceEntityDto.getReference());
        CustomerVO customerVO = customerServiceDao.getCustomerProfile(user);

        MailVO mailVO = orikaMapperFacade.map(mailServiceEntityDto, MailVO.class);

        mailVO.setMessageTo(customerVO.getUuid());
        mailVO.setMessageBody(CommonHelper.decodeBase64Value(mailVO.getMessageBody()));
        mailVO.setMessageFrom(Constants.SCB);
        mailVO.setMessageFromAddressType(Constants.ADDRESS_TYPE);
        mailVO.setMessageToAddressType(Constants.ADDRESS_TYPE);
        Date currentDateTime = new Date();
        mailVO.setMessageStatusDate(currentDateTime);
        mailVO.setDateRepliedByBO(currentDateTime);
        mailVO.setDateDeletedByBO(currentDateTime);
        mailVO.setMessageStatusDateByBO(currentDateTime);
        mailVO.setIsDeletedByCustomer(Boolean.FALSE);
        mailVO.setIsRepliedByBO(Boolean.FALSE);
        mailVO.setIsDeletedByBO(Boolean.FALSE);
        mailVO.setMessageStatus(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailVO.setMessageStatusByBO(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailVO.setCreatedDate(currentDateTime);
        mailVO.setCreatedBy(user.getCustomerId());
        mailVO.setUpdatedDate(currentDateTime);
        mailVO.setUpdatedBy(user.getCustomerId());
        mailVO.setCountryCode(user.getCountry());
        mailVO.setVersion(1L);

        mailServiceDao.insertMailData(mailVO);

        mailServiceEntityDto.setStatusDescription(MailConstant.STATUS);
        mailServiceEntityDto.setStatusCode(MailConstant.STATUS_CODE);

        return mailServiceEntityDto;
    }
}
