package com.sc.rdc.csl.ss.dal.af.dao;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.dal.af.entity.CustomerVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;

@Repository(value = "customerServiceDaoAf")
@Slf4j
public class CustomerServiceDao extends BaseDao {

    public CustomerVO getCustomerProfile(SsCSLUser user) {
        log.info("CustomerServiceDao:getCustomerProfile,{}", user);
        TypedQuery<CustomerVO> query = entityManagerAf.createQuery("select b from com.sc.rdc.csl.ss.dal.af.entity.CustomerVO b WHERE b.customerId = :customerId and b.statusCode = :statusCode and b.countryCode =:countryCode", CustomerVO.class);
        query.setParameter("customerId", user.getCustomerId());
        query.setParameter("statusCode", Constants.STATUS_CD);
        query.setParameter("countryCode", user.getCountry());
        CustomerVO customerVO = query.getSingleResult();
        log.info("Received getCustomerProfile from DB:" + customerVO);
        return customerVO;
    }
}
