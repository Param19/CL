package com.sc.rdc.csl.ss.dal.ae.service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.payee.PayeeDto;
import com.sc.rdc.csl.ss.dal.ae.dao.PayeeDao;
import com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.ArrayList;

import java.util.Date;

@Slf4j
@Service(value = "payeeServiceAE")
public class PayeeService extends com.sc.rdc.csl.ss.common.service.PayeeService {

    @Qualifier("payeeDaoAe")
    @Autowired
    private PayeeDao payeeDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Override
    public PayeeDto getPayee(String payeeId) {
        PayeeEntity payeeEntity = payeeDao.getPayeeDetails(payeeId);
        PayeeDto payeeDto = orikaMapperFacade.map(payeeEntity, PayeeDto.class);

        return payeeDto;
    }

    @Transactional("transactionManagerAe")
    @Override
    public void addPayee(PayeeDto payeeDto) {
        PayeeEntity payeeEntity = orikaMapperFacade.map(payeeDto, PayeeEntity.class);
        payeeEntity.setCreatedDate(new Date());
        payeeEntity.setUpdatedDate(new Date());
        payeeEntity.setUpdatedBy("SYSTEM");
        payeeEntity.setCreatedBy("SYSTEM");
        payeeEntity.setStatusCd("A");
        log.info("Mapped Payee dto:{} ", payeeDto);
        log.info("Mapped Payee entity:{} ", payeeEntity);
        payeeDao.addPayee(payeeEntity);
    }

    @Transactional("transactionManagerAe")
    @Override
    public void deletePayee(String id) {
        log.info("Deleting Payee in Database : {}", id);
        //Long payeeId = Long.parseLong(id);
        payeeDao.deletePayee(id);
    }

    @Transactional("transactionManagerAe")
    @Override
    public void updatePayee(PayeeDto payeeDto) {
        PayeeEntity payeeEntity = orikaMapperFacade.map(payeeDto, PayeeEntity.class);
        payeeDao.updatePayee(payeeEntity, payeeDto.getOldPayeeId());
    }

    @Override
    public List<PayeeDto> getAllPayees() {
        List<PayeeEntity> payeeEntities = payeeDao.getAllPayee();
        List<PayeeDto> payeeDtos = new ArrayList<>();
        for(PayeeEntity payeeEntity: payeeEntities) {
            PayeeDto payeeDto = orikaMapperFacade.map(payeeEntity, PayeeDto.class);
            payeeDtos.add(payeeDto);
        }

        return payeeDtos;
    }

}
