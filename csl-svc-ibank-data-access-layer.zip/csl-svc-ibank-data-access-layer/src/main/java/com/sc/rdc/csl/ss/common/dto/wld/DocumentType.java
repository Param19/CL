package com.sc.rdc.csl.ss.common.dto.wld;


public enum DocumentType {

    ID("ID"),
    PP("PP"),
    OT("OT");
    
    private String type;

    private DocumentType() {
    }

    private DocumentType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return type;
    }
    
    

}
