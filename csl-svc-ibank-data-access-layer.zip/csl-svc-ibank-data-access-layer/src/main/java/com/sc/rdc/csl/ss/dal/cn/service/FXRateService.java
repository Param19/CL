package com.sc.rdc.csl.ss.dal.cn.service;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.cn.dao.FXRateDao;
import com.sc.rdc.csl.ss.dal.cn.entity.FXRateEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

import static com.sc.rdc.csl.ss.dal.cn.config.LimitsConstant.MULTIPLIER;
import static com.sc.rdc.csl.ss.dal.cn.config.LimitsConstant.RATE_TYPE;


/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Slf4j
@Service("fxRateServiceCN")
public class FXRateService {

    @Autowired
    @Qualifier("fxRateDao")
    private FXRateDao fxRateDao;

    public BigDecimal getLCYAmount(String currency, BigDecimal amount) {
        List<FXRateEntity> fxRateList = fxRateDao.getAllFXRate(RATE_TYPE);
        FXRateEntity fxRate = fxRateList.stream()
                .filter(x -> currency.equalsIgnoreCase(x.getFxCurrencyCode()))
                .findFirst().orElseThrow(() -> new TechnicalException(ErrorConstant.ERR_FETCHING_FXRATE));
        if (MULTIPLIER.equalsIgnoreCase(fxRate.getMultiplyDividFlag())) {
            return amount.multiply(fxRate.getMidRate());
        } else {
            return amount.divide(fxRate.getMidRate(), 2, BigDecimal.ROUND_HALF_UP);
        }
    }
}
