package com.sc.rdc.csl.ss.dal.ae.service;


import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.AccountDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IAccountService;
import com.sc.rdc.csl.ss.dal.ae.dao.AccountServiceDao;
import com.sc.rdc.csl.ss.dal.ae.dao.ProductServiceDao;
import com.sc.rdc.csl.ss.dal.ae.entity.AccountEntity;
import com.sc.rdc.csl.ss.dal.ae.entity.FilterProductEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service("accountServiceAe")
public class AccountService extends IAccountService {

    @Autowired
    @Qualifier("accountServiceDaoAe")
    private AccountServiceDao accountServiceDao;

    @Autowired
    @Qualifier("productServiceDaoAe")
    private ProductServiceDao productServiceDao;
    
    @Autowired
    private MapperFacade orikaMapperFacade;
    
    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    public List<AccountDto> getAccountSummary() {
        List<AccountDto> accountDtoList = new ArrayList<AccountDto>();

        try {
            Optional<List<AccountEntity>> accountEntityList = Optional.ofNullable(accountServiceDao.getAccountSummary());
            accountEntityList =  buildAccountList(accountEntityList);
            log.info("accountEntityList after setting the account description ::{}", accountEntityList);
            accountEntityList.get().forEach(accountEntity -> {
                accountDtoList.add(orikaMapperFacade.map(accountEntity, AccountDto.class));
            });
            
            log.info("Orika mapper result :{}", accountDtoList);
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Account Summary for user  , {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return accountDtoList;
    }
    
    public List<AccountDto> getAccountDescription() {
    	
    	List<AccountDto> accountDescriptionDtos = new ArrayList<AccountDto>();
        try {

            Optional<List<AccountEntity>> accountEntityList = Optional.ofNullable(accountServiceDao.getAccountSummary());
            accountEntityList =  buildAccountList(accountEntityList);

            accountEntityList.get().forEach(accountEntity -> {
            	AccountDto accountDescriptionDto =  new AccountDto();
            	accountDescriptionDto.setAccountDescription(accountEntity.getAccountDescription());
            	accountDescriptionDto.setCurrencyCode(accountEntity.getCurrencyCode());
            	accountDescriptionDto.setAccountNumber(accountEntity.getAccountNumber());
            	accountDescriptionDto.setProductCode(accountEntity.getSubProductCode());
            	accountDescriptionDto.setAccountDesFilter("true");
            	accountDescriptionDtos.add(accountDescriptionDto);
            });
            
            log.info("accountDescriptionDto after setting the account description ::{}", accountDescriptionDtos);
            
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Account Summary for user  , {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return accountDescriptionDtos;
    }

        private Optional<List<AccountEntity>> buildAccountList(Optional<List<AccountEntity>> accountEntityList){

            ArrayList<String> accountCodeList = new ArrayList<String>();
            accountEntityList.get().forEach(accountEntity -> {
                if(StringUtils.isNotEmpty(accountEntity.getProductCode()) && StringUtils.isNotEmpty(accountEntity.getSubProductCode())){
                    accountCodeList.add("CASA"+"-"+accountEntity.getSubProductCode());
                }
            });
            Set<String> uniqueAccountCodeList = new HashSet<String>(accountCodeList);
            String lang = requestContext.getLanguage();
            List<FilterProductEntity> filterProductEntityList =  productServiceDao.getFilterProduct(uniqueAccountCodeList, lang);
            log.info("filterProductEntityList after setting the filterProductEntityList ::{}", filterProductEntityList);
            log.info("accountCodeList :{}",accountCodeList);
            if(accountEntityList!= null && filterProductEntityList != null){
                accountEntityList.get().forEach(accountEntity -> {
                    for(FilterProductEntity entity: filterProductEntityList){
                        if(entity!=null && StringUtils.isNotEmpty(entity.getProductCode()) && StringUtils.isNotEmpty(entity.getSubProductCode())){
                            if("CASA".equalsIgnoreCase(entity.getProductCode()) && accountEntity.getSubProductCode().equalsIgnoreCase(entity.getSubProductCode())){
                                accountEntity.setAccountDescription(entity.getAccountTypeAlias());
                            }
                        }
                    }
                });
            }


            log.info("accountEntityList after setting the personalizedSettingsEntity description ::{}", accountEntityList);

            return accountEntityList;
    }

}
