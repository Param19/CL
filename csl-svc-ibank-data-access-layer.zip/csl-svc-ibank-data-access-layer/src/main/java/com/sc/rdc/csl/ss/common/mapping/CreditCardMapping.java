package com.sc.rdc.csl.ss.common.mapping;

import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class CreditCardMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        //Card-Customer mapping
        orikaMapperFactory.classMap(com.sc.rdc.csl.ss.dal.hk.entity.card.CardCustEntity.class,
                com.sc.rdc.csl.ss.common.dto.card.CardCustDto.class)
                .field("cardNo", "creditCardNo")
                .field("cardNo", "cardNo")
                .field("customerId", "customerId")
                .field("custIdType", "customerIdType").register();

        orikaMapperFactory.classMap(com.sc.rdc.csl.ss.dal.hk.entity.card.CardTxnHistoryEntity.class,
                com.sc.rdc.csl.ss.common.dto.account.Transaction.class)
                .field("txnRefNo", "transactionApprovalSequenceNumber")
                .field("cardNum", "accountNo")
                .field("orgCode", "orgCode")
                .field("txnPostDate", "transactionEffectiveDate")
                .field("refDesc", "transactionDescription")
                .field("actualTxnAmount", "transactionAmount")
                .field("txnCode", "creditDebitTransactionIndicator")
                .field("txnCurr", "transactionCurrencyCode").register();

        orikaMapperFactory.classMap(com.sc.rdc.csl.ss.dal.in.entity.CardTxnHistoryEntity.class,
                com.sc.rdc.csl.ss.common.dto.account.Transaction.class)
                .field("txnRefNo", "transactionApprovalSequenceNumber")
                .field("cardNum", "accountNo")
                .field("orgCode", "orgCode")
                .field("txnPostDate", "transactionEffectiveDate")
                .field("refDesc", "transactionDescription")
                .field("actualTxnAmount", "transactionAmount")
                .field("txnCode", "creditDebitTransactionIndicator")
                .field("txnCurr", "transactionCurrencyCode").register();

        orikaMapperFactory.classMap(com.sc.rdc.csl.ss.dal.sg.entity.CardTxnHistoryEntity.class,
                com.sc.rdc.csl.ss.common.dto.account.Transaction.class)
                .field("txnRefNo", "transactionApprovalSequenceNumber")
                .field("cardNum", "accountNo")
                .field("orgCode", "orgCode")
                .field("txnPostDate", "transactionEffectiveDate")
                .field("refDesc", "transactionDescription")
                .field("actualTxnAmount", "transactionAmount")
                .field("txnCode", "creditDebitTransactionIndicator")
                .field("txnCurr", "transactionCurrencyCode").register();
    }
}




