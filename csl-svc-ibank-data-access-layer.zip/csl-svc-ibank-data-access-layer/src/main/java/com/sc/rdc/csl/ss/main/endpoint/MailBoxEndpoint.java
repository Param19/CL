package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class MailBoxEndpoint extends ResourceRepositoryBase<MailServiceEntityDto, String> {

    @Autowired
    @Qualifier("mailServiceImpl")
    private MailService mailService;

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    public MailBoxEndpoint() {
        super(MailServiceEntityDto.class);
    }

    @Override
    public MailServiceEntityDto create(MailServiceEntityDto mailServiceEntityDto) {

        log.info("Rel Id:" + cslRequestContext.getRelId());
        log.info("Received request for MailBox Notification : {} ; {}", cslRequestContext.getCountry(), mailServiceEntityDto.getReference());
        mailServiceEntityDto.setRelNumber(cslRequestContext.getRelId());
        mailServiceEntityDto.setCountryCode(cslRequestContext.getCountry());
        SsCSLUser user = new SsCSLUser();
        user.setUaas2id(cslRequestContext.getUaas2id());
        user.setCustomerId(cslRequestContext.getCustomerId());
        user.setRelId(cslRequestContext.getRelId());
        user.setCountry(cslRequestContext.getCountry());
        user.setChannel(cslRequestContext.getChannel());
        mailService.submitMailData(mailServiceEntityDto, user);
        return mailServiceEntityDto;
    }

    @Override
    public MailServiceEntityDto findOne(String id, QuerySpec querySpec) {

        try {
            log.debug("[MailRepository findAll Entry]");
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        } finally {
            log.debug("[MailRepository findOne Exit]");
        }
    }

    @Override
    public ResourceList<MailServiceEntityDto> findAll(QuerySpec querySpec) {
        try {
            log.debug("[MailRepository findAll Entry]");
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        } finally {
            log.debug("[MailRepository findAll Exit]");
        }
    }
}
