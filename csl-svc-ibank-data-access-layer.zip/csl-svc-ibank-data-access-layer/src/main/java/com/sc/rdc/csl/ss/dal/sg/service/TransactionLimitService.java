package com.sc.rdc.csl.ss.dal.sg.service;

import com.sc.rdc.csl.ss.common.dto.limit.TransactionLimit;
import com.sc.rdc.csl.ss.common.service.TransactionLimitBaseService;
import com.sc.rdc.csl.ss.dal.sg.dao.TransactionLimitDao;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service(value = "transactionLimitServiceSG")
public class TransactionLimitService extends TransactionLimitBaseService {

    @Autowired
    @Qualifier("transactionLimitDaoSg")
    private TransactionLimitDao transactionLimitDao;

    @Autowired
    private MapperFacade orikaMapper;

    @Override
    public List<TransactionLimit> getTransactionLimits(String ebid) {
        return orikaMapper.mapAsList(transactionLimitDao.getTransactionLimits(ebid), TransactionLimit.class);
    }
}





