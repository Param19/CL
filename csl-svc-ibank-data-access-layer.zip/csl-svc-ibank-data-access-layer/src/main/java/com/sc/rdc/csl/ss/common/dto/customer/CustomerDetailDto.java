package com.sc.rdc.csl.ss.common.dto.customer;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

import java.util.Date;


@Data
@JsonApiResource(type = "customer-details")
public class CustomerDetailDto extends SsBaseDto {

    @JsonApiId
    private String rellId;

    @JsonProperty("customer-ebid")
    private String customerEBID;

    @JsonProperty("countryGroup")
    private String countryGroup;

    @JsonProperty("customer-id-type")
    private String customerIdType;

    @JsonProperty("segment-code")
    private String segmentcode;

    @JsonProperty("sme-flag")
    private String smeFlag;

    @JsonProperty("country-code")
    private String country;

    @JsonProperty("uuid")
    private String uuid;

    @JsonProperty("ctry-cd")
    private String ctryCd;

    @JsonProperty("user-pswd")
    private String userPswd;

    @JsonProperty("name")
    private String name;

    @JsonProperty("status-cd")
    private String statusCd;

    @JsonProperty("dt-first-login")
    private Date dtFirstLogin;

    @JsonProperty("dt-last-login")
    private Date dtLastLogin;

    @JsonProperty("login-invalid-count")
    private int loginInvalidCount;

    @JsonProperty("cust-group-id")
    private String custGroupId;

    @JsonProperty("customer-name-1")
    private String custName1;

    @JsonProperty("customer-name-2")
    private String custName2;

    @JsonProperty("nickname")
    private String nickName;

    @JsonProperty("arm-cd")
    private String armCd;

    @JsonProperty("email")
    private String email;

    @JsonProperty("mobile-phone")
    private String mobilePhone;

    @JsonProperty("notif-type")
    private String notifType;

    @JsonProperty("address-1")
    private String address1;

    @JsonProperty("address-2")
    private String address2;

    @JsonProperty("address-3")
    private String address3;

    @JsonProperty("address-4")
    private String address4;

    @JsonProperty("district")
    private String district;

    @JsonProperty("state")
    private String state;

    @JsonProperty("place-birth")
    private String placeBirth;

    @JsonProperty("customer-access-key")
    private String custAccessKey;

    @JsonProperty("date-serv-start")
    private Date dtServStart;

    @JsonProperty("date-serv-end")
    private Date dtServEnd;

    @JsonProperty("date-suspend-start")
    private Date dtSuspendStart;

    @JsonProperty("date-suspend-end")
    private Date dtSuspendEnd;

    @JsonProperty("ftl-browser-id")
    private String ftlBrowserId;

    @JsonProperty("ftl-terms-accept-date")
    private Date ftlTermsAcceptDate;

    @JsonProperty("is-rereg")
    private String isRereg;

    @JsonProperty("is-letter-gen")
    private String isLetterGen;

    @JsonProperty("is-email-gen")
    private String isEmailGen;

    @JsonProperty("is-act")
    private String isAct;

    @JsonProperty("date-act")
    private Date dtAct;

    @JsonProperty("migrate-flag")
    private String migrateFlag;

    @JsonProperty("date-reg")
    private Date dtReg;

    @JsonProperty("reg-by")
    private String regBy;

    @JsonProperty("reg-mode")
    private String regMode;

    @JsonProperty("actv-type")
    private String actvType;

    @JsonProperty("pin-mailer-ser-no")
    private String pinMailerSerNo;

    @JsonProperty("pin-mailer-counter")
    private int pinMailerCounter;

    @JsonProperty("date-pin-mailer-exp")
    private Date dtPinMailerExp;

    @JsonProperty("rereg-count")
    private long reregCount;

    @JsonProperty("two-fa-typ-cd")
    private String twoFaTypCd;

    @JsonProperty("remark")
    private String remark;

    @JsonProperty("date-created")
    private Date dtCreated;

    @JsonProperty("created-by")
    private String createdBy;

    @JsonProperty("date-updated")
    private Date dtUpd;

    @JsonProperty("updated-by")
    private String updBy;

    @JsonProperty("version")
    private long version;

    @JsonProperty("sms-alert")
    private Boolean smsAlert;

    @JsonProperty("email-alert")
    private Boolean emailAlert;

    private String userId;
    private String userPassword;
    private String customerPBID;
    private String customerId;
    private String customerName1;
    private String customerName2;
    private String customerStatusCode;
    private String language;
    private Date lastLoginDate;
    private Date firstLoginDate;
    private String isLoggedIn;
    private Boolean isActivated;
    private Integer loginCounter;
    private String mobileNumber;
    private String accessKey;
    private String twoFAType;
    private String emailAddress;
    private String systemType;
    private String brandIndicator;
    private String armCode;
    private String relTyp;
    private String packageStatus;
    private Integer loginSuccessCount;
    private Long customerSequenceNo;
    private String txnPasswordStatus;
    private String migrationStatus;
    private boolean e2eMigrationStatus;
    @JsonIgnore
    private String customerPreference;


}