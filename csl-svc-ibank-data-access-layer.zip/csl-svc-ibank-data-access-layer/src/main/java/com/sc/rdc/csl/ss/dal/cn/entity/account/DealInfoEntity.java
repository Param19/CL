package com.sc.rdc.csl.ss.dal.cn.entity.account;

import lombok.Data;
import javax.persistence.*;

/**
 * Created by 1347884 on 11/29/2017.
 */
@Entity
@Data
@Table(name = "TD_ACCT_OPENING_DEAL_DETAILS", schema = "SCBREF")
public class DealInfoEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID", nullable = false)
    private Long id;

    @Column(name = "DEPOSIT_TYPE", nullable = false)
    private String depositType;

    @Column(name = "CURRENCY_CD", nullable = false)
    private String currencyCode;

    @Column(name = "DEAL_TYPE", nullable = false)
    private String dealType;

    @Column(name = "TENURE_UNIT", nullable = false)
    private String tenureUnit;

    @Column(name = "DEPOSIT_TENURE_VALUE", nullable = false)
    private String depositTenureValue;

    @Column(name = "INTEREST_PRODUCT", nullable = false)
    private String interestProduct;

    @Column(name = "INTEREST_CD", nullable = false)
    private String interestCode;

    @Column(name = "STATUS_CD", nullable = false)
    private String statusCD;
}
