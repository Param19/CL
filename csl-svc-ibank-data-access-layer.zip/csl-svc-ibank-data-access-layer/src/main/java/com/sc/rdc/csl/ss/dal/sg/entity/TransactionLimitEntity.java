package com.sc.rdc.csl.ss.dal.sg.entity;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;


@Data
public class TransactionLimitEntity {

	private Long id;
	private String ebid;
	private String customerId;
	private String customerIdType;
	private String category;
	private String transactionType;
	private String merchantType;
	private String merchantCode;
	private String payeeIndicator;
	private BigDecimal maximumLimit;
	private BigDecimal defLimit;
	private String countryCode;
	private Date updatedDate;
	private String updatedBy;

}

