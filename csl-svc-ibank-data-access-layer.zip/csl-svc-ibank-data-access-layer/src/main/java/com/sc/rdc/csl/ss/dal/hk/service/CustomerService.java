package com.sc.rdc.csl.ss.dal.hk.service;


import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerProfile;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICustomerService;
import com.sc.rdc.csl.ss.dal.hk.config.DozerUtilsHk;
import com.sc.rdc.csl.ss.dal.hk.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerStatusEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.NoResultException;
import java.util.Optional;

@Slf4j
@Service("customerServiceHK")
public class CustomerService extends ICustomerService {

    @Autowired
    @Qualifier("customerServiceDaoHK")
    private CustomerServiceDao customerServiceDao;

    @Qualifier("dozerUtilsHk")
    @Autowired
    private DozerUtilsHk dozerUtilsHK;

    @Autowired
    private MapperFacade orikaMapper;

    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public CustomerProfile getCustomerProfile(SsCSLUser user) {
        CustomerProfile customer = new CustomerProfile();
        try {
            Profile profile = getProfileEntity(user);
            log.info("profile after mapping :" + profile);
            customer.setStatusCode(SsConstant.SS_SUCCESS_STATUS);
            customer.setProfile(profile);
        } catch (Exception e) {
            log.error("exception details " + e.getMessage());
            if (e instanceof BusinessException)
                throw e;
            if (e instanceof EmptyResultDataAccessException)
                throw new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION);
            else {
                log.error("Exception while fetching Customerprofile {} , {} ", user.getCustomerId(), e.getMessage());
                throw new TechnicalException(ErrorConstant.ERR_FETCHING_CUSTOMER);
            }
        }
        return customer;
    }

    public Profile getProfile(SsCSLUser user) {
        return orikaMapper.map(getProfileEntity(user), Profile.class);
    }

    @Transactional("transactionManagerHk")
    @LogTimeTaken
    public void updateProfile(SsCSLUser user, Profile profile) {
        if (profile.getCustSeqNo() == null) {
            throw new BusinessException(ErrorConstant.ERR_NO_CUSTID);
        }
        updateUnderlyingProfileTables(profile);
    }

    private void updateUnderlyingProfileTables(Profile profile) {
        CustomerStatusEntity customerStatusEntity = customerServiceDao.getCustomerStatus(profile.getCustSeqNo());
        orikaMapper.map(profile, customerStatusEntity);
        customerServiceDao.update(customerStatusEntity);
    }

    private Profile getProfileEntity(SsCSLUser user) {
        if (StringUtils.isEmpty(user.getCustomerId()) && StringUtils.isEmpty(user.getUaas2id())) {
            throw new BusinessException(ErrorConstant.ERR_NO_CUSTID);
        }
        try {
            Optional<CustomerEntity> customerEntity = Optional.ofNullable(customerServiceDao.getCustomerProfile(user));
            customerEntity.orElseThrow(() -> new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION));
            log.info("DB VALUE :" + customerEntity.get());
            return dozerUtilsHK.convertCustomer(new Profile(), customerEntity.get(), "customer-profile");

        } catch (NoResultException ex) {
            throw new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION);
        }

    }
}
