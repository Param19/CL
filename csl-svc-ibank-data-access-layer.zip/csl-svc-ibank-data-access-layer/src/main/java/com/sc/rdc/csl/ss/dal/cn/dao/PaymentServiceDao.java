package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.GLPaymentEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.PaymentEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.ScheduledTransactionsSafeEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_PAYMENT_EXCEPTION;

@Repository(value = "paymentServiceDaoCn")
@Slf4j
public class PaymentServiceDao extends BaseDao {

    public static String FIND_PAYMENT = "select p from com.sc.rdc.csl.ss.dal.cn.entity.payment.PaymentEntity p WHERE p.transactionId = :transactionId";

    public static String SEQUENCE_NUMBER = "SELECT CFE.APP_ID_SEQ.NEXTVAL FROM dual";

    public PaymentEntity insertPayment(PaymentEntity paymentEntity) {
        log.debug("PaymentServiceDao:insertPayment,{}", paymentEntity);
        try {
            paymentEntity = entityManagerCn.merge(paymentEntity);
            return paymentEntity;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

    public ScheduledTransactionsSafeEntity insertSafeDetails(ScheduledTransactionsSafeEntity scheduledTransactionsSafeEntity) {
        log.debug("PaymentServiceDao:insertSafeDetails,{}", scheduledTransactionsSafeEntity);
        try {
            scheduledTransactionsSafeEntity = entityManagerCn.merge(scheduledTransactionsSafeEntity);
            return scheduledTransactionsSafeEntity;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

    public GLPaymentEntity insertGLPaymentDetails(GLPaymentEntity glPaymentEntity) {
        log.debug("PaymentServiceDao:insertGLPaymentDetails,{}", glPaymentEntity);
        try {
            glPaymentEntity = entityManagerCn.merge(glPaymentEntity);
            return glPaymentEntity;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

    public PaymentEntity updatePayment(PaymentEntity paymentEntity) {
        log.info("PaymentServiceDao:updatePayment,{}", paymentEntity);
        try {
            paymentEntity = entityManagerCn.merge(paymentEntity);
            return paymentEntity;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

    public PaymentEntity getPayment(String transactionId) {
        log.debug("PaymentServiceDao:getPayment,{}", transactionId);
        PaymentEntity paymentEntity = null;
        try {
            Query query = entityManagerCn.createQuery(FIND_PAYMENT);
            query.setParameter("transactionId", transactionId);
            List<PaymentEntity> paymentVoList = query.getResultList();
            if (!paymentVoList.isEmpty()) {
                paymentEntity = paymentVoList.get(0);
            }
            return paymentEntity;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

    public Long getSequence(){
        Query query = entityManagerCn.createQuery(SEQUENCE_NUMBER);
        return (Long)query.getResultList().get(0);
    }
}
