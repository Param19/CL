package com.sc.rdc.csl.ss.dal.hk.entity.account;

import java.math.BigDecimal;
import java.util.Date;

public class AccountEntity extends ProductEntity {

    private static final long serialVersionUID = -1L;

    private BigDecimal localCurrentBalance;
    private BigDecimal localAvailableBalance;

    private BigDecimal principal;
    private String term;
    private BigDecimal interestRate;
    private Date issueDate;
    private Date currentMaturityDate;
    private BigDecimal interestAtMaturity;

    private Date tradeDate;
    private Date valuedDate;
    private String alternateCurrency;
    private BigDecimal conversionRate;
    private Date fixingDate;
    private BigDecimal fixingRate;
    private BigDecimal repaymentDepositCurrency;
    private BigDecimal repaymentAlternateCurrency;

    private String issueNumber;
    private String issueDescription;
    private BigDecimal currentFaceAmount;
    private BigDecimal availableFaceAmount;
    private BigDecimal marketPrice;
    private BigDecimal currentMarketValue;
    private BigDecimal availableMarketValue;
    // Extra
    private BigDecimal principalPlusInterest;

    //for Account Details
    private String interestDisposalCode;
    private String principalDisposalCode;
    private String specialInstruction;
    private String termCode;

    private String odClass;

    private String currentBalanceStr;
    //For wealthPro 
   // private String wealthproIndicator;
   // private String wealthproODAccNo;

    public String getInterestDisposalCode() {
        return interestDisposalCode;
    }

    public void setInterestDisposalCode(String interestDisposalCode) {
        this.interestDisposalCode = interestDisposalCode;
    }

    public String getPrincipalDisposalCode() {
        return principalDisposalCode;
    }

    public void setPrincipalDisposalCode(String principalDisposalCode) {
        this.principalDisposalCode = principalDisposalCode;
    }

    public BigDecimal getLocalCurrentBalance() {
        return localCurrentBalance;
    }

    public void setLocalCurrentBalance(BigDecimal localCurrentBalance) {
        this.localCurrentBalance = localCurrentBalance;
    }

    public BigDecimal getLocalAvailableBalance() {
        return localAvailableBalance;
    }

    public void setLocalAvailableBalance(BigDecimal localAvailableBalance) {
        this.localAvailableBalance = localAvailableBalance;
    }

    public String getAlternateCurrency() {
        return alternateCurrency;
    }

    public void setAlternateCurrency(String alternateCurrency) {
        this.alternateCurrency = alternateCurrency;
    }

    public BigDecimal getAvailableFaceAmount() {
        return availableFaceAmount;
    }

    public void setAvailableFaceAmount(BigDecimal availableFaceAmount) {
        this.availableFaceAmount = availableFaceAmount;
    }

    public BigDecimal getAvailableMarketValue() {
        return availableMarketValue;
    }

    public void setAvailableMarketValue(BigDecimal availableMarketValue) {
        this.availableMarketValue = availableMarketValue;
    }

    public BigDecimal getConversionRate() {
        return conversionRate;
    }

    public void setConversionRate(BigDecimal conversionRate) {
        this.conversionRate = conversionRate;
    }

    public BigDecimal getCurrentFaceAmount() {
        return currentFaceAmount;
    }

    public void setCurrentFaceAmount(BigDecimal currentFaceAmount) {
        this.currentFaceAmount = currentFaceAmount;
    }

    public BigDecimal getCurrentMarketValue() {
        return currentMarketValue;
    }

    public void setCurrentMarketValue(BigDecimal currentMarketValue) {
        this.currentMarketValue = currentMarketValue;
    }

    public Date getCurrentMaturityDate() {
        return currentMaturityDate;
    }

    public void setCurrentMaturityDate(Date currentMaturityDate) {
        this.currentMaturityDate = currentMaturityDate;
    }

    public Date getFixingDate() {
        return fixingDate;
    }

    public void setFixingDate(Date fixingDate) {
        this.fixingDate = fixingDate;
    }

    public BigDecimal getFixingRate() {
        return fixingRate;
    }

    public void setFixingRate(BigDecimal fixingRate) {
        this.fixingRate = fixingRate;
    }

    public BigDecimal getInterestAtMaturity() {
        return interestAtMaturity;
    }

    public void setInterestAtMaturity(BigDecimal interestAtMaturity) {
        this.interestAtMaturity = interestAtMaturity;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public String getIssueDescription() {
        return issueDescription;
    }

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public String getIssueNumber() {
        return issueNumber;
    }

    public void setIssueNumber(String issueNumber) {
        this.issueNumber = issueNumber;
    }

    public BigDecimal getMarketPrice() {
        return marketPrice;
    }

    public void setMarketPrice(BigDecimal marketPrice) {
        this.marketPrice = marketPrice;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public void setPrincipal(BigDecimal principal) {
        this.principal = principal;
    }

    public BigDecimal getRepaymentAlternateCurrency() {
        return repaymentAlternateCurrency;
    }

    public void setRepaymentAlternateCurrency(BigDecimal repaymentAlternateCurrency) {
        this.repaymentAlternateCurrency = repaymentAlternateCurrency;
    }

    public BigDecimal getRepaymentDepositCurrency() {
        return repaymentDepositCurrency;
    }

    public void setRepaymentDepositCurrency(BigDecimal repaymentDepositCurrency) {
        this.repaymentDepositCurrency = repaymentDepositCurrency;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public Date getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(Date tradeDate) {
        this.tradeDate = tradeDate;
    }

    public Date getValuedDate() {
        return valuedDate;
    }

    public void setValuedDate(Date valuedDate) {
        this.valuedDate = valuedDate;
    }

    public BigDecimal getPrincipalPlusInterest() {
        return principalPlusInterest;
    }

    public void setPrincipalPlusInterest(BigDecimal principalPlusInterest) {
        this.principalPlusInterest = principalPlusInterest;
    }

    public String getTermCode() {
        return termCode;
    }

    public void setTermCode(String termCode) {
        this.termCode = termCode;
    }

    public String getOdClass() {
        return odClass;
    }

    public void setOdClass(String odClass) {
        this.odClass = odClass;
    }

	public String getSpecialInstruction() {
		return specialInstruction;
	}

	public void setSpecialInstruction(String specialInstruction) {
		this.specialInstruction = specialInstruction;
	}
	/*public String getWealthproIndicator() {
		return wealthproIndicator;
	}

	public void setWealthproIndicator(String wealthproIndicator) {
		this.wealthproIndicator = wealthproIndicator;
	}

	public String getWealthproODAccNo() {
		return wealthproODAccNo;
	}

	public void setWealthproODAccNo(String wealthproODAccNo) {
		this.wealthproODAccNo = wealthproODAccNo;
	}*/

    public String getCurrentBalanceStr() {
        return String.valueOf(getCurrentBalance());
    }

    public void setCurrentBalanceStr(String currentBalanceStr) {
        this.currentBalanceStr = currentBalanceStr;
    }
}