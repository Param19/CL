package com.sc.rdc.csl.ss.dal.in.service;

import java.util.Date;

import com.sc.csl.retail.core.log.LogTimeTaken;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.helper.CommonHelper;
import com.sc.rdc.csl.ss.common.helper.MailConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import com.sc.rdc.csl.ss.dal.in.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.in.dao.MailServiceDao;
import com.sc.rdc.csl.ss.dal.in.entity.MailServiceEntity;
import com.webmethods.jms.log.Log;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service(value = "mailBoxServiceIN")
public class MailBoxService extends MailService {

    @Qualifier("mailServiceDaoIn")
    @Autowired
    private MailServiceDao mailServiceDao;

    @Qualifier("dozerBeanMapperIn")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    @Qualifier("customerServiceDaoIn")
    @Autowired
    private CustomerServiceDao customerServiceDao;

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;


    @Transactional("transactionManagerIn")
    @Override
    @LogTimeTaken
    public SsBaseDto submitMailData(MailServiceEntityDto mailServiceEntityDto, SsCSLUser user) {

        Integer mailId = mailServiceDao.getNextSequence();
        String messageReceiverId = customerServiceDao.getCustomerEBID(user.getCustomerId());

        Log.info("messageReceiverId:"+messageReceiverId);
        MailServiceEntity mailServiceEntityVO = dozerBeanMapper.map(mailServiceEntityDto, MailServiceEntity.class);

        if(messageReceiverId !=null) {
           if(StringUtils.isBlank(mailServiceEntityDto.getMessageReceiverId())){
        	   mailServiceEntityVO.setMessageReceiverId(messageReceiverId);
           }
            if(StringUtils.isBlank(mailServiceEntityVO.getMessageSenderId())){
            	mailServiceEntityVO.setMessageSenderId(messageReceiverId);
            }
        }

        mailServiceEntityVO.setMessageBody(CommonHelper.decodeBase64Value(mailServiceEntityVO.getMessageBody()));
        mailServiceEntityVO.setMessageSubject(CommonHelper.decodeBase64Value(mailServiceEntityVO.getMessageSubject()));
        mailServiceEntityVO.setMessageId(mailId.longValue());
        mailServiceEntityVO.setMessageMasterId(mailId.longValue());
        mailServiceEntityVO.setuUid(String.valueOf(mailId));

        Date currentDateTime = new Date();

        mailServiceEntityVO.setMessageStatusDate(currentDateTime);
        mailServiceEntityVO.setDateCreated(currentDateTime);
        mailServiceEntityVO.setDateRepliedByBO(currentDateTime);
        mailServiceEntityVO.setDateDeletedByBO(currentDateTime);
        mailServiceEntityVO.setMessageStatusDateByBO(currentDateTime);
        
        if (StringUtils.isBlank(mailServiceEntityVO.getMessageReceiverAddressType())) {
        	mailServiceEntityVO.setMessageReceiverAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_GENERAL);
        }

        mailServiceEntityVO.setIsDeletedByCustomer(Boolean.FALSE);
        mailServiceEntityVO.setIsRepliedByBO(Boolean.FALSE);
        mailServiceEntityVO.setIsDeletedByBO(Boolean.FALSE);

        if(StringUtils.isBlank(mailServiceEntityVO.getMessageSenderAddressType()) ){
        	mailServiceEntityVO.setMessageSenderAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_STANDARD_CHARTERED_BANK);
        }
        mailServiceEntityVO.setReferenceNumber(cslRequestContext.getRequestId());
        mailServiceEntityVO.setMessageStatusByBO(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailServiceEntityVO.setMessageStatus(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailServiceDao.insertMailData(mailServiceEntityVO);
        mailServiceEntityDto.setStatusDescription(MailConstant.STATUS);
        mailServiceEntityDto.setStatusCode(MailConstant.STATUS_CODE);
        return mailServiceEntityDto;

    }
}
