package com.sc.rdc.csl.ss.dal.sg.entity;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import com.sc.rdc.csl.ss.common.dto.SsConstant;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class AccountEntity extends BaseDto {

    private static final long serialVersionUID = -1L;

    private BigDecimal localCurrentBalance;
    private BigDecimal localAvailableBalance;

    private BigDecimal principal;
    private String term;
    private BigDecimal interestRate;
    private Date issueDate;
    private Date currentMaturityDate;
    private BigDecimal interestAtMaturity;

    private Date tradeDate;
    private Date valuedDate;
    private String alternateCurrency;
    private BigDecimal conversionRate;
    private Date fixingDate;
    private BigDecimal fixingRate;
    private BigDecimal repaymentDepositCurrency;
    private BigDecimal repaymentAlternateCurrency;

    private String issueNumber;
    private String issueDescription;
    private BigDecimal currentFaceAmount;
    private BigDecimal availableFaceAmount;
    private BigDecimal marketPrice;
    private BigDecimal currentMarketValue;
    private BigDecimal availableMarketValue;
    // Extra
    private BigDecimal principalPlusInterest;

    //for Account Details
    private String interestDisposalCode;
    private String principalDisposalCode;
    private String specialInstruction;
    private String termCode;
    private Date accountOpeningDate;

    private String odClass;

    //Added for CBIS Changes GetDepositTrancheDetails (FD Services)
    private String smcdFlag;
    private String trancheID;
    private String trancheDesc;
    private String couponPaymentFrequencey;
    private String fundsAccountNumber;
    private String maturityDate;
    private String branchName;

    private Date accountOpenDate;

    private String accountShortNameNonEnglish; // account name from host (in zh)


    private String fundsCurrencyCode;
    private String fundsProductCode;

    // payment
    private String accountTitle;


    // Properties from ProductEntity

    private Integer index;
    private String customerId;
    private String customerIdType;
    private String productCode;
    private String subProductCode;
    private String accountNumber;
    private String accountName;
    private String accountDescription;
    private String consolidatedCode;

    private String accountStatus;
    private String accountStatusDesc;
    private String blockCode;
    private String relationshipCode;

    private String currencyCode;
    private BigDecimal currentBalance;
    private BigDecimal availableBalance;

    private Integer customOrder = SsConstant.DEFAULT_ORDER;
    private Integer productOrder = SsConstant.DEFAULT_ORDER;


    private boolean isFullInfo;
    private Date hostUpdatedDate; // For online updated date
    private boolean isOnline;	// is from online or 24x7

    private boolean isValidStatus;

    //Code added for CBIS
    private String dealTypeCode;
    private String masterNo;
    private String branchCode;
    private String segmentCode;
    private Date lastUpdatedDate;

    private String kidFlag;
    private String ibFlag;
    private String riskCode;

    private com.sc.rdc.csl.ss.dal.cn.entity.FilterProductEntity filterProductEntity;

}