package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerPersonalizedSettingsEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.DeviceGroupEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.PersonalizedSettingsEntity;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.persistence.Query;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

@Service(value="personalizedSettingsDaoHk")
@Slf4j
public class PersonalizedSettingsDao extends BaseDao {
    
    public static final String DEVICE_CHANNEL_IBNK = "0";
    
    @SuppressWarnings("unchecked")
    public List<PersonalizedSettingsEntity> getPersonalizedAccountSummary(String customerEBID)  {
		StringBuilder queryString = new StringBuilder();
		queryString.append(" select ps, dg from com.sc.rdc.csl.ss.dal.hk.entity.customer.PersonalizedSettingsEntity ps, ");
		queryString.append(" com.sc.rdc.csl.ss.dal.hk.entity.customer.DeviceGroupEntity dg ");
		queryString.append(" where ps.customerEBID = :customerEBID ");
		queryString.append(" and ps.settingId = dg.settingId ");
		queryString.append(" and dg.deviceChannel = :deviceChannel ");
		queryString.append(" order by ps.orderNumber ");
        Query query = entityManagerHk.createQuery(queryString.toString());
        query.setParameter("customerEBID", customerEBID);
        query.setParameter("deviceChannel", DEVICE_CHANNEL_IBNK);	

        List rawList = query.getResultList();
        if (CollectionUtils.isNotEmpty(rawList)) {
        	List<PersonalizedSettingsEntity> personalizedSettingsList = new ArrayList<>();
        	Iterator it = rawList.iterator();
        	while (it.hasNext()) {
        		Object[] obj = (Object[]) it.next();
        		PersonalizedSettingsEntity pVO = (PersonalizedSettingsEntity) obj[0];
        		DeviceGroupEntity deviceGroupVO = (DeviceGroupEntity) obj[1];
        		// set deviceGroupVO into personalized settings vo
        		if (deviceGroupVO != null) {
        			Set deviceGroupSet = new HashSet();
        			deviceGroupSet.add(deviceGroupVO);
        			pVO.setDeviceGroupList(deviceGroupSet);
        		}
         		personalizedSettingsList.add(pVO);
        	}
        	
        	return personalizedSettingsList;
        }
        return null;
    }

    /*This method will use to get Customer Current&Default language*/
    public CustomerPersonalizedSettingsEntity getCustomerPersonalizedSummary(String customerEBID)  {
        StringBuilder queryString = new StringBuilder();
		queryString.append(" select cps from com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerPersonalizedSettingsEntity cps, ");
		queryString.append(" com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerEntity ce ");
		queryString.append(" where ce.customerEBID = :customerEBID and cps.customerProfileId = ce.customerSequenceNo ");
		Query query = entityManagerHk.createQuery(queryString.toString());
		query.setParameter("customerEBID", customerEBID);
		List<CustomerPersonalizedSettingsEntity> customerPersonalizedSettingsList = query.getResultList();
		CustomerPersonalizedSettingsEntity customerPersonalizedSettings = null;
		if (!customerPersonalizedSettingsList.isEmpty()) {
			customerPersonalizedSettings = customerPersonalizedSettingsList.get(0);
		}
		return customerPersonalizedSettings;
	}
}
