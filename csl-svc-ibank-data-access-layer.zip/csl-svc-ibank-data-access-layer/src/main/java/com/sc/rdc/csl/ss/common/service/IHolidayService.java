
package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.holiday.HolidayDto;
import java.util.List;

public abstract class IHolidayService {
    public List<HolidayDto> getHolidaySummary() {
        return null;
    }
}
