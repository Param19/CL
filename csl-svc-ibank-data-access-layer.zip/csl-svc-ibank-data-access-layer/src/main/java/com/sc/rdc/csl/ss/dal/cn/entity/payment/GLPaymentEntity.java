package com.sc.rdc.csl.ss.dal.cn.entity.payment;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by 1493439 on 11/14/2017.
 */
@Data
public class GLPaymentEntity extends BaseDto {

    private static final long serialVersionUID = 1L;

    private String id;
    private String processId;
    private String customerEBID;
    private String objectData;
    private String status;
    private String customerId;
    private String customerIdType;
    private String applicationType;
    private String productCode;
    private String fulfillmentStatus;
    private String lastPrintedBy;
    private Date firstPrintedDate;
    private Date lastPrintedDate;
    private Integer printCount;
    private Integer pageCount;
    private String lastPrintedStatus;
    private String lastViewedBy;
    private Date lastViewedDate;
    private String rejectedReason;
    private String reprintFlag;
    private String transactionId;
    private Integer serialNo;
    private String sessionId;
    private String channelCode;
    private String ackMessageCode;
    private String newObjectData;
    private String additionalInfo;
    private String countryCode;
    private String appLanguage;
    private String lastUpdatedBy;
}