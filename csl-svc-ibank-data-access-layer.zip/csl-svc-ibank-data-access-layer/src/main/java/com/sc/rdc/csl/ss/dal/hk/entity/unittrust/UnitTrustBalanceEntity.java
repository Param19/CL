package com.sc.rdc.csl.ss.dal.hk.entity.unittrust;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class UnitTrustBalanceEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private String accountNumber;
    private String currencyCode;
    private String relId;
    private BigDecimal availableBalance;
    private Long id;
    private String productCode;
    private String subProductCode;
}
