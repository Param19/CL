package com.sc.rdc.csl.ss.main.config;

import com.sc.csl.retail.core.config.BaseJaxrsConfig;
import com.sc.rdc.csl.ss.main.endpoint.PersonalizedSettingsEndpoint;
import com.sc.rdc.csl.ss.main.endpoint.ProductEndpoint;
import com.sc.rdc.csl.ss.main.endpoint.WealthLendingEndpoint;
import com.sc.rdc.csl.ss.main.helper.UserParameterConverter;

import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;


@Configuration
public class SsJaxRsConfig extends BaseJaxrsConfig {

    @Override
    public void configureEndpoint(JAXRSServerFactoryBean endpoint) {
        endpoint.setAddress("/");
        endpoint.setProvider(userParameterConverter);
        endpoint.setServiceBeans(Arrays.asList(
                wealthLendingEndpoint,
                personalizedSettingsEndpoint,
                productEndpoint
        ));
    }

    @Autowired
    private WealthLendingEndpoint wealthLendingEndpoint;

    @Autowired
    private ProductEndpoint productEndpoint;

    @Autowired
    private UserParameterConverter userParameterConverter;

    @Autowired
    private PersonalizedSettingsEndpoint personalizedSettingsEndpoint;
    


}
