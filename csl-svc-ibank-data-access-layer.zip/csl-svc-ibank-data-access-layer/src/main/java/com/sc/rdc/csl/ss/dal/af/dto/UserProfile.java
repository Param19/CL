package com.sc.rdc.csl.ss.dal.af.dto;

import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import lombok.Data;

@Data
public class UserProfile extends Profile
{
    private String preferredLogin;
}