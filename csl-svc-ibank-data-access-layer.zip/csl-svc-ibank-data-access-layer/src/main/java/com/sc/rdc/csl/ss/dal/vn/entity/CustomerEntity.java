package com.sc.rdc.csl.ss.dal.vn.entity;

import lombok.Data;

@Data
public class CustomerEntity {
	
	private UserInfoEntity userInfo;
	private UserStatEntity userStat;
	
	public CustomerEntity(UserInfoEntity userInfo, UserStatEntity userStat) {
		this.userInfo = userInfo;
		this.userStat = userStat;
	}

	public CustomerEntity() {
		// TODO Auto-generated constructor stub
	}

	
}
