package com.sc.rdc.csl.ss.dal.vn.config;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sc.rdc.csl.ss.common.dto.audit.Audit;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.dal.vn.entity.AuditEntity;
import com.sc.rdc.csl.ss.dal.vn.entity.CustomerEntity;

import lombok.extern.slf4j.Slf4j;

@Component("dozerUtilsVN")
@Slf4j
public class DozerUtilsVN {

    @Qualifier("dozerBeanMapperVN")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;


    public Profile convertCustomer(Profile profile,CustomerEntity customerEntity,String mapId) {
        if (customerEntity == null || profile == null) {
            return null;
        }
        log.info("before convert the value :"+customerEntity);
        dozerBeanMapper.map(customerEntity, profile,"customer-profile");
        log.info("mapping files"+ dozerBeanMapper.map(customerEntity, Profile.class));
        log.info("after convert the value :"+profile);
        return profile;
    }
    
    public AuditEntity convertCustomer(Audit audit,AuditEntity auditEntity,String mapId) {
        if (auditEntity == null || audit == null) {
            return null;
        }
        log.info("before convert the value :"+audit);
        dozerBeanMapper.map(audit, auditEntity,mapId);
        log.info("after convert the value :"+auditEntity);
        return auditEntity;
    }


}
