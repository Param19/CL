package com.sc.rdc.csl.ss.dal.pk.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.dal.pk.entity.customer.CustomerDetailEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION;

@Repository(value = "custDetailDaoPk")
@Slf4j
public class CustDetailDao extends BaseDao {

    public static String GET_CUSTOMER_DETAIL = "select  o from com.sc.rdc.csl.ss.dal.pk.entity.customer.CustomerDetailEntity o WHERE o.customerId = :customerId ";

    public CustomerDetailEntity getCustomerDetails(String customerId) {

        log.info("CustomerId:{}", customerId);
        Query query = entityManagerPk.createQuery(GET_CUSTOMER_DETAIL);
        query.setParameter("customerId", customerId);
        CustomerDetailEntity custDetailEntity = (CustomerDetailEntity)query.getSingleResult();
        log.info("customerdetails Record", custDetailEntity);
       if(custDetailEntity == null)
        {
            throw new BusinessException(CUSTOMER_NO_RECORD_EXCEPTION);
        }

        return custDetailEntity;
    }


}
