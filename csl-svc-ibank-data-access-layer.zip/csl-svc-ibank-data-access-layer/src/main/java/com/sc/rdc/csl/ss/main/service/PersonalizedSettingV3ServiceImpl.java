package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsV3Summary;
import com.sc.rdc.csl.ss.common.service.PersonalizedSettingV3Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("personalizedSettingV3ServiceImpl")
@Slf4j
public class PersonalizedSettingV3ServiceImpl extends PersonalizedSettingV3Service {

    @Autowired
    private PersonalizedSettingsV3Factory personalizedSettingsV3Factory;

    @Override
    public PersonalizedSettingsV3Summary getPersonalizedAccountSummary(PersonalizedSettingsV3Summary personalizedSettingsV3Summary) {
        PersonalizedSettingsV3Summary personalizedSettingsV3Summarydto = personalizedSettingsV3Factory.getPersonalizedAccountSummary(personalizedSettingsV3Summary.getCountryCode()).getPersonalizedAccountSummary(personalizedSettingsV3Summary);
        return personalizedSettingsV3Summarydto;
    }

}
