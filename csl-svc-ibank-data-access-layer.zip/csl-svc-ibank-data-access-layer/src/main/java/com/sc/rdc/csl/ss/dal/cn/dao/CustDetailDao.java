package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.dal.cn.entity.customer.CustomerDetailEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION;

@Repository(value = "custDetailDaoCn")
@Slf4j
public class CustDetailDao extends BaseDao {

    public static String GET_CUSTOMER_DETAIL = "select  o from com.sc.rdc.csl.ss.dal.cn.entity.customer.CustomerDetailEntity o WHERE o.customerId = :customerId ";

    public static String GET_CUSTOMER_PROFILE = "select  o from com.sc.rdc.csl.ss.dal.cn.entity.customer.CustomerDetailEntity o WHERE o.customerId = :customerId ";

    public String getCustomerEBID(String customerId) {
     
        log.info("CustomerId:", customerId);
        Query query = entityManagerCn.createQuery(GET_CUSTOMER_DETAIL);
        query.setParameter("customerId", customerId);
        List<CustomerDetailEntity> customerdetails = query.getResultList();
        String messageSenderId =null;
        log.info("customerdetails Record", customerdetails.size());
       if(customerdetails!=null && customerdetails.size()>0)
        {
            CustomerDetailEntity cardCustEntity = (CustomerDetailEntity)customerdetails.get(0);
            messageSenderId = cardCustEntity.getCustomerEBID();
        }
        else {
            throw new BusinessException(CUSTOMER_NO_RECORD_EXCEPTION);
        }
        return messageSenderId;
    }

    public CustomerDetailEntity getCustomerProfile(String custId) {
        log.info("CustomerServiceDao:getCustomerProfile,{}", custId);
        Query query = entityManagerCn.createQuery(GET_CUSTOMER_PROFILE);
        query.setParameter("customerId", custId);
        CustomerDetailEntity profile = (CustomerDetailEntity) query.getSingleResult();
        log.info("Received getCustomerProfile from DB:" + profile);
        return profile;
    }

}
