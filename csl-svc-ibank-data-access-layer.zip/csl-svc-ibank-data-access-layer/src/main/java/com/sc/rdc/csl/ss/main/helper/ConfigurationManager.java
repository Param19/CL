package com.sc.rdc.csl.ss.main.helper;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ConfigurationManager {

    private static Map<String, Properties> propertiesHolder = new HashMap<String, Properties>();

    public static String getProperty(String config, String key) {
        return getProperties(config).getProperty(key);
    }

    private static Properties getProperties(String config) {

        Properties properties = propertiesHolder.get(config);

        if (properties == null) {
            properties = new Properties();

            try {
                File file = new ClassPathResource("config/business-errormap.properties").getFile();
                properties.load(new FileInputStream(file));
            } catch (Exception e) {
                log.error("Unable to load configuration [" + config + "].", e);
                throw new RuntimeException("Unable to load configuration [" + config + "].", e);
            }

            propertiesHolder.put(config, properties);
        }
        return properties;
    }

}
