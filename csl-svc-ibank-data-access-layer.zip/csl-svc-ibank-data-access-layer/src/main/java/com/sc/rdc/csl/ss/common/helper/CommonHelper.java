package com.sc.rdc.csl.ss.common.helper;

import java.io.UnsupportedEncodingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;

@Slf4j
public class CommonHelper {

    public static final String UTF_8 = "UTF-8";

    public static String decodeBase64Value(String strValue) {
        try {
            if (strValue != null) {
                  strValue = new String(Base64.decodeBase64(strValue.getBytes(UTF_8)), UTF_8);
            }
        } catch (UnsupportedEncodingException ex) {
            log.error("Error :", ex);
        }
        return strValue;
    }

    public static String encodeBase64Value(String value) {
        String decodeValue = null;
        try {
            if (value != null) {
                decodeValue = new String(Base64.encodeBase64(value.getBytes(UTF_8)), UTF_8);
            }
        } catch (UnsupportedEncodingException ex) {
            log.error("Error :", ex);
        }
        return decodeValue;
    }
}
