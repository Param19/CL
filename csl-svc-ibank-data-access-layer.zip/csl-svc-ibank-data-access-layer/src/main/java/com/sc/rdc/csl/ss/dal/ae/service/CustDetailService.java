package com.sc.rdc.csl.ss.dal.ae.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import com.sc.rdc.csl.ss.dal.ae.dao.CustDetailDao;
import com.sc.rdc.csl.ss.dal.ae.dao.ReferenceDao;
import com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service(value = "custDetailServiceAE")
public class CustDetailService extends CustomerDetailService {

    @Qualifier("custDetailDaoAe")
    @Autowired
    private CustDetailDao CustDetailDao;

    @Qualifier("referenceDetailsDaoAe")
    @Autowired
    private ReferenceDao referenceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Transactional(value = "transactionManagerAe", readOnly = true)
    @LogTimeTaken
    public CustomerDetailDto getCustomerDetail(CustomerDetailDto custDetailDto) {

        CustomerVO customerDetailEntity = CustDetailDao.getCustomerDetails(custDetailDto.getRellId());
        return orikaMapperFacade.map(customerDetailEntity,CustomerDetailDto.class);

       /* ReferenceEntity referenceEntity = referenceDao.getReferenceDetails("SEGMENT_CD", custDetailDto.getSegmentcode());
        ReferenceDto referenceDto = orikaMapperFacade.map(referenceEntity,ReferenceDto.class);
        custDetailDto.setCountry(cslRequestContext.getCountry());

        if(referenceDto!=null && StringUtils.isNotEmpty(referenceDto.getValue())
                && "SME".equalsIgnoreCase(referenceDto.getValue())){

            custDetailDto.setSmeFlag("true");

        } else {
            custDetailDto.setSmeFlag("false");
        }*/


    }
}