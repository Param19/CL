package com.sc.rdc.csl.ss.dal.hk.dao.holiday;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.hk.dao.BaseDao;
import com.sc.rdc.csl.ss.dal.hk.entity.holiday.HolidayEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

@Repository(value ="holidayServiceDaoHk")
@Slf4j
public class HolidayServiceDao extends BaseDao{

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<HolidayEntity> getHolidaySummary() {
        log.info("HolidayServiceDao:getHolidaySummary,{}");
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.holiday.HolidayEntity a");
        List<HolidayEntity> hEntityList = query.getResultList();
        log.info("Received {} HolidaySummary record(s) from DB for country {}",
                (hEntityList != null ? hEntityList.size() : 0), requestContext.getCountry());
        if(!(hEntityList != null && !hEntityList.isEmpty())) {
            throw new BusinessException(ErrorConstant.HOLIDAY_LIST_NOT_FOUND_FOR_COUNTRY);
        }
        return hEntityList;
    }
}
