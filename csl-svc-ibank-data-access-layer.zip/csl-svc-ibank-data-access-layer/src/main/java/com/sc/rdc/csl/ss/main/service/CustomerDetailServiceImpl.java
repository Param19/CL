package com.sc.rdc.csl.ss.main.service;


import com.sc.rdc.csl.ss.common.dto.customer.CustomerContact;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("customerDetailServiceImpl")
@Slf4j
public class CustomerDetailServiceImpl extends CustomerDetailService {


    @Autowired
    private CustomerDetailFactory customerDetailFactory;


    @Override
    public CustomerDetailDto getCustomerDetail(CustomerDetailDto custDetailDto) {

        CustomerDetailDto customerDetail_data = customerDetailFactory.getCustomerDetail(custDetailDto.getCountryCode()).getCustomerDetail(custDetailDto);
        return customerDetail_data;
    }

    @Override
    public CustomerContact getCustomerContact(String countryCode,String customerId) {
        return customerDetailFactory.getCustomerDetail(countryCode).getCustomerContact(countryCode,customerId);
    }
}