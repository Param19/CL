package com.sc.rdc.csl.ss.dal.ae.dao;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;

@Repository(value = "customerServiceDaoAe")
@Slf4j
public class CustomerServiceDao extends BaseDao {

    @Autowired
    private CSLRequestContext cslRequestContext;

	 public CustomerVO getCustomerProfile() {
	        log.info("CustomerServiceDao:getCustomerProfile");
	        TypedQuery<CustomerVO> query = entityManagerAe.createQuery("select a from com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO a WHERE a.customerId = :customerId and a.statusCode = :statusCode and a.countryCode =:countryCode", CustomerVO.class);
	        query.setParameter("customerId", cslRequestContext.getCustomerId());
	        query.setParameter("statusCode", Constants.STATUS_CD);
	        query.setParameter("countryCode", cslRequestContext.getCountry());
	        CustomerVO customerVO = query.getSingleResult();
	        log.info("Received getCustomerProfile from DB:" + customerVO);
	        return customerVO;
	    }
}
