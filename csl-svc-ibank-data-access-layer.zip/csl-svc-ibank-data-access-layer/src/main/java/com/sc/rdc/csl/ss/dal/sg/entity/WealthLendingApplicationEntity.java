package com.sc.rdc.csl.ss.dal.sg.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.math.BigDecimal;
import java.util.Date;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class WealthLendingApplicationEntity extends SsBaseDto {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String customerId;
    private String customerIdType;
    private String custName;
    private String docType;
    private String docRefNo;
    private String occupation;
    private String addressLine1;
    private String addressLine2;
    private String addressLine3;
    private String sourceOfFund;
    private String purporseOfOverDraft;
    private String purposeOfOverDraftDesc;
    private BigDecimal preApprovedLimit;
    private String requiredSamePreApprovedFlag;
    private BigDecimal requestedWealthProLimit;
    private String idaCurrentAccount;
    private String idaSavingsAccount;
    private String debtSecAccount;
    private String utInvestmentAccount;
    private String pledgedSdAccountCollaterallFlag;
    private String receiptRefNo;
    private Date submissionDate;
    private String applicationStatus;
    private String depositPldgWealthProFlag;
    private String actionType;
    private String idaCurrentAccountCurrency;
    private String idaSavingsAccountCurrency;
    private String debtSecAccountCurrency;
    private String utInvestmentAccountCurrency;
    private String responseStatus;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerIdType() {
        return customerIdType;
    }

    public void setCustomerIdType(String customerIdType) {
        this.customerIdType = customerIdType;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getDocRefNo() {
        return docRefNo;
    }

    public void setDocRefNo(String docRefNo) {
        this.docRefNo = docRefNo;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getSourceOfFund() {
        return sourceOfFund;
    }

    public void setSourceOfFund(String sourceOfFund) {
        this.sourceOfFund = sourceOfFund;
    }

    public String getPurporseOfOverDraft() {
        return purporseOfOverDraft;
    }

    public void setPurporseOfOverDraft(String purporseOfOverDraft) {
        this.purporseOfOverDraft = purporseOfOverDraft;
    }

    public String getPurposeOfOverDraftDesc() {
        return purposeOfOverDraftDesc;
    }

    public void setPurposeOfOverDraftDesc(String purposeOfOverDraftDesc) {
        this.purposeOfOverDraftDesc = purposeOfOverDraftDesc;
    }

    public BigDecimal getPreApprovedLimit() {
        return preApprovedLimit;
    }

    public void setPreApprovedLimit(BigDecimal preApprovedLimit) {
        this.preApprovedLimit = preApprovedLimit;
    }

    public String getRequiredSamePreApprovedFlag() {
        return requiredSamePreApprovedFlag;
    }

    public void setRequiredSamePreApprovedFlag(String requiredSamePreApprovedFlag) {
        this.requiredSamePreApprovedFlag = requiredSamePreApprovedFlag;
    }

    public BigDecimal getRequestedWealthProLimit() {
        return requestedWealthProLimit;
    }

    public void setRequestedWealthProLimit(BigDecimal requestedWealthProLimit) {
        this.requestedWealthProLimit = requestedWealthProLimit;
    }

    public String getIdaCurrentAccount() {
        return idaCurrentAccount;
    }

    public void setIdaCurrentAccount(String idaCurrentAccount) {
        this.idaCurrentAccount = idaCurrentAccount;
    }

    public String getIdaSavingsAccount() {
        return idaSavingsAccount;
    }

    public void setIdaSavingsAccount(String idaSavingsAccount) {
        this.idaSavingsAccount = idaSavingsAccount;
    }

    public String getDebtSecAccount() {
        return debtSecAccount;
    }

    public void setDebtSecAccount(String debtSecAccount) {
        this.debtSecAccount = debtSecAccount;
    }

    public String getUtInvestmentAccount() {
        return utInvestmentAccount;
    }

    public void setUtInvestmentAccount(String utInvestmentAccount) {
        this.utInvestmentAccount = utInvestmentAccount;
    }

    public String getPledgedSdAccountCollaterallFlag() {
        return pledgedSdAccountCollaterallFlag;
    }

    public void setPledgedSdAccountCollaterallFlag(
            String pledgedSdAccountCollaterallFlag) {
        this.pledgedSdAccountCollaterallFlag = pledgedSdAccountCollaterallFlag;
    }

    public String getReceiptRefNo() {
        return receiptRefNo;
    }

    public void setReceiptRefNo(String receiptRefNo) {
        this.receiptRefNo = receiptRefNo;
    }

    public Date getSubmissionDate() {
        return submissionDate;
    }

    public void setSubmissionDate(Date submissionDate) {
        this.submissionDate = submissionDate;
    }

    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }

    public String getDepositPldgWealthProFlag() {
        return depositPldgWealthProFlag;
    }

    public void setDepositPldgWealthProFlag(String depositPldgWealthProFlag) {
        this.depositPldgWealthProFlag = depositPldgWealthProFlag;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getIdaCurrentAccountCurrency() {
        return idaCurrentAccountCurrency;
    }

    public void setIdaCurrentAccountCurrency(String idaCurrentAccountCurrency) {
        this.idaCurrentAccountCurrency = idaCurrentAccountCurrency;
    }

    public String getIdaSavingsAccountCurrency() {
        return idaSavingsAccountCurrency;
    }

    public void setIdaSavingsAccountCurrency(String idaSavingsAccountCurrency) {
        this.idaSavingsAccountCurrency = idaSavingsAccountCurrency;
    }

    public String getDebtSecAccountCurrency() {
        return debtSecAccountCurrency;
    }

    public void setDebtSecAccountCurrency(String debtSecAccountCurrency) {
        this.debtSecAccountCurrency = debtSecAccountCurrency;
    }

    public String getUtInvestmentAccountCurrency() {
        return utInvestmentAccountCurrency;
    }

    public void setUtInvestmentAccountCurrency(String utInvestmentAccountCurrency) {
        this.utInvestmentAccountCurrency = utInvestmentAccountCurrency;
    }

    public String getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
