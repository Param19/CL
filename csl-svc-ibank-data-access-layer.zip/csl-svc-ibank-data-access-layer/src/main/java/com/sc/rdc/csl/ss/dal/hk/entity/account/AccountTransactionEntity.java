package com.sc.rdc.csl.ss.dal.hk.entity.account;

import com.sc.rdc.csl.ss.common.dto.BaseDto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
public class AccountTransactionEntity extends BaseDto {
    private static final long serialVersionUID = -1L;
    private String transactionApprovalSequenceNumber;
    private String creditDebitTransactionIndicator;
    private String transactionAmount;
    private String transactionCurrencyCode;
    private Date transactionEffectiveDate;
    private String transactionDescription;
    private String accountNo;
    private Long id;
}


