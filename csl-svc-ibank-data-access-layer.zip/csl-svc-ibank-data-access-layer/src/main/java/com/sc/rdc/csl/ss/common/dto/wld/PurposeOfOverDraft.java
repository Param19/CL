package com.sc.rdc.csl.ss.common.dto.wld;


public enum PurposeOfOverDraft {

    PN("PN"),
    LQ("LQ"),
    GP("GP"),
    OT("OT");

    private String type;

    private PurposeOfOverDraft() {
    }

    private PurposeOfOverDraft(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return type;
    }

}
