package com.sc.rdc.csl.ss.dal.cn.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICustomerService;
import com.sc.rdc.csl.ss.dal.cn.dao.CustDetailDao;
import com.sc.rdc.csl.ss.dal.cn.entity.customer.CustomerDetailEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Slf4j
@Service("customerServiceCn")
public class CustomerService extends ICustomerService {

    @Autowired
    @Qualifier("custDetailDaoCn")
    private CustDetailDao custDetailDao;

    @Autowired
    private MapperFacade orikaMapper;

    @Autowired
    private CSLRequestContext cslRequestContext;

    public CustomerDetailDto getCustomerProfile() {
        CustomerDetailDto customer;

        try {
            CustomerDetailEntity customerDetailEntity = custDetailDao.getCustomerProfile(cslRequestContext.getCustomerId());
            if(customerDetailEntity == null){
                throw new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION);
            }
            customer = orikaMapper.map(customerDetailEntity, CustomerDetailDto.class);
            customer.setStatusCode(SsConstant.SS_SUCCESS_STATUS);
        } catch (Exception e) {
            log.error("Exception while fetching Customerprofile {} , {} ", cslRequestContext.getCustomerId(), e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_CUSTOMER);
        }
        return customer;
    }

}