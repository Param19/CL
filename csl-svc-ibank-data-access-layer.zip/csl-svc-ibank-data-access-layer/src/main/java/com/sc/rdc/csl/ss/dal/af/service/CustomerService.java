package com.sc.rdc.csl.ss.dal.af.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerProfile;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICustomerService;
import com.sc.rdc.csl.ss.dal.af.config.DozerUtilsAf;
import com.sc.rdc.csl.ss.dal.af.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.af.entity.CustomerVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Service(value = "customerServiceAf")
public class CustomerService extends ICustomerService {
    @Autowired
    @Qualifier("dozerUtilsAf")
    private DozerUtilsAf dozerUtilsAf;

    @Qualifier("customerServiceDaoAf")
    @Autowired
    private CustomerServiceDao customerServiceDao;

    @Transactional(value = "transactionManagerAf", readOnly = true)
    @LogTimeTaken
    public CustomerProfile getCustomerProfile(SsCSLUser user){
        CustomerProfile customer = new CustomerProfile();
        try {
            Optional<CustomerVO> customerEntity = Optional.ofNullable(customerServiceDao.getCustomerProfile(user));
            customerEntity.orElseThrow(() -> new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION));

            Profile profile = dozerUtilsAf.convertCustomer(new Profile(), customerEntity.get(),"customer-profile");
            log.info("profile after mapping :"+profile);
            customer.setStatusCode(SsConstant.SS_SUCCESS_STATUS);
            customer.setProfile(profile);
        } catch (Exception e) {
            log.info("exception details "+e.getMessage());
            if(e instanceof BusinessException)
                throw e;
            if(e instanceof EmptyResultDataAccessException)
                throw new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION);
            else{
                log.error("Exception while fetching Customerprofile {} , {} ", user.getCustomerId(), e.getMessage());
                throw new TechnicalException(ErrorConstant.ERR_FETCHING_CUSTOMER);
            }
        }
        return customer;
    }
}
