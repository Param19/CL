package com.sc.rdc.csl.ss.dal.cn.entity.payment;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.math.BigDecimal;
import java.sql.Timestamp;

/**
 * Created by 1493439 on 9/22/2017.
 */
@Data
public class ScheduledTransactionsSafeEntity extends BaseDto {

    private Long id;
    private String transactionId;
    private String nof;
    private String additionalNof1;
    private String additionalNof2;
    private String additionalNof3;
    private String additionalNof4;
    private String additionalNof5;
    private String bopCode;
    private String bopDesc;
    private String bopRemarks;
    private String remittanceInfo;
    private String estUsageDuration;
    private String fxpConsistent;
    private String safeReferenceNumber;
    private Timestamp safeQuoteRecordTimestamp;
    private String safeOrganizationCode;
    private String safeOperationId;
    private String customerFocusStatus;
    private String fxPurchaseRmbAccount;
    private String fxpDbtAccCur;
    private String fxpDbtAccName;
    private String fxPurchaseFcyAccount;
    private String fxpCdtAccCur;
    private String fxpCdtAccName;
    private String fxPurchaseTxCurrency;
    private BigDecimal fxPurchaseTXAmount;
    private BigDecimal safeExchangeRate;
    private BigDecimal safeUsdEquivalentAmount;
    private String safeNofCode;
    private String ebbsNofCode;
}
