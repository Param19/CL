package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.util.CSLAssert;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import com.sc.rdc.csl.ss.main.service.PaymentServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.*;

@Slf4j
@Component
public class PaymentEndpoint extends ResourceRepositoryBase<PaymentDto, String> {

    @Autowired
    private PaymentServiceImpl paymentService;

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    protected PaymentEndpoint() {
        super(PaymentDto.class);
    }

    @Override
    public PaymentDto save(PaymentDto paymentDto) {
        validateHeader();
        return paymentService.submitPayment(paymentDto, cslRequestContext.getCountry());
    }

    @Override
    public PaymentDto create(PaymentDto paymentDto) {
        CSLAssert.notNull(paymentDto, SS_EMPTY_PAYMENT);
        CSLAssert.hasLength(paymentDto.getTransactionId(), SS_NO_TRANSACTIONID);
        log.info(" Payment Data {}", paymentDto);
        if(paymentDto.isUpdate()) {
        	log.info("Update called");
            return update(paymentDto);
        } else {
        	log.info("Create called");
            return save(paymentDto);
        }
    }

    private PaymentDto update(PaymentDto paymentDto) {
        CSLAssert.hasLength(paymentDto.getCountryCode(), CASA_NO_COUNTRY);
        return paymentService.updatePayment(paymentDto, paymentDto.getCountryCode());
    }

    @Override
    public PaymentDto findOne(String transactionId, QuerySpec querySpec) {
        CSLAssert.notNull(cslRequestContext, CASA_NO_HEADER);
        CSLAssert.hasLength(cslRequestContext.getCountry(), CASA_NO_COUNTRY);
        CSLAssert.hasLength(transactionId, SS_NO_TRANSACTIONID);
        return paymentService.getPayment(transactionId, cslRequestContext.getCountry());
    }

    private void validateHeader() {
        CSLAssert.notNull(cslRequestContext, CASA_NO_HEADER);
        CSLAssert.notNull(cslRequestContext.getCustomerId(), CASA_NO_HEADER);
        CSLAssert.hasLength(cslRequestContext.getRelId(), CASA_NO_RELID);
    }

    @Override
    public ResourceList<PaymentDto> findAll(QuerySpec querySpec) {
        throw new UnsupportedOperationException();
    }
}