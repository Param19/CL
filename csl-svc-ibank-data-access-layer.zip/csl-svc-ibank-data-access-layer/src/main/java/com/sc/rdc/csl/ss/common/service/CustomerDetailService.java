package com.sc.rdc.csl.ss.common.service;


import com.sc.rdc.csl.ss.common.dto.customer.CustomerContact;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;

public abstract  class CustomerDetailService {

    public CustomerDetailDto getCustomerDetail(CustomerDetailDto customerDetailDto) {
        return null;
    }

    public CustomerContact getCustomerContact(String countryCode,String relId) {
        return null;
    }

    public CustomerDetailDto getCustomerProfile() { return null; }
}