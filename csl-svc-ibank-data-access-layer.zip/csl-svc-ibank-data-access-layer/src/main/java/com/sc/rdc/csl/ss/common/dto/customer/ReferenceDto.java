package com.sc.rdc.csl.ss.common.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.UUID;

/**
 * Created by 1493439 on 10/25/2017.
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonApiResource(type = "payments")
public class ReferenceDto extends SsBaseDto {

    private static final long serialVersionUID = 1L;
    @JsonApiId
    private String uuid = UUID.randomUUID().toString();

    private Long id;
    private String countryCode;
    private String type;
    private String value;
    private String referenceCode;
    private String description;
    private int sequenceNo;
    private String statusCd;
    private String isDefault;
    private String isDisplay;
}