package com.sc.rdc.csl.ss.dal.hk.service.card;


import com.sc.rdc.csl.ss.common.dto.card.CardFaceDto;
import com.sc.rdc.csl.ss.common.service.IDcImageFaceService;
import com.sc.rdc.csl.ss.dal.hk.dao.card.DcImageFaceDao;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("dcImageFaceServiceHK")
@Slf4j
public class DcImageFaceServiceHK extends IDcImageFaceService {

    @Qualifier("dcImageFaceDaoHK")
    @Autowired
    private DcImageFaceDao dcImageFaceDao;

    @Override
    public List<CardFaceDto> getDcImageFaces(String segmentCd, String ctry) {
        log.info("getDcImageFaces {} {}", segmentCd);
        List<CardFaceDto> cardFaceDtos = null;
        try {
            cardFaceDtos = dcImageFaceDao.getEligibleCardTypes(segmentCd, ctry);
            log.info("size {}", CollectionUtils.size(cardFaceDtos));
        } catch (Exception e) {
            log.error("getDcImageFaces {}", e);
        }

        return cardFaceDtos;
    }


}