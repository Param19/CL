package com.sc.rdc.csl.ss.dal.ae.service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.helper.CommonHelper;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.helper.MailConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import com.sc.rdc.csl.ss.dal.ae.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.ae.dao.MailServiceDao;
import com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO;
import com.sc.rdc.csl.ss.dal.ae.entity.MailVO;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Slf4j
@Service(value = "mailBoxServiceAE")
public class MailBoxService extends MailService {

    @Qualifier("mailServiceDaoAe")
    @Autowired
    private MailServiceDao mailServiceDao;

    @Qualifier("customerServiceDaoAe")
    @Autowired
    private CustomerServiceDao customerServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Transactional("transactionManagerAe")
    @Override
    public SsBaseDto submitMailData(MailServiceEntityDto mailServiceEntityDto, SsCSLUser user) {

        log.info("Persisting Inbox message into Data base : {} : {}", cslRequestContext.getCountry(), mailServiceEntityDto.getReference());
        CustomerVO customerVO = customerServiceDao.getCustomerProfile();

        MailVO mailVO = orikaMapperFacade.map(mailServiceEntityDto, MailVO.class);

        mailVO.setMessageTo(customerVO.getCustomerEBID());
        mailVO.setMessageBody(CommonHelper.decodeBase64Value(mailVO.getMessageBody()));
        mailVO.setMessageFrom(Constants.SCB);
        mailVO.setMessageFromAddressType(Constants.ADDRESS_TYPE);
        mailVO.setMessageToAddressType(Constants.ADDRESS_TYPE);
        Date currentDateTime = new Date();
        mailVO.setMessageStatusDate(currentDateTime);
        mailVO.setDateRepliedByBO(currentDateTime);
        mailVO.setDateDeletedByBO(currentDateTime);
        mailVO.setMessageStatusDateByBO(currentDateTime);
        mailVO.setIsDeletedByCustomer(Boolean.FALSE);
        mailVO.setIsRepliedByBO(Boolean.FALSE);
        mailVO.setIsDeletedByBO(Boolean.FALSE);
        mailVO.setMessageStatus(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailVO.setMessageStatusByBO(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailVO.setCreatedDate(currentDateTime);
        mailVO.setCreatedBy(cslRequestContext.getCustomerId());
        mailVO.setUpdatedDate(currentDateTime);
        mailVO.setUpdatedBy(cslRequestContext.getCustomerId());
        mailVO.setCountryCode(cslRequestContext.getCountry());
        mailVO.setVersion(1L);
        mailVO.setMessageMasterId(customerVO.getCustomerEBID());
        mailVO.setUuid(cslRequestContext.getUaas2id());
        mailServiceDao.insertMailData(mailVO);

        mailServiceEntityDto.setStatusDescription(MailConstant.STATUS);
        mailServiceEntityDto.setStatusCode(MailConstant.STATUS_CODE);

        return mailServiceEntityDto;
    }
}
