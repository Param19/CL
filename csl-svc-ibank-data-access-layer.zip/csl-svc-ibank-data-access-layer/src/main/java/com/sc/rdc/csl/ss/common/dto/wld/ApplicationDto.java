package com.sc.rdc.csl.ss.common.dto.wld;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationDto extends SsBaseDto {

    private static final long serialVersionUID = 1L;
    private String relId;
    private Long id;
    private String customerId;
    private String customerIdType;
    private String custName;
    private DocumentType docType;
    private String docRefNo;
    private String occupation;
    private String addressLine1;
    private String addressLine2;
    private String addressLine3;
    private SourceOfFund sourceOfFund;
    private PurposeOfOverDraft purposeOfOverDraft;
    private String purposeOfOverDraftDesc;
    private String preApprovedLimit;
    private String requestedWealthProLimit;
    private String idaCurrentAccount;
    private String idaSavingsAccount;
    private String utInvestmentAccount;
    private String debtSecAccount;
    private BooleanFlag requiredSamePreApprovedFlag;
    private BooleanFlag pledgedSdAccountCollateralFlag;
    private String receiptRefNo;
    private Date submissionDate;
    private String applicationStatus;
    private BooleanFlag depositPldgWealthProFlag;
    private String actionType;
    private String idaCurrentAccountCurrency;
    private String idaSavingsAccountCurrency;
    private String debtSecAccountCurrency;
    private String utInvestmentAccountCurrency;
    private String responseStatus;

    public ApplicationDto addRequestId(String requestId) {
        return this;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
