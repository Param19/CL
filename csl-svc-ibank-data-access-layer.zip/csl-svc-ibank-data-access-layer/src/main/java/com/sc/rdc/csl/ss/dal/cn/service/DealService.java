package com.sc.rdc.csl.ss.dal.cn.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.DealInfo;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IDealService;
import com.sc.rdc.csl.ss.dal.cn.dao.DealServiceDao;
import com.sc.rdc.csl.ss.dal.cn.entity.account.DealInfoEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by 1347884 on 11/29/2017.
 */
@Slf4j
@Service("dealServiceCn")
public class DealService extends IDealService{

    @Autowired
    @Qualifier("dealServiceDaoCn")
    private DealServiceDao dealServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    @Override
    public List<DealInfo> getDealInfo() {

        List<DealInfo> dealInfoList = new ArrayList<DealInfo>();

        try{
            log.info("getDealInfo Called");
            Optional<List<DealInfoEntity>> dealInfoEntityList = Optional.ofNullable(dealServiceDao.getDealInfo());
            log.info("getDealInfo dealInfoEntityList : " + dealInfoEntityList);

            dealInfoEntityList.get().forEach(dealEntity -> {
                DealInfo dealListTmp = orikaMapperFacade.map(dealEntity, DealInfo.class);
                //TODO - TEMP Remove Later
                dealListTmp.setCountry("CN");
                dealInfoList.add(dealListTmp);
            });

            log.info("getDealInfo dealInfoList : " + dealInfoList);

        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Deal Information  , {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_DEAL);
        }

        return dealInfoList;
    }

}
