package com.sc.rdc.csl.ss.dal.hk.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.sc.rdc.csl.ss.common.helper.Constants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
public class EntityManagerConfigHk {

    @Primary
    @Bean(name = "entityManagerFactoryHk")
    public LocalContainerEntityManagerFactoryBean entityManagerFactoryHk(@Qualifier("db2DataSourceHk") DataSource db2DataSourceHk) {
        LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactory.setDataSource(db2DataSourceHk);
        entityManagerFactory.setPersistenceXmlLocation("classpath*:com/sc/rdc/csl/ss/resource/hk/persistence/persistence-hk.xml");
        entityManagerFactory.setPersistenceUnitName(Constants.PERSISTENCE_UNIT_HK);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(false);
        vendorAdapter.setDatabase(Database.DB2);
        entityManagerFactory.setJpaVendorAdapter(vendorAdapter);
        return entityManagerFactory;
    }

    @Primary
    @Bean(name = "transactionManagerHk")
    public PlatformTransactionManager transactionManager(
            @Qualifier("entityManagerFactoryHk") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    @Primary
    @Bean(name = "exceptionTranslationHk")
    public PersistenceExceptionTranslationPostProcessor exceptionTranslationHk() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    @Primary
    @Bean(name = "db2DataSourceHk")
    @ConfigurationProperties(prefix = "hk.db2.datasource")
    public DataSource db2DataSourceHk() {
        return new ComboPooledDataSource();
    }


}
