package com.sc.rdc.csl.ss.common.dto.wld;

public enum BooleanFlag {

    Y("Y"),
    N("N");

    private String flag;

    private BooleanFlag() {
    }

    private BooleanFlag(String flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return flag;
    }

}
