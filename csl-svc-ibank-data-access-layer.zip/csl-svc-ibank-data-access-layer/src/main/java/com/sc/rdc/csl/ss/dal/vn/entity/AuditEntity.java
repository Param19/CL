package com.sc.rdc.csl.ss.dal.vn.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Id;

import lombok.Data;

@Data
//@Entity
//@Table(name = "DB2INST1", schema = "AUDTTRL")
public class AuditEntity implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	@Id
	//@Column(name = "AUDTKEY")
	private Long auditKey;
	
	//@Column(name = "ENTRYTIME")
	private Timestamp entryTime;
	
	//@Column(name = "SECTION")
	private String section;
	
	//@Column(name = "ACTIONTYPE")
	private String actionType;
	
	//@Column(name = "PRIMRELNO")
	private String primaryRelId;
	
	//@Column(name = "INFO")
	private String auditInfo;
		
	//@Column(name = "SECRELNO")
	private String secRelId;
	
	//@Column(name = "CLASSNAME")
	private String className;
	
	//@Column(name = "CNTRYCODE")
	private String coutnry;
	
	//@Column(name = "PROGRAMID")
	private String programId;
	
	//@Column(name = "ACTION")
	private String action;
	
	//@Column(name = "TRNFLAG")
	private String trnsactionFlag;

	//@Column(name = "TRNFLAG")
	private String hashFlag;
	
	//@Column(name = "PURGFLAG")
	private String purgeFlag;
}
