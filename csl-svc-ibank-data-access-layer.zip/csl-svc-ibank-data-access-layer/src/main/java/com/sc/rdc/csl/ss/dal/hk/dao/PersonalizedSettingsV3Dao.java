package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.rdc.csl.ss.common.dto.customer.AccountPersonalized;
import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsV3Summary;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.DeviceGroupEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.PersonalizedSettingsEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.persistence.Query;
import java.util.*;

@Service(value="personalizedSettingsV3DaoHk")
@Slf4j
public class PersonalizedSettingsV3Dao extends BaseDao {
    
    public static final String DEVICE_CHANNEL_IBNK = "0";



	public  List<PersonalizedSettingsEntity> getPersonalizedAccountSummary(String customerEBID , String language)
	{
		PersonalizedSettingsV3Summary personalizedSettingsV3Summary = null;
		AccountPersonalized accountPersonalized =null;
		Query query = entityManagerHk.createQuery(
				"select ps, dg from com.sc.rdc.csl.ss.dal.hk.entity.customer.PersonalizedSettingsEntity ps, "
						+ "com.sc.rdc.csl.ss.dal.hk.entity.customer.DeviceGroupEntity dg"
						+ " where ps.customerEBID = :customerEBID"
						+ " and ps.settingId = dg.settingId"
						+ " and dg.deviceChannel = :deviceChannel"
						+ " and ps.preferredLanguage = :preferredLanguage"
						+ " order by ps.orderNumber");
		query.setParameter("customerEBID", customerEBID);
		query.setParameter("preferredLanguage",language);
		query.setParameter("deviceChannel", DEVICE_CHANNEL_IBNK);
		List rawList = query.getResultList();
		if (CollectionUtils.isNotEmpty(rawList)) {
			List<PersonalizedSettingsEntity> personalizedSettingsList = new ArrayList<>();
			Iterator it = rawList.iterator();
			while (it.hasNext()) {
				Object[] obj = (Object[]) it.next();
				PersonalizedSettingsEntity pVO = (PersonalizedSettingsEntity) obj[0];
				DeviceGroupEntity deviceGroupVO = (DeviceGroupEntity) obj[1];
				// set deviceGroupVO into personalized settings vo
				if (deviceGroupVO != null) {
					Set deviceGroupSet = new HashSet();
					deviceGroupSet.add(deviceGroupVO);
					pVO.setDeviceGroupList(deviceGroupSet);
				}
				personalizedSettingsList.add(pVO);
			}

			return personalizedSettingsList;
		}

		return null;
	}
}
