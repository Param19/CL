package com.sc.rdc.csl.ss.dal.hk.entity.card;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author 1382158
 * @since 2017
 */
@Entity
@Data
@Table(name = "CM_ATM_CARD_TYP", schema = "SCBREF")
public class AtmCardType implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "ATM_CARD_TYPE_ID")
    private Long atmCardType;
    /*   @Column(name = "ATM_CARD_TYPE_NAME_EN")
        private String cardTypeNameEn;*/
    @Column(name = "ATM_CARD_TYPE_NAME_CN")
    private String cardTypeNameCn;
    @Column(name = "ATM_CARD_TYPE_NAME_HK")
    private String cardTypeNameHk;
    @Column(name = "RESTRICTED_CARD_NO")
    private String restrictedCardNos;
    @Column(name = "SUB_CARD_TYPE")
    private String subCardType;
    @Column(name = "ALLOW_PREMIUM_CUST")
    private String isPremimum;
    @Column(name = "ALLOW_PRIORITY_CUST")
    private String isPriority;
    @Column(name = "ALLOW_MASS_CUST")
    private String isMass;
    @Column(name = "DT_CREATED")
    private Timestamp dtCreated;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "DT_UPD")
    private Timestamp dtUpdated;
    @Column(name = "UPD_BY")
    private String updatedBy;
    @Column(name = "ISDUALCARD")
    private Character isDualCard;


}
