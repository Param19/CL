package com.sc.rdc.csl.ss.main.service;


import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.helper.MailConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import com.webmethods.jms.log.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class MailServiceFactory {

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private Environment environment;

    @Autowired
    private CSLRequestContext cslRequestContext;


    public MailService getMailService() {
        Log.info("Getting MailService instance from Application context for Country : {}", cslRequestContext.getCountry());
        String countryGroup = environment.getProperty("database.country.group.".concat(cslRequestContext.getCountry().toUpperCase()));
        String countryServiceName = MailConstant.serviceName.concat(countryGroup != null ? countryGroup : cslRequestContext.getCountry().toUpperCase());
        return applicationContext.getBean(countryServiceName, MailService.class);
    }
}
