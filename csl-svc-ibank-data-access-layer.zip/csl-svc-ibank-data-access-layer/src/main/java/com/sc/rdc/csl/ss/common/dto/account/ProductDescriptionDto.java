package com.sc.rdc.csl.ss.common.dto.account;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.Setter;

import java.util.Map;

@Setter
@Getter
@JsonApiResource(type = "product-description")
public class ProductDescriptionDto extends SsBaseDto {

    @JsonApiId
    private String id;

    @JsonProperty("product-description")
    private Map<String , String> productDescription;








}
