
package com.sc.rdc.csl.ss.common.helper;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Constants {
    public static final String HK = "HK";
    public static final String SG = "SG";
    public static final String CN = "CN";
    public static final String VN = "VN";
    public static final String MY = "MY";
    public static final String AF = "AF";
    public static final String IN = "IN";
    public static final String CI = "CI";
    public static final String AE = "AE";
    public static final String PK = "PK";
    
    
    //New Countries 
   	public static final String NG = "NG";
   	public static final String KE = "KE";
   	public static final String GH = "GH";
   	public static final String BW = "BW";
   	public static final String ZM = "ZM";
   	public static final String UG = "UG";
   	public static final String ZW = "ZW";
   	public static final String TZ = "TZ";
   	
    public static final String SCB = "Standard Chartered Bank";
    public static final String ADDRESS_TYPE = "G";
    public static final String STATUS_CD = "A";
    

    public static final String PERSISTENCE_UNIT_AF = "sharedservice_af";
    public static final String PERSISTENCE_UNIT_CN = "sharedservice_cn";
    public static final String PERSISTENCE_UNIT_HK = "sharedservice_hk";
    public static final String PERSISTENCE_UNIT_IN = "sharedservice_in";
    public static final String PERSISTENCE_UNIT_MY = "sharedservice_my";
    public static final String PERSISTENCE_UNIT_SG = "sharedservice_sg";
    public static final String PERSISTENCE_UNIT_VN = "sharedservice_vn";

    public static final String PERSISTENCE_UNIT_AE = "sharedservice_ae";
    public static final String PERSISTENCE_UNIT_PK = "sharedservice_pk";


    public static final String FROM_DATE = "fromDate";
    public static final String TO_DATE = "toDate";
    public static final String PAGE_LIMIT = "pageLimit";

    public static final Map<String, String> transactionStatusMap = new HashMap<String, String>() {{
        put("2","SUBM");
        put("3","SUCC");
        put("4","FAIL");
        put("6","PROC");
        put("7","SCHD");
        put("8","COMP");
    }};

    public static final Map<String, String> transactionModeMap = new HashMap<String, String>() {{
        put("I","IMDD");
        put("S","SUBM");
        put("P","POST");
    }};

    public static final Map<String, String> transactionType = new HashMap<String, String>() { {
        put("OAFT","OAT");
        put("INFT","IFT");
        put("GLFT","GLTT");
    }};

    public static final List<String> transactionTypeList = new ArrayList<String>(){ {
        add("OAFT");
        add("GLFT");
        }};

    public static final Map<String, String> transactionCodes = new HashMap<String, String>() { {
        put("OAFT","15");
        put("INFT","19");
        put("GLFT","20");
    }};
}





