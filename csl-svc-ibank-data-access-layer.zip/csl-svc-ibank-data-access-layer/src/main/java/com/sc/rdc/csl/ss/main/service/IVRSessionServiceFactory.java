package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.IIVRSessionService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component()
@Slf4j
public class IVRSessionServiceFactory {
    
    @Qualifier("ivrSessionServiceHk")
    @Autowired
    private IIVRSessionService ivrSessionServiceHk;

    @Qualifier("ivrSessionServiceAe")
    @Autowired
    private IIVRSessionService ivrSessionServiceAe;

    @Qualifier("ivrSessionServiceIn")
    @Autowired
    private IIVRSessionService ivrSessionServiceIn;

    @Qualifier("ivrSessionServiceSg")
    @Autowired
    private IIVRSessionService ivrSessionServiceSg;

    @Qualifier("ivrSessionServiceMy")
    @Autowired
    private IIVRSessionService ivrSessionServiceMy;

    public IIVRSessionService getIVRSessionService(String country)
    {
        switch (StringUtils.upperCase(country)) {
            case Constants.HK:
                return ivrSessionServiceHk;
            case Constants.AE:
                return ivrSessionServiceAe;
            case Constants.IN:
                return ivrSessionServiceIn;
            case Constants.SG:
                return ivrSessionServiceSg;
            case Constants.MY:
                return ivrSessionServiceMy;
            default:
                log.error("############ Country "+country+" not supported for IVR###########");
                return null;
        }
    }
}
