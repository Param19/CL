package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.card.CardDto;
import com.sc.rdc.csl.ss.main.service.CreditCardServiceImpl;
import io.katharsis.queryspec.IncludeRelationSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class CreditCardEndpoint extends ResourceRepositoryBase<CardDto, String> {

    @Autowired
    private CreditCardServiceImpl creditCardService;

    @Autowired
    private CSLRequestContext cslRequestContext;

    public CreditCardEndpoint(){
        super(CardDto.class);
    }

    @Override
    public ResourceList<CardDto> findAll(QuerySpec querySpec) {

        log.info("Offline Credit Card Summary");
        SsCSLUser ssCSLUser = getSsCSLUser();
        List<CardDto> credits = creditCardService.getCreditCardSummary(ssCSLUser);
        return querySpec.apply(credits);
    }

    @Override
    public ResourceList<CardDto> findAll(Iterable<String> ids, QuerySpec querySpec) {
        SsCSLUser ssCSLUser = getSsCSLUser();
        List<String> creditCardList = new ArrayList<>();
        ids.forEach(id -> creditCardList.add(id));
        List<CardDto> credits = creditCardService.getProvidedCreditCardsSummary(ssCSLUser,creditCardList);
        ResourceList resourceList = new DefaultResourceList();
        resourceList.addAll(credits);
        return resourceList;
    }

    @Override
    public CardDto findOne(String id, QuerySpec querySpec) {
        log.info("Offline Credit Card Details");
        SsCSLUser ssCSLUser = getSsCSLUser();
        CardDto cardDetails = creditCardService.getCreditCardDetails(id, ssCSLUser , containsRelation(querySpec,"cardtransactions"));
       return cardDetails;
    }

    private SsCSLUser getSsCSLUser() {
        SsCSLUser ssCSLUser = new SsCSLUser();
        ssCSLUser.addCSLRequestContext(cslRequestContext);
        ssCSLUser.setUaas2id(cslRequestContext.getUaas2id());
        ssCSLUser.setCountry(cslRequestContext.getCountry());
        ssCSLUser.setLanguage(cslRequestContext.getLanguage());
        ssCSLUser.setRelId(cslRequestContext.getRelId());
        ssCSLUser.setSegCd(cslRequestContext.getSessionId());
        return ssCSLUser;
    }


    private boolean containsRelation(QuerySpec querySpec, String relationName) {
        if(querySpec!=null) {
            return getIncludedRelations(querySpec).stream()
                    .anyMatch(relation -> relation.toString().equalsIgnoreCase(relationName));
        }else {
            return Boolean.FALSE;
        }
    }

    private List<IncludeRelationSpec> getIncludedRelations(QuerySpec querySpec) {
        return querySpec.getIncludedRelations();
    }
}