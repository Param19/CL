
package com.sc.rdc.csl.ss.common.service;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;

public abstract class ICustomerService {
    public CustomerDetailDto getCustomerProfile() {
        return null;
    }

    public void updateProfile(SsCSLUser user, Profile profile) {
    throw new TechnicalException(ErrorConstant.UNSUPPORTED_OPERATION);
    }

    public Profile getProfile(SsCSLUser user) { throw new TechnicalException(ErrorConstant.UNSUPPORTED_OPERATION); }

    public SsBaseDto getCustomerProfile(SsCSLUser user) {
        throw new TechnicalException(ErrorConstant.UNSUPPORTED_OPERATION);
    }
}
