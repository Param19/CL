package com.sc.rdc.csl.ss.dal.ae.dao;

import com.sc.rdc.csl.ss.dal.ae.entity.MailVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

@Repository(value = "mailServiceDaoAe")
@Slf4j
public class MailServiceDao extends BaseDao {

    public void insertMailData(MailVO mailVO) {
        entityManagerAe.merge(mailVO);
        log.info("MailVO Successfully Inserted for {}", mailVO.getCountryCode());
    }
}
