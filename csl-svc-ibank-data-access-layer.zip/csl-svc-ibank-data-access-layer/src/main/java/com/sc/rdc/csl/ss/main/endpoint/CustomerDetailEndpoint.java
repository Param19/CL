package com.sc.rdc.csl.ss.main.endpoint;


import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import com.sc.rdc.csl.ss.main.helper.CommonEnricher;
import com.sc.rdc.csl.ss.main.service.CustomerServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
public class CustomerDetailEndpoint extends ResourceRepositoryBase<CustomerDetailDto, String> {

    public CustomerDetailEndpoint() {

        super(CustomerDetailDto.class);
    }

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    @Qualifier("customerDetailServiceImpl")
    private CustomerDetailService customerDetailService;

    @Autowired
    private CustomerServiceImpl customerService;

    public CustomerDetailDto findOne(String id, QuerySpec querySpec) {

        try {
            log.debug("[CardDetailsRepository findAll Entry]");
            CustomerDetailDto customerDetailDto = new CustomerDetailDto();
            customerDetailDto.setCountryCode(cslRequestContext.getCountry());
            customerDetailDto.setRellId(cslRequestContext.getRelId());

            Map<String, Object> filterMap = CommonEnricher.populateQuerySpec(querySpec);
            String filterValue = (String)filterMap.get("customerPreference");
            log.info("Filter value: {}", filterValue);
            if(StringUtils.isNotEmpty(filterValue) && "true".equalsIgnoreCase(filterValue)){
                return customerService.getCustomerProfile();
            } else {
                return customerDetailService.getCustomerDetail(customerDetailDto);
            }
        } finally {
            log.debug("[CardDetailsRepository findOne Exit]");
        }

    }



    @Override
    public ResourceList<CustomerDetailDto> findAll(QuerySpec querySpec) {
        try {
            log.debug("[CardDetailsRepository findAll Entry]");
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        } finally {
            log.debug("[CardDetailsRepository findAll Exit]");
        }

    }
}