package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.card.CardCustDto;
import com.sc.rdc.csl.ss.common.service.CardCustService;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class CardCustEndpoint extends ResourceRepositoryBase<CardCustDto,String> {

    public CardCustEndpoint() {
        super(CardCustDto.class);
    }

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    @Qualifier("cardCustServiceImpl")
    private CardCustService cardCustService;

    @Override
    public CardCustDto findOne(String id, QuerySpec querySpec) {

        try {
            log.debug("[CardDetailsRepository findAll Entry]");
            CardCustDto cardCustDto = new CardCustDto();
            cardCustDto.setCountryCode(cslRequestContext.getCountry());
            cardCustDto.setCardNo(id);
            cardCustDto = cardCustService.getCardCust(cardCustDto);
            return cardCustDto;
        } finally {
            log.debug("[CardDetailsRepository findOne Exit]");
        }

    }

    @Override
    public ResourceList<CardCustDto> findAll(QuerySpec querySpec) {
        log.debug("[CardDetailsRepository findAll Entry]");
        CardCustDto cardCustDto = new CardCustDto();
        cardCustDto.setCountryCode(cslRequestContext.getCountry());
        cardCustDto.setCustomerId(cslRequestContext.getCustomerId());
        cardCustDto.setCustomerIdType(cslRequestContext.getCustomerType());
        List<CardCustDto> cardCustDtoList = cardCustService.getCardList(cardCustDto);
        return querySpec.apply(cardCustDtoList);
    }
}
