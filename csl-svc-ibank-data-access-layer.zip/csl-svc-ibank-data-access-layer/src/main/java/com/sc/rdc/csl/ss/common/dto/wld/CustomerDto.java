package com.sc.rdc.csl.ss.common.dto.wld;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerDto extends SsBaseDto {

    private Long id;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    private String customerId;
    private String customerIdType;
    private Date expiryDate;
    private BigDecimal preApprovedLimit;
    private String status;

        
    @Override
    public String toString() {
      return ToStringBuilder.reflectionToString(this);
    }

}
