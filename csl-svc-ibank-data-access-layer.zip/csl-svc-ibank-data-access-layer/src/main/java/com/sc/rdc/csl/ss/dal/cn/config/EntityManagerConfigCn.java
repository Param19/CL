
package com.sc.rdc.csl.ss.dal.cn.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.sc.rdc.csl.ss.common.helper.Constants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
public class EntityManagerConfigCn {

    @Bean("entityManagerFactoryCn")
    public LocalContainerEntityManagerFactoryBean entityManagerFactoryCn(@Qualifier("db2DataSourceCn") DataSource db2DataSourceCn) {
        LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactory.setDataSource(db2DataSourceCn);
        entityManagerFactory.setPersistenceXmlLocation("classpath*:com/sc/rdc/csl/ss/resource/cn/persistence/persistence-cn.xml");
        entityManagerFactory.setPackagesToScan("com.sc.rdc.csl.ss.dal.cn.entity");
        entityManagerFactory.setPersistenceUnitName(Constants.PERSISTENCE_UNIT_CN);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(false);
        vendorAdapter.setDatabase(Database.DB2);
        entityManagerFactory.setJpaVendorAdapter(vendorAdapter);
        return entityManagerFactory;
    }

    @Bean(name = "transactionManagerCn")
    public PlatformTransactionManager transactionManager(
            @Qualifier("entityManagerFactoryCn") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    @Bean("exceptionTranslationCn")
    public PersistenceExceptionTranslationPostProcessor exceptionTranslationCn() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    @Bean("db2DataSourceCn")
    @ConfigurationProperties(prefix = "cn.db2.datasource")
    public DataSource db2DataSourceCn() {
        return new ComboPooledDataSource();
    }

}
