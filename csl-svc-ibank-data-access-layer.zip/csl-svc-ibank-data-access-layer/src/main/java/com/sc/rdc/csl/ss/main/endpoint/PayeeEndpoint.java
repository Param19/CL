package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.payee.PayeeDto;
import com.sc.rdc.csl.ss.main.service.PayeeServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;


@Slf4j
@Component
public class PayeeEndpoint extends ResourceRepositoryBase<PayeeDto, String> {

    public PayeeEndpoint() { super(PayeeDto.class); }

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    @Qualifier("payeeServiceImpl")
    private PayeeServiceImpl payeeService;

    @Override
    public PayeeDto findOne(String id, QuerySpec querySpec) {
        try {
            log.debug("[PayeeRepository findOne Entry]");
            PayeeDto payeeDto = new PayeeDto();
            payeeDto.setCountryCode(cslRequestContext.getCountry());
            payeeDto.setPayeeId(id);
            payeeDto = payeeService.getPayee(id);
            return payeeDto;
        } finally {
            log.debug("[PayeeRepository findOne Exit]");
        }
    }

    @Override
    public ResourceList<PayeeDto> findAll(QuerySpec querySpec) {
        try {
            log.debug("[PayeeRepository findAll Entry]");
            return querySpec.apply(payeeService.getAllPayees());
        } finally {
            log.debug("[PayeeRepository findAll Exit]");
        }
    }

    @Override
    public PayeeDto create(PayeeDto payeeDto) {
        log.info("Payee Dto: {}",payeeDto);
        if(null != payeeDto && "Y".equalsIgnoreCase(payeeDto.getIsPayeeUpdate())){
            payeeService.updatePayee(payeeDto);
        } else {
            payeeService.addPayee(payeeDto);
        }
        return payeeDto;
    }

    @DELETE
    @Path("/{id}")
    public void delete(String id) {
        log.debug(id);
        payeeService.deletePayee(id);
    }

}
