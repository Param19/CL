
package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.util.CSLAssert;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.loan.LoanDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import io.katharsis.queryspec.QuerySpec;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanServiceImpl {
    

    @Autowired
    private LoanServiceFactory loanServiceFactory;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<LoanDto> getLoanSummary()  {
        validateHeaders();
        List<LoanDto> loanSummary = loanServiceFactory.getLoanService(requestContext.getCountry()).getLoanSummary();
        return loanSummary;
    }

    private void validateHeaders() {
        CSLAssert.hasLength(requestContext.getCountry(), ErrorConstant.CASA_NO_COUNTRY);
        CSLAssert.hasLength(requestContext.getRelId(), ErrorConstant.CASA_NO_RELID);
    }

    public LoanDto getOneLoanDetails(String accountId, QuerySpec querySpec){
        validateHeaders();
        LoanDto loanDetails = loanServiceFactory.getLoanService(requestContext.getCountry()).getOneLoanDetail(accountId, querySpec);
        return loanDetails;
    }
}
