package com.sc.rdc.csl.ss.common.dto.customer;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.util.List;
import lombok.Data;

@Data
public class PersonalizedSettingsSummary extends SsBaseDto {
   private List<AccountPersonalized> accountPersonalizedSummary ; 
   private CustomerPersonalized  customerPersonalizedSummary ;
}
