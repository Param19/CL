package com.sc.rdc.csl.ss.common.dto.customer;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@JsonApiResource(type = "personalized-settings")
@Data
public class PersonalizedSettingsV3Summary extends SsBaseDto {
   private static final long serialVersionUID = 7058050166460825314L;

   @JsonApiId
   private String id;

   private List<AccountPersonalized> accountPersonalizedSummary ;
}
