package com.sc.rdc.csl.ss.dal.sg.entity;

import lombok.Data;

@Data
public class CustomerEntity {
    private String customerId;
    private String accountNumber;
    private Long id;
}
