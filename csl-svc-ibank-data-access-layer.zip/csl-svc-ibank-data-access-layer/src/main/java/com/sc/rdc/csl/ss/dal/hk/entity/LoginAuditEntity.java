package com.sc.rdc.csl.ss.dal.hk.entity;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoginAuditEntity implements Serializable {
	  private static final long serialVersionUID = -1L;
	 
	  private String activityDesc;
	  private String activityStatus;
	  private String backendTxnId;
	  private String channel;
	  private String channelCd;
	  private String customerBackendStatus;
	  private String customerId;
	  private String customerStatus;
	  private String ebid;
	  private Boolean isAuthorized;
	  private Boolean isAuthNeeded;
	  private Boolean isAuthRequired;
	  private Boolean isCustInfoRetrieved;
	  private Boolean isFirstTimeLogin;
	  private String logEvent;
	  private String logException;
	  private Date logTimestamp;
	  private String moDcs;
	  private String moMessage;
	  private String moMsgId;
	  private String moMsisdn;
	  private String moScNo;
	  private Date moTimestamp;
	  private String pinMailerSerialNo;
	  private String sessionId;
	  private String txnId;
	  private String  useCase;
	 
	  @Override
	    public boolean equals(Object o) {

	        if (o == this) return true;
	        if (!(o instanceof LoginAuditEntity)) {
	            return false;
	        }

	        LoginAuditEntity loginAuditEntity = (LoginAuditEntity) o;

	        return loginAuditEntity.logTimestamp.equals(logTimestamp) &&
	        	   loginAuditEntity.customerId == customerId &&
	        	   loginAuditEntity.sessionId.equals(sessionId);
	    }

	    @Override
	    public int hashCode() {
	        int result = 17;
	        result = 31 * result + logTimestamp.hashCode();
	        result = 31 * result + customerId.hashCode();
	        result = 31 * result + sessionId.hashCode();
	        return result;
	    }

}
