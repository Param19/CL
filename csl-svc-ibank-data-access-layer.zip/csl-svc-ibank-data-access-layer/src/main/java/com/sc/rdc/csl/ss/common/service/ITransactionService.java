package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.account.Transaction;
import io.katharsis.queryspec.QuerySpec;

import java.util.List;

public abstract class ITransactionService {

    public List<Transaction> getTransactions(List<String> accountNo, QuerySpec querySpecs) { return null; }

}
