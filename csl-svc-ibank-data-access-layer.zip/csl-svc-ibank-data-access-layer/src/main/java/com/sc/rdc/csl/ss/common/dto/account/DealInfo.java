package com.sc.rdc.csl.ss.common.dto.account;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * Created by 1347884 on 11/29/2017.
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonApiResource(type = "deal")
public class DealInfo extends SsBaseDto {

    @JsonApiId
    private Long id;

    @NotNull
    @JsonProperty("depositType")
    private String depositType;

    @JsonProperty("currencyCode")
    private String currencyCode;

    @JsonProperty("dealType")
    private String dealType;

    @JsonProperty("tenureUnit")
    private String tenureUnit;

    @JsonProperty("depositTenureValue")
    private String depositTenureValue;

    @JsonProperty("interestProduct")
    private String interestProduct;

    @JsonProperty("interestCode")
    private String interestCode;

    @JsonProperty("statusCD")
    private String statusCD;

    //TODO - TEMP - REMOVE IT LATER
    @JsonProperty("country")
    private String country;
}
