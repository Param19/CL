package com.sc.rdc.csl.ss.dal.af.service;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.audit.Audit;
import com.sc.rdc.csl.ss.common.helper.AuditConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IAuditService;
import com.sc.rdc.csl.ss.dal.af.dao.AuditServiceDao;
import com.sc.rdc.csl.ss.dal.af.entity.AuditEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("auditServiceAf")
public class AuditService extends IAuditService {
	

    @Autowired
    @Qualifier("auditServiceDaoAf")
    private AuditServiceDao auditServiceDao;

    @Autowired
    CSLRequestContext cslRequestContext;
    
	@Override
	@Transactional("transactionManagerAf")
	public Audit auditTransaction(Audit audit,SsCSLUser user) {
		log.debug("auditTransaction :"+audit);
		try{
			AuditEntity auditEntity= preparePinChangeAuditEntity(audit);
			
			auditServiceDao.auditTransaction(auditEntity);
			audit.setStatusCd(AuditConstant.SUCCESS);
		}catch (Exception e) {
			log.info("Exceotion message "+e.getLocalizedMessage());
            log.error("Exception while Inserting Audit {} , {} ", user.getCustomerId(), e.getMessage());
            throw new TechnicalException(ErrorConstant.ERR_INSERTING_AUDIT);
        }
	    return audit;
  } 
	
	public AuditEntity preparePinChangeAuditEntity(Audit audit){
		
		AuditEntity auditEntity = new AuditEntity();

		String auditInfo = audit.getAuditInfo();
		
		Map<String,String> auditInfoMap= new HashMap<>(); 

		StringTokenizer auditDataToken = new StringTokenizer(auditInfo,
				AuditConstant.SEMICOLON);

		/* "Card=************5556;EmbossedName=Testing;CardType=CREDIT;ReceiptNumber=MY1611280124I80010;ErrorCode=;ErrorMessage=;ChannelFlag=IBK;DateTime=2017-03-01 10:20:41.956" */
		while (auditDataToken.hasMoreElements()) {
			String element = auditDataToken.nextToken();
			String key = StringUtils.substringBefore(element,
					AuditConstant.EQUALS);
			String value = StringUtils.substringAfter(element,
					AuditConstant.EQUALS);
			auditInfoMap.put(key, value);
		}
		
		if(AuditConstant.OPERATION_CC_PINSET.equalsIgnoreCase(audit.getFunctionCd())) {
			auditEntity.setUseCase(AuditConstant.CREDIT_CARD_USE_CASE_PC);
			auditEntity.setLogEvent(AuditConstant.CREDIT_LOG_EVENT_PC);
		} else if (AuditConstant.OPERATION_CC_ACTIVATION.equalsIgnoreCase(audit.getFunctionCd())) {
			auditEntity.setUseCase(AuditConstant.CREDIT_CARD_USE_CASE_CA);
			auditEntity.setLogEvent(AuditConstant.CREDIT_LOG_EVENT_CA);
		} else if (AuditConstant.OPERATION_CC_PINACTIV.equalsIgnoreCase(audit.getFunctionCd())) {
			auditEntity.setUseCase(AuditConstant.CREDIT_CARD_USE_CASE_BOTH);
			auditEntity.setLogEvent(AuditConstant.CREDIT_LOG_EVENT_BOTH);
		} else {
			auditEntity.setUseCase("");
			auditEntity.setLogEvent("");
		}

		if(StringUtils.isNotBlank(auditInfoMap.get(AuditConstant.CARDTYPE)) && auditInfoMap.get(AuditConstant.CARDTYPE).length() >= 1)
			auditEntity.setCardType(auditInfoMap.get(AuditConstant.CARDTYPE).substring(0, 1));
		else
			auditEntity.setCardType("");
		if(StringUtils.isNotBlank(cslRequestContext.getSessionId()))
			auditEntity.setSessionId(cslRequestContext.getSessionId());
		else
			auditEntity.setSessionId(cslRequestContext.getRequestId());
		auditEntity.setTxnId(cslRequestContext.getRequestId());
		auditEntity.setPinchangeStaus(audit.getAction());
		auditEntity.setCardNumber(auditInfoMap.get(AuditConstant.CARD));
		auditEntity.setCardEmbossedName(auditInfoMap.get(AuditConstant.EMBOSSEDNAME));
		auditEntity.setChannel(auditInfoMap.get(AuditConstant.CHANNELFLAG));
		auditEntity.setBackendTxnId(auditInfoMap.get(AuditConstant.RECEIPTNUMBER));
		auditEntity.setCustomerId(cslRequestContext.getCustomerId());
		auditEntity.setCustomerType(cslRequestContext.getCustomerType());
		auditEntity.setEbid(cslRequestContext.getUaas2id());
		auditEntity.setErrorCode(auditInfoMap.get(AuditConstant.ERRORCODE));
		auditEntity.setTxnType(auditInfoMap.get(AuditConstant.TXN_TYPE));
		auditEntity.setReasonForFailure(auditInfoMap.get(AuditConstant.ERRORMESSAGE));
		auditEntity.setCountryCode(auditInfoMap.get(AuditConstant.COUNTRY_CODE));
		try {
			DateFormat df = new SimpleDateFormat(AuditConstant.AUDI_TIME_FORMAT);
			Date transactionDate = df.parse(auditInfoMap.get(AuditConstant.DATETIME));
			Timestamp timestamp = new Timestamp(transactionDate.getTime());
			auditEntity.setLogTimestamp(timestamp);
		} catch (Exception ex) {
			log.info("Exception occured while formatting dateTime "+ ex);
			auditEntity
					.setLogTimestamp(new Timestamp(new Date().getTime()));
		}
		
		auditEntity.setCardActivationStatus(auditInfoMap.get(AuditConstant.CARD_ACTIVATION_STATUS));
		
		return auditEntity;
	}

}
