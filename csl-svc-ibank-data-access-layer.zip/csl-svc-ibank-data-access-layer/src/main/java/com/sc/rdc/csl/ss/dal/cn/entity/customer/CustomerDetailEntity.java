package com.sc.rdc.csl.ss.dal.cn.entity.customer;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.util.Date;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CustomerDetailEntity extends BaseDto {

    private static final long serialVersionUID = -1L;

    private Long id;
    private String userId;
    private String userPassword;
    private String customerEBID;
    private String customerPBID;
    private String customerIdType;
    private String customerId;
    private String customerName1;
    private String customerName2;
    private String customerStatusCode;
    private String language;
    private Date lastLoginDate;
    private Date firstLoginDate;
    private String isLoggedIn;
    private Boolean isActivated;
    private Integer loginCounter;
    private String mobileNumber;
    private String accessKey;
    private String twoFAType;
    private String emailAddress;
    private String nickName;
    private String systemType;
    private String brandIndicator;
    private String armCode;
    private String relTyp;
    private String packageStatus;
    private Integer loginSuccessCount;
    private Long customerSequenceNo;
    private String txnPasswordStatus;
    private String migrationStatus;
    private boolean e2eMigrationStatus;
    private Boolean smsAlert;
    private Boolean emailAlert;
}
