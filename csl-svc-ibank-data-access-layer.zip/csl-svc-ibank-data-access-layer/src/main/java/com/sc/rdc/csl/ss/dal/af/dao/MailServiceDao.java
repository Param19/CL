package com.sc.rdc.csl.ss.dal.af.dao;

import com.sc.rdc.csl.ss.dal.af.entity.MailVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

@Repository(value = "mailServiceDaoAf")
@Slf4j
public class MailServiceDao extends BaseDao {

    public void insertMailData(MailVO mailVO) {
        entityManagerAf.persist(mailVO);
        log.info("MailVO Successfully Inserted for {}", mailVO.getCountryCode());
    }
}
