package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.card.CardCustDto;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CardCustEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CARD_NO_RECORD_EXCEPTION;

@Repository(value = "cardCustServiceDaoHk")
@Slf4j
public class CardCustDao extends BaseDao {

    public static String GET_CARD_DETAIL = "select o from com.sc.rdc.csl.ss.dal.hk.entity.card.CardCustEntity o WHERE o.cardNo = :cardNo";
    public static String GET_CARD_LIST = "select o from com.sc.rdc.csl.ss.dal.hk.entity.card.CardCustEntity o WHERE o.customerId = :customerId and o.custIdType = :custIdType ";

    public CardCustDto getCardDetails(CardCustDto cardCustDto) {

        CardCustDto customerIdVO = null;
        log.info("getApplication::getApplication,{}", cardCustDto.getCardNo());
        Query query = entityManagerHk.createQuery(GET_CARD_DETAIL);
        query.setParameter("cardNo", cardCustDto.getCardNo());
        List<CardCustEntity> carddetails = query.getResultList();

       if(carddetails!=null && carddetails.size()>0)
       {
           CardCustEntity cardCustEntity = (CardCustEntity)carddetails.get(0);

           customerIdVO = new CardCustDto();
           customerIdVO.setCardNo(cardCustEntity.getCardNo());
           customerIdVO.setCustomerIdType(cardCustEntity.getCustIdType());
           customerIdVO.setCustomerId(cardCustEntity.getCustomerId());

       }
       else {
           throw new BusinessException(CARD_NO_RECORD_EXCEPTION);
       }
       return customerIdVO;
    }


    public List<CardCustEntity> getCardList(CardCustDto cardCustDto) {

        log.info("CardCustDao::get Customer Id,{}", cardCustDto.getCustomerId());
        Query query = entityManagerHk.createQuery(GET_CARD_LIST);
        query.setParameter("customerId", cardCustDto.getCustomerId());
        query.setParameter("custIdType", cardCustDto.getCustomerIdType());
        List<CardCustEntity> cardList = query.getResultList();

        if(cardList == null || cardList.isEmpty()) {
            throw new BusinessException(CARD_NO_RECORD_EXCEPTION);
        }
        return cardList;
    }
}
