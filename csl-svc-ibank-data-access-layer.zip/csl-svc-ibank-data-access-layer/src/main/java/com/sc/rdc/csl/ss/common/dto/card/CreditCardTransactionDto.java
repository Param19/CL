package com.sc.rdc.csl.ss.common.dto.card;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Data
@NoArgsConstructor
@JsonApiResource(type = "cardtransactions")
public class CreditCardTransactionDto implements Serializable {

	private static final long serialVersionUID = 5874886117375293695L;

	@JsonApiId
	private String txnRefNo;
	@JsonProperty("card-num")
	private String cardNum;
	@JsonProperty("origin-txn-amt")
	private BigDecimal originTxnAmt;
	@JsonProperty("txn-currency")
	private String txnCurr;
	@JsonProperty("transaction-desc")
	private String desc;
	@JsonProperty("transaction-amount")
	private BigDecimal actualTxnAmount;
	@JsonProperty("partialrev-txn-amt")
	private BigDecimal partialRevTxnAmt;

	@JsonProperty("txn-date")
	private String txnDate;
	@JsonProperty("partialrev-txn-date")
	private String partialRevTxnDate;
	@JsonProperty("debit-credit-flag")
	private String debitCreditFlag;
	@JsonProperty("txn-code")
	private String txnCode;
	@JsonIgnore
	private String sendPageCount;
	@JsonProperty("sequence-number")
	private String sequenceNumber;
	@JsonProperty("batch-number")
	private String batchNumber;

	@JsonProperty("is-partially-reversed")
	private String isPartiallyReversed="N";
	@JsonProperty("primary-supp-ind")
	private String primarySuppInd;

	@JsonProperty("posting-date")
	private String  posting_Date ;

	@JsonProperty("date-of-purchase")
	private String effDt;

	@JsonProperty("amount-spent")
	private String amount;

	@JsonProperty("transaction-id")
	private String transactionId;

	@JsonProperty("transaction-description")
	private String refDesc;

	@JsonProperty("Currency")
	private String currency ;

	@JsonProperty("transaction-code")
	private String transactionCode;

	@JsonProperty("transaction-type")
	private String transactionType;

	@JsonProperty("transaction-date")
	private Date transactionDate;

	@JsonProperty("transaction-currency-code")
	private String transactionCurrencyCode;

	@JsonApiRelation(lookUp = LookupIncludeBehavior.AUTOMATICALLY_WHEN_NULL, opposite = "cardtransactions")
	private CardDto creditCardDto;
	
	public String toString() {
		return ReflectionToStringBuilder.toString(this,	ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
