package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerContact;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import com.sc.rdc.csl.ss.dal.hk.dao.CustDetailDao;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerDetailEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service(value = "custDetailServiceHK")
public class CustDetailService extends CustomerDetailService {


    @Qualifier("custDetailDaoHk")
    @Autowired
    private CustDetailDao cardCustDao;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public CustomerDetailDto getCustomerDetail(CustomerDetailDto custDetailDto) {
        String customerEBID = cardCustDao.getCustomerEBID(custDetailDto.getRellId());
        if(customerEBID !=null) {
            custDetailDto.setCustomerEBID(customerEBID);
        }

        return custDetailDto;
    }

    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public CustomerContact getCustomerContact(String countryCode,String customerId) {
        log.info("CustDetailService getCustomerContact() ");
        CustomerDetailEntity cusrDetailEntity = cardCustDao.getCustomerDetail(customerId);
        log.info("CustomerDetailEntoty :: {} ",cusrDetailEntity);
        if(cusrDetailEntity!=null) {
            CustomerContact custContact = new CustomerContact();
            custContact.setContactDetails(cusrDetailEntity.getMobileNumber());
            custContact.setContactTypeCode("Mobile");
            custContact.setRelId(cslRequestContext.getRelId());
            return custContact;
        }
        return null;
    }
}