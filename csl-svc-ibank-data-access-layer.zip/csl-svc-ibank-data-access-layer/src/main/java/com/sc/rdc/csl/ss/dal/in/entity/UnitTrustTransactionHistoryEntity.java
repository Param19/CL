package com.sc.rdc.csl.ss.dal.in.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class UnitTrustTransactionHistoryEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private String accountNumber;
    private String fundShortName;
    private String fundCode;
    private Long id;
}

