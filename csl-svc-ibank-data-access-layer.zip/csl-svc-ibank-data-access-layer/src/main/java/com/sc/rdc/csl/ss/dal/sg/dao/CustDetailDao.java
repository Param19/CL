package com.sc.rdc.csl.ss.dal.sg.dao;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.sc.rdc.csl.ss.dal.sg.entity.ProfileEntity;

import lombok.extern.slf4j.Slf4j;

@Repository(value = "custDetailDaoSG")
@Slf4j
public class CustDetailDao extends BaseDao {

    public static String GET_CUSTOMER_PROFILE = "select  o from com.sc.rdc.csl.ss.dal.sg.entity.ProfileEntity o WHERE o.customerId = :customerId ";

  
    public ProfileEntity  getCustomerDetail(String customerId) {
        log.info("getCustomerDetail CustomerId: ", customerId);
        Query query = entityManagerSg.createQuery(GET_CUSTOMER_PROFILE);
        query.setParameter("customerId", customerId);
        List<ProfileEntity> customerdetails = query.getResultList();
        if(!customerdetails.isEmpty()) {
            return customerdetails.get(0);
        }
        return null;
    }
}
