
package com.sc.rdc.csl.ss.common.dto;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.core.web.header.CSLUser;
import lombok.Data;
import lombok.ToString;

/**
 * Please don't use this class instead use CSLRequestContext to get csl_header information.
 * Inject CSLRequestContext class wherever required
 * @deprecated  use {@link #com.sc.csl.retail.core.web.CSLRequestContext} instead.
 */
@Data
@ToString()
@Deprecated
public class SsCSLUser extends CSLUser {
    private String customerTypeId;
    private String customerId;
    private String channel;
    public SsCSLUser(){}
    public SsCSLUser(CSLRequestContext cslRequestContext){
        this.customerId = cslRequestContext.getCustomerId();
        this.customerTypeId = cslRequestContext.getCustomerType();
        this.channel = cslRequestContext.getChannel();
        setCountry(cslRequestContext.getCountry());
        setRelId(cslRequestContext.getRelId());
        setUaas2id(cslRequestContext.getUaas2id());
        setLanguage(cslRequestContext.getLanguage());
    }
    
    
     public SsCSLUser addCSLRequestContext(CSLRequestContext cslRequestContext){
         this.customerId = cslRequestContext.getCustomerId();
        this.customerTypeId =  cslRequestContext.getCustomerType();
         this.channel = cslRequestContext.getChannel();
         return this;
    }
    
    public SsCSLUser addCustomerTypeId(String customerTypeId){
        this.customerTypeId = customerTypeId;
        return this;
    }
    
    public SsCSLUser addCustomerId(String customerId){
        this.customerId = customerId;
        return this;
    }
}
