package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.IProductService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component()
@Slf4j
public class ProductServiceFactory {
    
    @Qualifier("productServiceServiceHk")
    @Autowired
    private IProductService productServiceHk;
    
    public IProductService getProductService(String country)
    {
        switch (StringUtils.upperCase(country)) {
            case Constants.HK: 
                return productServiceHk;
            default: 
                log.error("############ Country not supported ###########");
                return null;
        }
    }
}
