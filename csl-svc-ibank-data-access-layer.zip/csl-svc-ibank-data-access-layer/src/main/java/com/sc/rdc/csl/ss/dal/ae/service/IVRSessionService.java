package com.sc.rdc.csl.ss.dal.ae.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.IVRInfo;
import com.sc.rdc.csl.ss.common.service.IIVRSessionService;
import com.sc.rdc.csl.ss.dal.ae.dao.IVRSessionServiceDao;
import com.sc.rdc.csl.ss.dal.ae.entity.customer.IVRInfoEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by 1347884 on 11/7/2017.
 */
@Slf4j
@Service("ivrSessionServiceAe")
public class IVRSessionService extends IIVRSessionService {
    @Autowired
    @Qualifier("ivrSessionServiceDaoAe")
    private IVRSessionServiceDao ivrSessionServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    @Override
    @Transactional(value = "transactionManagerAe", readOnly = true)
    @LogTimeTaken
    public IVRInfo getIVRInfo(String mobileNo, String country) {
        log.info("getIVRInfo mobileNo : " + mobileNo+"; country : "+country);
        IVRInfoEntity ivrInfoEntity = ivrSessionServiceDao.getIVRInfo(mobileNo, country);
        log.info("getIVRInfo ivrInfoEntity : " + ivrInfoEntity);
        IVRInfo ivrInfo = orikaMapperFacade.map(ivrInfoEntity, IVRInfo.class);
        log.info("getIVRInfo ivrInfo : " + ivrInfo);
        return ivrInfo;
    }
}
