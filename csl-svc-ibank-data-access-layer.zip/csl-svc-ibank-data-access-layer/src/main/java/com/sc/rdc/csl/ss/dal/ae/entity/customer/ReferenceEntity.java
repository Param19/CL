package com.sc.rdc.csl.ss.dal.ae.entity.customer;


import lombok.Data;

/**
 * @author Munikumar , Challagulla (1493439)
 */
@Data
public class ReferenceEntity {

    private static final long serialVersionUID = -1L;

    private Long id;
    private String uuid;
    private String countryCode;
    private String type;
    private String value;
    private String referenceCode;
    private String description;
    private int sequenceNo;
    private String statusCode;
    private String isDefault;
    private String isDisplay;
}



