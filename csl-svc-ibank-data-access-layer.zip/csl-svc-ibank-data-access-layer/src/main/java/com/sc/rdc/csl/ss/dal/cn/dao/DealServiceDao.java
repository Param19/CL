package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.cn.entity.account.DealInfoEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

/**
 * Created by 1347884 on 11/29/2017.
 */
@Repository(value ="dealServiceDaoCn")
@Slf4j
public class DealServiceDao  extends BaseDao{

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    public static String GET_DEAL_INFO = "select a from com.sc.rdc.csl.ss.dal.cn.entity.account.DealInfoEntity a WHERE a.statusCD = :statusCD";

    public List<DealInfoEntity> getDealInfo() {
        log.info("DealServiceDao:getDealInfo");

        Query query = entityManagerCn.createQuery(GET_DEAL_INFO);
        // Fetching only Active Records i.e Status code with A
        query.setParameter("statusCD", "A");
        log.info("DealServiceDao: Query1: "+query);
        log.info("DealServiceDao: Query2: "+query.toString());
        List<DealInfoEntity> dealInfoEntityList = query.getResultList();
        log.info("Received DealInfo from DB ", dealInfoEntityList);
        return dealInfoEntityList;
    }

}
