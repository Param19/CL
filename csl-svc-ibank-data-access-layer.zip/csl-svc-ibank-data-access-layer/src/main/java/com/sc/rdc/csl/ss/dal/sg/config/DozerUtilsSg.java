package com.sc.rdc.csl.ss.dal.sg.config;


import com.sc.rdc.csl.ss.common.dto.wld.ApplicationDto;
import com.sc.rdc.csl.ss.common.dto.wld.CustomerDto;
import com.sc.rdc.csl.ss.dal.sg.entity.WealthLendingApplicationEntity;
import com.sc.rdc.csl.ss.dal.sg.entity.WealthLendingCustEntity;
import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class DozerUtilsSg {
    	
    
    @Qualifier("dozerBeanMapperSg")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    
    public List<ApplicationDto> convertApplicationDto(final List<WealthLendingApplicationEntity> sourceList, String className, String mapId) throws ClassNotFoundException {
        if (sourceList== null) {
            return null;
        }
        List<ApplicationDto> dest = new ArrayList<>();
        for (WealthLendingApplicationEntity source : sourceList) {
            ApplicationDto dto = new ApplicationDto();
            dozerBeanMapper.map(source, dto, mapId);
            dest.add(dto );
        }
        return dest;
    }
    
    public CustomerDto convertCustomer(WealthLendingCustEntity wealthLendingCustEntity)  {
        if (wealthLendingCustEntity== null) {
            return null;
        }
        CustomerDto cust = new CustomerDto();
        dozerBeanMapper.map(wealthLendingCustEntity,cust );
        return cust;
    }
    
    
       
    
}
