package com.sc.rdc.csl.ss.common.dto.qrpayment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.builder.ToStringBuilder;


@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class QRPaymentDetailDto extends SsBaseDto {

    private static final long serialVersionUID = 1L;
    private String relId;
    private Long id;
    private String customerId;
    private String customerIdType;
    private String custName;
    private String sourceOfFund;
    private String cardType;
    private String cardNumber;
    private String cardName;
    private String merchantName;
    private String merchantCity;
    private String merchantCategory;
    private String txnCurrency;
    private String paymentStatus;
    /*
    TXN_AMOUNT	DECIMAL(25,2),
    SOURCE_CURRENCY	VARCHAR(10),
    SOURCE_AMOUNT	DECIMAL(25,2),
    SETTLEMENT_CURRENCY	VARCHAR(10),
    SETTLEMENT_AMOUNT	DECIMAL(25,2),
    PAYMENTSTATUSCODE	VARCHAR(10),
    PAYMENTSTATUS	VARCHAR(20),
    PAYMENT_STATUS_DESC	VARCHAR(200),
    MESSAGE	VARCHAR(200),
    PAYMENTDATE	TIMESTAMP,
    PROCESSEDTIMESTAMP	TIMESTAMP,
    PAYMENT_REQ_ORIGINATED	VARCHAR(20),
    SCANNED_QR_CODE	VARCHAR(250),
    RPE_REF_NUM	VARCHAR(36),
    CNTRY_CODE	VARCHAR(2) NOT NULL,
     */

    public QRPaymentDetailDto addRequestId(String requestId) {
        return this;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
