package com.sc.rdc.csl.ss.dal.sg.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.sg.entity.CreditCardEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.persistence.Query;
import java.util.List;

@Repository(value = "creditCardServiceDaoSg")
@Slf4j
public class CreditCardServiceDao extends BaseDao {

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<CreditCardEntity> getCreditCardSummary() {
        Query query = entityManagerSg.createQuery("select c from com.sc.rdc.csl.ss.dal.sg.entity.CreditCardEntity c" +
                " WHERE c.customerId = :customerId").setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);

        query.setParameter("customerId", requestContext.getCustomerId());
        List<CreditCardEntity> creditCardEntityList = query.getResultList();
        log.info("Received {} Credit Card record(s) from DB for User Id {}",
                (creditCardEntityList != null ? creditCardEntityList.size() : 0), requestContext.getCustomerId());
        if(!(creditCardEntityList!=null && creditCardEntityList.size()>0))
            throw new BusinessException(ErrorConstant.CREDITCARD_NO_RECORD_EXCEPTION);
        return creditCardEntityList;
    }

    public List<CreditCardEntity> getProvidedCreditCardSummary(String customerId, List<String> creditCards) {
        log.info("CreditCardServiceDao:getCreditCardSummary,{}" + customerId);
        Query query = entityManagerSg.createQuery("select a from com.sc.rdc.csl.ss.dal.sg.entity.CreditCardEntity a WHERE a.cardNum in (:cardNum)")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("cardNum", creditCards);
        List<CreditCardEntity> creditCardEntityList = query.getResultList();

        log.info("Received {} CreditCardSummary record(s) from DB for User Id {}",
                (creditCardEntityList != null ? creditCardEntityList.size() : 0), customerId);
        if(CollectionUtils.isEmpty(creditCardEntityList)){
            throw new BusinessException(ErrorConstant.CREDITCARD_NO_RECORD_EXCEPTION);
        }

        for (CreditCardEntity cardDto: creditCardEntityList) {
            cardDto.setCustomerId(cardDto.getRelIdType() + cardDto.getRelId());
        }

        return creditCardEntityList;
    }

    public CreditCardEntity getCreditCardDetails(String cardNo, SsCSLUser user) {
        log.info("CreditCardServiceDao: getCreditCardDetails,{}", user);
        Query query = entityManagerSg.createQuery("select a from com.sc.rdc.csl.ss.dal.sg.entity.CreditCardEntity a WHERE a.cardNum = :cardNum")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("cardNum", cardNo);
        List<CreditCardEntity> cardDetailsList = query.getResultList();
        if (cardDetailsList.isEmpty()) {
            throw new BusinessException(ErrorConstant.CREDITCARD_NO_RECORD_EXCEPTION);
        }
        CreditCardEntity cardDetails = cardDetailsList.get(0);
        cardDetails.setCustomerId(cardDetails.getRelIdType() + cardDetails.getRelId());
        log.info("Received Credit Card Details from DB for User Id {}, {} ", cardNo, cardDetails);
        return cardDetails;
    }

}
