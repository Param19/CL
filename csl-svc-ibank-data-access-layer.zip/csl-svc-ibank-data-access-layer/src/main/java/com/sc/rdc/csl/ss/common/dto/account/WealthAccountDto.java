package com.sc.rdc.csl.ss.common.dto.account;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.math.BigDecimal;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "account")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class WealthAccountDto extends ProductDto {

    private static final long serialVersionUID = 6310676561570800812L;

    private String accountStatus;
    private BigDecimal clearedBalance;
    private Date currentMaturityDate;
    private String interestDisposalCode;
    private BigDecimal interestRate;
    private Date issueDate;
    private BigDecimal principal;
    private String principalDisposalCode;
    private String tenor;
    private String term;
    private String termCode;
    private BigDecimal totalEffectiveLimit;
    private String trancheDesc;
    private String trancheID;
    private String accountShortName;
    private String iban;
    // AE
    private String masterNumber;

    //HK Wealth
    private BigDecimal availableFaceAmount;
    private BigDecimal currentFaceAmount;
    private BigDecimal interestAtMaturity;
    private String wealthproIndicator;
    private String wealthproODAccNo;

    public String getMasterNumber() {
        return masterNumber;
    }

    public void setMasterNumber(String masterNumber) {
        this.masterNumber = masterNumber;
    }

    public String getAccountShortName() {
        return accountShortName;
    }

    public void setAccountShortName(String accountShortName) {
        this.accountShortName = accountShortName;
    }

    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public BigDecimal getClearedBalance() {
        return clearedBalance;
    }

    public void setClearedBalance(BigDecimal clearedBalance) {
        this.clearedBalance = clearedBalance;
    }

    public Date getCurrentMaturityDate() {
        return currentMaturityDate;
    }

    public void setCurrentMaturityDate(Date currentMaturityDate) {
        this.currentMaturityDate = currentMaturityDate;
    }

    public String getInterestDisposalCode() {
        return interestDisposalCode;
    }

    public void setInterestDisposalCode(String interestDisposalCode) {
        this.interestDisposalCode = interestDisposalCode;
    }

    public BigDecimal getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }

    public Date getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(Date issueDate) {
        this.issueDate = issueDate;
    }

    public BigDecimal getPrincipal() {
        return principal;
    }

    public void setPrincipal(BigDecimal principal) {
        this.principal = principal;
    }

    public String getPrincipalDisposalCode() {
        return principalDisposalCode;
    }

    public void setPrincipalDisposalCode(String principalDisposalCode) {
        this.principalDisposalCode = principalDisposalCode;
    }

    public String getTenor() {
        return tenor;
    }

    public void setTenor(String tenor) {
        this.tenor = tenor;
    }

    public String getTerm() {
        return term;
    }

    public void setTerm(String term) {
        this.term = term;
    }

    public String getTermCode() {
        return termCode;
    }

    public void setTermCode(String termCode) {
        this.termCode = termCode;
    }

    public BigDecimal getTotalEffectiveLimit() {
        return totalEffectiveLimit;
    }

    public void setTotalEffectiveLimit(BigDecimal totalEffectiveLimit) {
        this.totalEffectiveLimit = totalEffectiveLimit;
    }

    public String getTrancheDesc() {
        return trancheDesc;
    }

    public void setTrancheDesc(String trancheDesc) {
        this.trancheDesc = trancheDesc;
    }

    public String getTrancheID() {
        return trancheID;
    }

    public void setTrancheID(String trancheID) {
        this.trancheID = trancheID;
    }

    public BigDecimal getAvailableFaceAmount() {
        return availableFaceAmount;
    }

    public void setAvailableFaceAmount(BigDecimal availableFaceAmount) {
        this.availableFaceAmount = availableFaceAmount;
    }

    public BigDecimal getCurrentFaceAmount() {
        return currentFaceAmount;
    }

    public void setCurrentFaceAmount(BigDecimal currentFaceAmount) {
        this.currentFaceAmount = currentFaceAmount;
    }

    public BigDecimal getInterestAtMaturity() {
        return interestAtMaturity;
    }

    public void setInterestAtMaturity(BigDecimal interestAtMaturity) {
        this.interestAtMaturity = interestAtMaturity;
    }

    public String getWealthproIndicator() {
        return wealthproIndicator;
    }

    public void setWealthproIndicator(String wealthproIndicator) {
        this.wealthproIndicator = wealthproIndicator;
    }

    public String getWealthproODAccNo() {
        return wealthproODAccNo;
    }

    public void setWealthproODAccNo(String wealthproODAccNo) {
        this.wealthproODAccNo = wealthproODAccNo;
    }

}
