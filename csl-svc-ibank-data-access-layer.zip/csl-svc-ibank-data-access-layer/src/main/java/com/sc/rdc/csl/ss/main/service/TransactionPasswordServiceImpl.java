
package com.sc.rdc.csl.ss.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.rdc.csl.ss.common.service.ITransactionPasswordService;
import com.sc.rdc.csl.ss.dal.hk.dto.TransactionPasswordDto;

@Service("transactionPasswordServiceImpl")
public class TransactionPasswordServiceImpl extends ITransactionPasswordService {
    
    @Autowired
    private TransactionPasswordServiceFactory transactionPasswordServiceFactory;

    @Override
    public TransactionPasswordDto getTransactionPassword(String ebid)  {
        return transactionPasswordServiceFactory.getTransactionPasswordService().getTransactionPassword(ebid);
    }
    
    @Override
    public void save(TransactionPasswordDto transactionPasswordDto)  {
         transactionPasswordServiceFactory.getTransactionPasswordService().save(transactionPasswordDto);
    }
}
