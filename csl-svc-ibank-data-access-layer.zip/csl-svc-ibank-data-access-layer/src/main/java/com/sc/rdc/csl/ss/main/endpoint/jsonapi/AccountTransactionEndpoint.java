package com.sc.rdc.csl.ss.main.endpoint.jsonapi;

import com.sc.rdc.csl.ss.common.dto.account.Transaction;
import com.sc.rdc.csl.ss.main.service.TransactionServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class AccountTransactionEndpoint extends ResourceRepositoryBase<Transaction, String> {

    public AccountTransactionEndpoint() {
        super(Transaction.class);
    }

    @Autowired
    private TransactionServiceImpl transactionService;

    @Override
    public ResourceList<Transaction> findAll(QuerySpec querySpec) {
        ResourceList<Transaction> resourceList = new DefaultResourceList<>();
        return resourceList;
    }

    @Override
    public ResourceList<Transaction> findAll(Iterable<String> ids, QuerySpec querySpec) {
        List<String> accountList = new ArrayList<>();
        ids.forEach(id -> accountList.add(id));
        List<Transaction> transactionsList = transactionService.fetchTransaction(accountList,querySpec);
        ResourceList transactionRRList = new DefaultResourceList();
        transactionRRList.addAll(transactionsList);
        return transactionRRList;
    }

}

