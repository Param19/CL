package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.card.CardFaceDto;
import com.sc.rdc.csl.ss.main.helper.CommonEnricher;
import com.sc.rdc.csl.ss.main.service.DcImageFaceServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Slf4j
@Component
public class DcImageFaceEndPoint extends ResourceRepositoryBase<CardFaceDto, String> {

    @Autowired
    private DcImageFaceServiceImpl dcImageFaceService;

    @Autowired
    private CSLRequestContext cslRequestContext;

    public DcImageFaceEndPoint() {
        super(CardFaceDto.class);
    }

    @Override
    public ResourceList<CardFaceDto> findAll(QuerySpec querySpec) {
        Map<String, Object> filterMap = CommonEnricher.populateQuerySpec(querySpec);
        //String atmCardType = (String)filterMap.get("atmCardType");
        String countryCode = (String) filterMap.get("countryCode");
        String custSeg = (String) filterMap.get("custSeg");
        log.info("findAll: {}{}", custSeg, countryCode);
        if (StringUtils.isNotEmpty(custSeg) && StringUtils.isNotEmpty(countryCode)) {
            return querySpec.apply(dcImageFaceService.getDcImageFaces(custSeg, countryCode));
        }
        return null;
    }

    @Override
    public CardFaceDto findOne(String accountNo, QuerySpec querySpec) {
        return null;
    }
}
