package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.TransactionLimitBaseService;
import com.sc.rdc.csl.ss.dal.cn.service.LimitsService;
import com.sc.rdc.csl.ss.dal.sg.service.TransactionLimitService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class TransactionLimitServiceFactory {

    @Autowired
    @Qualifier("transactionLimitServiceSG")
    private TransactionLimitService transactionLimitServiceSg;

    @Autowired
    @Qualifier("transactionLimitServiceCN")
    private LimitsService transactionLimitServiceCN;


    public TransactionLimitBaseService getTransactionLimitService(String country) {

            switch (StringUtils.upperCase(country)) {
                case Constants.SG:
                    return transactionLimitServiceSg;
                case Constants.CN:
                    return transactionLimitServiceCN;
                default:
                    log.error("############ Country not supported ###########");
                    return null;
            }
    }
}
