package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.customer.IVRInfo;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.main.service.IVRSessionServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Sivaprakasam, Balaji (1347884) on 11/7/2017.
 */
@Component
@Slf4j
public class IVRSessionEndpoint  extends ResourceRepositoryBase<IVRInfo, String> {
    @Autowired
    private IVRSessionServiceImpl ivrSessionService;

    protected IVRSessionEndpoint() {
        super(IVRInfo.class);
    }

    @Override
    public ResourceList<IVRInfo> findAll(QuerySpec querySpec) {
        try {
            log.debug("[IVRSessionRepository findAll Entry]");
            throw new BusinessException(ErrorConstant.SERVICE_UNAVAILABLE);
        } finally {
            log.debug("[IVRSessionRepository findAll Exit]");
        }
    }

    @Override
    public IVRInfo findOne(String id, QuerySpec querySpec) {
        log.info("findOne Operation : id - " + id + " querySpec : " + querySpec);
        return ivrSessionService.getInfo(id, querySpec);
    }

    @Override
    public IVRInfo save(IVRInfo ivrInfo) {
        // COMMENTING THE FOLLOWING LINE SINCE SAVE ENDPOINT IS NOT CURRENTLY USED FROM PICASSO STACK
        //return ivrSessionService.saveIVRInfo(ivrInfo);
        try {
            log.debug("[IVRSessionRepository save Entry]");
            throw new BusinessException(ErrorConstant.SERVICE_UNAVAILABLE);
        } finally {
            log.debug("[IVRSessionRepository save Exit]");
        }
    }

}
