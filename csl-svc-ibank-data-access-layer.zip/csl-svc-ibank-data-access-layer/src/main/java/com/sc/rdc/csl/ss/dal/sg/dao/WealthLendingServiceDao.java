package com.sc.rdc.csl.ss.dal.sg.dao;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.dal.sg.entity.WealthLendingCustEntity;
import java.util.List;
import javax.persistence.Query;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

@Repository(value = "wealthLendingServiceDaoSg")
@Slf4j
public class WealthLendingServiceDao extends BaseDao {   

    public static String WEALTH_PRO_CUST_STATUS_ACCEPTED = "Accepted";
    public static String WEALTH_PRO_CUST_STATUS_OPEN = "open";


    public WealthLendingCustEntity findWldCustomerDetails(SsCSLUser user) {
        Query query = entityManagerSg.createQuery("select o from com.sc.rdc.csl.ss.dal.sg.entity.WealthLendingCustEntity o WHERE o.customerId = :customerId AND o.customerIdType = :customerIdType");
        query.setParameter("customerId", user.getCustomerId());
        query.setParameter("customerIdType", user.getCustomerTypeId());
        List<WealthLendingCustEntity> custVoList = query.getResultList();
        WealthLendingCustEntity wealthLendingCustVO = null;
        if (!custVoList.isEmpty()) {
            wealthLendingCustVO = custVoList.get(0);
        }
        return wealthLendingCustVO;
    }

    
}
