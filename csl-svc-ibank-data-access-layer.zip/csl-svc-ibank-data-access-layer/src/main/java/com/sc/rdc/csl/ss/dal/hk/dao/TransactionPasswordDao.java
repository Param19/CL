package com.sc.rdc.csl.ss.dal.hk.dao;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.hk.entity.TransactionPasswordEntity;

@Repository(value = "transactionPasswordDaoServiceHk")
@Slf4j
public class TransactionPasswordDao extends BaseDao {

	@Autowired
	@Qualifier("cslRequestContext")
	CSLRequestContext requestContext;

	public TransactionPasswordEntity getTransactionPassword(String ebid) {
		log.info("TransactionPasswordDao:getTransactionPassword,{}");
		Query query = entityManagerHk.createQuery("select a from " + TransactionPasswordEntity.class.getSimpleName()
				+ " a where a.ebid=:ebid");
		query.setParameter("ebid", ebid);
		TransactionPasswordEntity transactionPasswordEntity = null;
		
		try {
			transactionPasswordEntity = (TransactionPasswordEntity) query.getSingleResult();
		} catch (NoResultException nre) {
			throw new BusinessException(ErrorConstant.TRANSACTION_PASSWORD_NOT_FOUND_FOR_EBID);
		} catch (Exception ex) {
			throw new BusinessException(ErrorConstant.TRANSACTION_PASSWORD_NOT_FOUND_FOR_EBID);
		}

		if (null == transactionPasswordEntity) {
			throw new BusinessException(ErrorConstant.TRANSACTION_PASSWORD_NOT_FOUND_FOR_EBID);
		}
		return transactionPasswordEntity;
	}
	
	public void save(TransactionPasswordEntity transactionPasswordEntity) {
		log.info("TransactionPasswordDao:TransactionPasswordEntity,{}");
		try {
			entityManagerHk.merge(transactionPasswordEntity);
		} catch (Exception ex) {
			log.info("Error TP", ex);
			throw new BusinessException(ErrorConstant.TRANSACTION_PASSWORD_SAVE_FAILED);
		}
	}
}
