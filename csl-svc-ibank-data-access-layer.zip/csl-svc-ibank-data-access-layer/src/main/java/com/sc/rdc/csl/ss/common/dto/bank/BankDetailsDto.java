package com.sc.rdc.csl.ss.common.dto.bank;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonApiResource(type = "banks")

public class BankDetailsDto extends SsBaseDto {

    private static final long serialVersionUID = 7058050166460825314L;

    @JsonApiId
    private String id;



    @JsonProperty("bankName")
    private String bankName;

    @JsonProperty("bankCode")
    private String bankCode;


}
