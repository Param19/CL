package com.sc.rdc.csl.ss.dal.in.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerContact;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import com.sc.rdc.csl.ss.dal.in.dao.CustDetailDao;
import com.sc.rdc.csl.ss.dal.in.entity.CustomerEntity;

import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service(value = "custDetailServiceIN")
public class CustDetailService extends CustomerDetailService {


    @Qualifier("custDetailDaoIN")
    @Autowired
    private CustDetailDao custCustDao;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Transactional(value = "transactionManagerIn" , readOnly = true)
    @LogTimeTaken
    public CustomerContact getCustomerContact(String countryCode,String customerId) {
        log.info("CustDetailService getCustomerContact() ");
        CustomerEntity custEntity = custCustDao.getCustomerDetail(customerId);
        log.info("CustomerDetailEntity :: {} ",custEntity);
        if(custEntity!=null) {
            CustomerContact custContact = new CustomerContact();
            custContact.setContactDetails(custEntity.getMobileNumber());
            custContact.setContactTypeCode("MF1");
            custContact.setRelId(cslRequestContext.getRelId());
            return custContact;
        }
        return null;
    }
}