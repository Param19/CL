package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.audit.Audit;

public class IAuditService {

	 public Audit auditTransaction(Audit audit,SsCSLUser user) {
	        return null;
	  }
}
