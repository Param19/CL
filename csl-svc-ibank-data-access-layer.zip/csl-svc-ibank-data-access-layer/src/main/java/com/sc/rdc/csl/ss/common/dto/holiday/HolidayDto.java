package com.sc.rdc.csl.ss.common.dto.holiday;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

/**
 * @author 1571806
 */
@Data
@JsonApiResource(type = "holidays")
public class HolidayDto extends SsBaseDto {

	private static final long serialVersionUID = 1L;

	@JsonApiId
	private String uuid = UUID.randomUUID().toString();
	private Date date;
	private String description;
	private Integer year;
	private Integer month;
	private Integer day;
}
