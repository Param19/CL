package com.sc.rdc.csl.ss.dal.sg.service;


import java.util.Optional;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.dal.sg.entity.CustomerStatusEntity;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerProfile;
import com.sc.rdc.csl.ss.dal.sg.entity.ProfileEntity;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICustomerService;
import com.sc.rdc.csl.ss.dal.sg.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.sg.dto.UserProfile;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.transaction.annotation.Transactional;


@Slf4j
@Service("customerServiceSg")
public class CustomerService extends ICustomerService {

    @Autowired
    @Qualifier("customerServiceDaoSg")
    private CustomerServiceDao customerServiceDao;

    @Autowired
    private MapperFacade orikaMapper;

    @Transactional(value = "transactionManagerSg", readOnly = true)
    @LogTimeTaken
    public CustomerProfile getCustomerProfile(SsCSLUser user) {
        CustomerProfile customer = new CustomerProfile();
        try {
            UserProfile profile = orikaMapper.map(getProfileEntity(user), UserProfile.class);
            customer.setProfile(profile);
            customer.setStatusCode(SsConstant.SS_SUCCESS_STATUS);
        } catch (Exception e) {
            log.error("Exception while fetching Customerprofile {} , {} ", user.getCustomerId(), e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_CUSTOMER);
        }
        return customer;
    }

    public Profile getProfile(SsCSLUser user) {
        try {
            return orikaMapper.map(getProfileEntity(user), Profile.class);
        } catch (Exception e) {
            log.error("Exception while fetching Customerprofile {} , {} ", user.getCustomerId(), e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_CUSTOMER);
        }
    }

    @Transactional("transactionManagerSg")
    @LogTimeTaken
    public void updateProfile(SsCSLUser user, Profile profile) {
        if (profile.getCustSeqNo()== null) {
            throw new BusinessException(ErrorConstant.ERR_NO_CUSTID);
        }
        updateUnderlyingProfileTables(profile);
    }

    private void updateUnderlyingProfileTables(Profile profile) {
        CustomerStatusEntity customerStatusEntity = customerServiceDao.getCustomerStatus(profile.getCustSeqNo());
        orikaMapper.map(profile, customerStatusEntity);
        customerServiceDao.update(customerStatusEntity);
    }

    private ProfileEntity getProfileEntity(SsCSLUser user) {
    	
        if (StringUtils.isEmpty(user.getCustomerId()) && StringUtils.isEmpty(user.getUaas2id())) {
            throw new BusinessException(ErrorConstant.ERR_NO_CUSTID);
        }

        Optional<ProfileEntity> profileEntity = Optional.ofNullable(customerServiceDao.getCustomerProfile(user));
        profileEntity.orElseThrow(() -> new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION));
        return profileEntity.get();
    }

}
