package com.sc.rdc.csl.ss.dal.ae.dao;

import org.springframework.stereotype.Repository;
import com.sc.rdc.csl.ss.dal.ae.entity.AuditEntity;
import lombok.extern.slf4j.Slf4j;

@Repository(value = "auditServiceDaoAe")
@Slf4j
public class AuditServiceDao extends BaseDao {

	public AuditEntity auditTransaction(AuditEntity auditEntity){
		log.info("call AuditServiceDao : auditTransaction");
		entityManagerAe.merge(auditEntity);
		log.info("call AuditServiceDao : auditTransaction done");
		return auditEntity;
	}
}
