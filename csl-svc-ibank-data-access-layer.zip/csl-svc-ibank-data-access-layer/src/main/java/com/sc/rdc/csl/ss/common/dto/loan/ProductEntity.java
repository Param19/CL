package com.sc.rdc.csl.ss.common.dto.loan;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountConstant;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ProductEntity extends BaseDto {
    private static final long serialVersionUID = -1L;

    private Integer index;
    private String customerId;
    private String customerIdType;
    private String productCode;
    private String subProductCode;
    private String accountNumber;
    private String accountName;
    private String accountDescription;
    private String consolidatedCode;

    private String accountStatus;
    private String blockCode;
    private String relationshipCode;

    private String currencyCode;
    private BigDecimal currentBalance;
    private BigDecimal availableBalance;

    private Integer customOrder = AccountConstant.DEFAULT_ORDER;
    private Integer productOrder = AccountConstant.DEFAULT_ORDER;

    // complete info populate from BEH/24x7
    // e.g. when get card list, isFullInfo = false, after calling GetCardDetails will set isFullInfo = true
    private boolean isFullInfo;

    //private boolean isOnline;	// is from online or 24x7

    //For Loan: do not remove invalid status from loanlist but set flag instead.
    private boolean isValidStatus;

}
