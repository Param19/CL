package com.sc.rdc.csl.ss.dal.my.entity;

import java.io.Serializable;
import java.sql.Timestamp;

public class AuditEntity implements Serializable {

	private static final long serialVersionUID = 1L;

		
	private String sessionId;
	private String txnId;
	private long id;
	private String useCase;
	private String logEvent;
	
	private String backendTxnId;
	private Timestamp logTimestamp;
	private String logException;
	private String activityStatus;
	private String activityDesc;

	private String customerId;
	private String ebid;
	private String pinchangeStaus;
	private String errorCode;
	private String cardNumber;
	private String cardType;	
	private String customerType;
	
	private String cardEmbossedName;
	private String reasonForFailure;
	private String channel;
	private String cardActivationStatus;
	private String txnType;
	
	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}


	public String getUseCase() {
		return useCase;
	}

	public void setUseCase(String useCase) {
		this.useCase = useCase;
	}

	public String getLogEvent() {
		return logEvent;
	}

	public void setLogEvent(String logEvent) {
		this.logEvent = logEvent;
	}

	public String getBackendTxnId() {
		return backendTxnId;
	}

	public void setBackendTxnId(String backendTxnId) {
		this.backendTxnId = backendTxnId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Timestamp getLogTimestamp() {
		return logTimestamp;
	}

	public void setLogTimestamp(Timestamp logTimestamp) {
		this.logTimestamp = logTimestamp;
	}

	public String getLogException() {
		return logException;
	}

	public void setLogException(String logException) {
		this.logException = logException;
	}

	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}

	public String getActivityDesc() {
		return activityDesc;
	}

	public void setActivityDesc(String activityDesc) {
		this.activityDesc = activityDesc;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getEbid() {
		return ebid;
	}

	public void setEbid(String ebid) {
		this.ebid = ebid;
	}

	public String getPinchangeStaus() {
		return pinchangeStaus;
	}

	public void setPinchangeStaus(String pinchangeStaus) {
		this.pinchangeStaus = pinchangeStaus;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCardEmbossedName() {
		return cardEmbossedName;
	}

	public void setCardEmbossedName(String cardEmbossedName) {
		this.cardEmbossedName = cardEmbossedName;
	}

	public String getReasonForFailure() {
		return reasonForFailure;
	}

	public void setReasonForFailure(String reasonForFailure) {
		this.reasonForFailure = reasonForFailure;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCardActivationStatus() {
		return cardActivationStatus;
	}

	public void setCardActivationStatus(String cardActivationStatus) {
		this.cardActivationStatus = cardActivationStatus;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

}
