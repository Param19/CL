/**
 * CASAMapping.java / Jun 16, 2017 / CSL-SVC-CASAS-1.0.0
 */
package com.sc.rdc.csl.ss.dal.ae.mapping;

import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.dto.customer.ReferenceDto;
import com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO;
import com.sc.rdc.csl.ss.dal.ae.entity.customer.ReferenceEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class CustomerDetailMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        orikaMapperFactory
                .classMap(CustomerDetailDto.class, CustomerVO.class)
                .field("rellId","customerId")
                .field("segmentcode","segmentCode")
                .byDefault()
                .register();

        orikaMapperFactory
                .classMap(ReferenceDto.class, ReferenceEntity.class)
                .field("statusCd","statusCode")
                .byDefault()
                .register();
    }


}

