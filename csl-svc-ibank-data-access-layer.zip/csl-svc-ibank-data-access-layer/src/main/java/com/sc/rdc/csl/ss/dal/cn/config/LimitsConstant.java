package com.sc.rdc.csl.ss.dal.cn.config;

import java.util.Arrays;
import java.util.List;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
public class LimitsConstant {

    public static final String LOCAL_CURRENCY = "CNY";
    public static final String RATE_TYPE = "B";
    public static final String MULTIPLIER = "M";
    public static final String CUSTOMER_DAILY_LIMIT = "CDTL";
    public static final String STATUS_ENABLED = "Enabled";
    public static final String PER_TRANS_LIMIT = "PTL";
    public static final String OVERALL_INTRDAY_LIMIT = "OIDL";
    public static final String INTRADAY_DAILY_LIMIT = "IDL";
    public static final String DAILY_TRANS_LIMIT = "DDTL";
    public static final List LIMIT_TYPES = Arrays.asList("OIDL", "IDL", "DDTL", "NDTL", "PTL");
    public static final String DATE_FORMATTER = "MM/dd/yyyy";
    public static final String OWN_ACCOUNT_TRANS_TYPE = "15";
    public static final String THIRD_PARTY_TRANS_TYPE = "16";
    public static final String HYPHEN = "-";

}
