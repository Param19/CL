package com.sc.rdc.csl.ss.dal.cn.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import com.sc.rdc.csl.ss.common.dto.payment.SSGlobalLinkTransferDetailsDto;
import com.sc.rdc.csl.ss.common.dto.payment.ScheduledTransactionsSafeDto;
import com.sc.rdc.csl.ss.common.service.IPaymentService;
import com.sc.rdc.csl.ss.dal.cn.config.TransferConfig;
import com.sc.rdc.csl.ss.dal.cn.dao.PaymentServiceDao;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.GLPaymentEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.PaymentEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.ScheduledTransactionsSafeEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.ss.common.helper.Constants.CN;
import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_NO_PAYMENT;
import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_PAYMENT_EXISTS;

@Slf4j
@Service(value = "paymentServiceCn")
public class PaymentService extends IPaymentService {

    @Autowired
    private MapperFacade orikaMapperFacade;
            
    @Qualifier("paymentServiceDaoCn")
    @Autowired
    private PaymentServiceDao paymentServiceDao;

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    @Autowired
    private TransferConfig transferConfig;

    public static final Map<String, String> txnStatusCodeMap = new HashMap<String, String>() {{
        put("0000", "3"); //SUCCESS
        put("0001", "4"); //Rejected
        put("0002", "2"); //Submitted
        put("0003", "6"); //Processing
        put("0004", "7"); //Scheduled
    }};

    @Transactional("transactionManagerCn")
    @Override
    @LogTimeTaken
    public  PaymentDto submitPayment(PaymentDto paymentDto){
        String origTxnId = paymentDto.getTransactionId();
        ScheduledTransactionsSafeEntity scheduledTransactionsSafeEntity = null;
        GLPaymentEntity glPaymentEntity = null;
        paymentDto.setTransactionId(getPrefixedTxnId(origTxnId));
        if(StringUtils.isNotBlank(paymentDto.getBranchCode()) && StringUtils.isNotBlank(paymentDto.getBranchName())) {
            paymentDto.setBranchCode(paymentDto.getBranchCode() + "-" + paymentDto.getBranchName());
            paymentDto.setBranchCode(StringUtils.substring(paymentDto.getBranchCode(),0,45));
        }
        log.info("Submit Payment for Transaction Id {}", paymentDto.getTransactionId());
        PaymentEntity entity = orikaMapperFacade.map(paymentDto, PaymentEntity.class);
        if(paymentDto!=null && paymentDto.getSsSafePaymentDto()!=null){
            ScheduledTransactionsSafeDto scheduledTransactionsSafeDto =  paymentDto.getSsSafePaymentDto();
            scheduledTransactionsSafeDto.setTransactionId(getPrefixedTxnId(scheduledTransactionsSafeDto.getTransactionId()));
           scheduledTransactionsSafeEntity = orikaMapperFacade.map(scheduledTransactionsSafeDto ,ScheduledTransactionsSafeEntity.class);
        }
        if(paymentDto.getSsGLFTDetailsDto()!= null){
            SSGlobalLinkTransferDetailsDto ssGlobalLinkTransferDetailsDto =  paymentDto.getSsGLFTDetailsDto();
            ssGlobalLinkTransferDetailsDto.setTransactionId(getPrefixedTxnId(ssGlobalLinkTransferDetailsDto.getTransactionId()));
            glPaymentEntity = orikaMapperFacade.map(ssGlobalLinkTransferDetailsDto ,GLPaymentEntity.class);
        }

        entity.setCreatedDate(new Date());
        entity.setCreatedBy(cslRequestContext.getUaas2id());
        entity.setUpdatedDate(new Date());
        entity.setUpdatedBy(cslRequestContext.getUaas2id());
        entity.setProcessedTimestamp(new Date());
        log.info("Submit Payment for Transaction Id {}, PaymentDto {}", paymentDto.getTransactionId(), entity);
        if(getPayment(paymentDto.getTransactionId())!=null)
            throw new BusinessException(SS_PAYMENT_EXISTS);
        entity = paymentServiceDao.insertPayment(entity);
        if(scheduledTransactionsSafeEntity != null){
            paymentServiceDao.insertSafeDetails(scheduledTransactionsSafeEntity);
        }
        if(glPaymentEntity != null){
            Date currentDate = new Date();
            glPaymentEntity.setId(origTxnId);
            glPaymentEntity.setUpdatedDate(currentDate);
            glPaymentEntity.setCreatedDate(currentDate);
            glPaymentEntity.setLastUpdatedBy("SYSTEM");
            glPaymentEntity.setChannelCode("IBK");
            glPaymentEntity.setAppLanguage(cslRequestContext.getLanguage());
            paymentServiceDao.insertGLPaymentDetails(glPaymentEntity);
        }

        return getPaymentDto(entity, origTxnId);
    }

    @Transactional("transactionManagerCn")
    @Override
    @LogTimeTaken
    public  PaymentDto updatePayment(PaymentDto paymentDto){
        String origTxnId = paymentDto.getTransactionId();
        paymentDto.setTransactionId(getPrefixedTxnId(origTxnId));
        log.info("Update Payment for Transaction Id {}, PaymentDto {}", paymentDto.getTransactionId(), paymentDto);
        PaymentEntity entity = paymentServiceDao.getPayment(paymentDto.getTransactionId());
        if(entity!=null) {
            entity.setTransactionStatus(txnStatusCodeMap.get(paymentDto.getTransactionStatusCode()));
            entity.setUpdatedDate(new Date());
            //entity.setUpdatedBy(user.getUaas2id());
            entity = paymentServiceDao.updatePayment(entity);
            return getPaymentDto(entity, origTxnId);
        } else
            throw new BusinessException(SS_NO_PAYMENT);
    }

    @Transactional("transactionManagerCn")
    @Override
    @LogTimeTaken
    public PaymentDto getPayment(String origTxnId){
        String prefixedTxnId = getPrefixedTxnId(origTxnId);
        log.info("Get Payment for TransactionId {}", prefixedTxnId);
        PaymentEntity entity = paymentServiceDao.getPayment(prefixedTxnId);
        return getPaymentDto(entity, origTxnId);
    }

    private PaymentDto getPaymentDto(PaymentEntity entity, String origTxnId) {
        PaymentDto responseDto = orikaMapperFacade.map(entity, PaymentDto.class);
        if(responseDto!=null)
            responseDto.setTransactionId(origTxnId);
        return responseDto;
    }

    private String getPrefixedTxnId(String origTxnId) {
        String prefix = transferConfig.getPrefixTxnId().get(CN);
        if(StringUtils.isNotBlank(origTxnId) && StringUtils.isNotBlank(prefix)) {
            if(!origTxnId.startsWith(prefix)) {
                return prefix + origTxnId;
            }
        }
        return origTxnId;
    }
}
