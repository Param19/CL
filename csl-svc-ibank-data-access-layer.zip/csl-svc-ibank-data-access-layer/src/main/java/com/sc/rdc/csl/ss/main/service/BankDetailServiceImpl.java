package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.dto.bank.BankDetailsDto;
import com.sc.rdc.csl.ss.common.service.BankDetailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("bankDetailServiceImpl")
@Slf4j
public class BankDetailServiceImpl extends BankDetailService {

    @Autowired
    private BankDetailServiceFactory bankDetailServiceFactory;


    @Override
    public List<BankDetailsDto> getBankDetails(BankDetailsDto bankDetailsDto) {

        List<BankDetailsDto> bankList = bankDetailServiceFactory.getBankDetails(bankDetailsDto.getCountryCode()).getBankDetails(bankDetailsDto);
        return bankList;
    }
}
