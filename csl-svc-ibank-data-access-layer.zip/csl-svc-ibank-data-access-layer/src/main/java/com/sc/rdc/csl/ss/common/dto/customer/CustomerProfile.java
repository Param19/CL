package com.sc.rdc.csl.ss.common.dto.customer;

import java.io.Serializable;
import java.util.UUID;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.SerializeType;
import lombok.Data;

@JsonApiResource(type = "customer")
@Data
public class CustomerProfile extends SsBaseDto implements Serializable {

    @JsonApiId
    private String id = UUID.randomUUID().toString();
    
    private Integer statusCode;
    
    @JsonApiRelation(serialize=SerializeType.EAGER)
    private Profile profile;

}
