package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.unittrust.UnitTrustSummaryEntity;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Repository(value ="unitTrustDaoHk")
@Slf4j
public class UnitTrustDao extends BaseDao {

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<UnitTrustSummaryEntity> findAllUnitTrusts() {
        List<UnitTrustSummaryEntity> unitTrustList = new ArrayList<>();
        Query query = entityManagerHk.createQuery("select b.accountNumber, b.currencyCode, b.relId, b.availableBalance, b.productCode, b.subProductCode, t.fundShortName, t.fundCode from com.sc.rdc.csl.ss.dal.hk.entity.unittrust.UnitTrustBalanceEntity b, " +
                "com.sc.rdc.csl.ss.dal.hk.entity.unittrust.UnitTrustTransactionHistoryEntity t where b.accountNumber = t.accountNumber and b.relId = :relId");
        query.setParameter("relId", requestContext.getCustomerId());
        List<Object[]> unitTrusts = query.getResultList();
        log.info("No of UnitTrusts {} for User Id {}", unitTrusts.size(), requestContext.getRelId());
        for (Object[] unitTrustRecord : unitTrusts) {
            UnitTrustSummaryEntity unitTrustSummaryEntity = new UnitTrustSummaryEntity();
            unitTrustSummaryEntity.setAccountNumber((String)unitTrustRecord[0]);
            unitTrustSummaryEntity.setCurrencyCode((String)unitTrustRecord[1]);
            unitTrustSummaryEntity.setRelId((String)unitTrustRecord[2]);
            unitTrustSummaryEntity.setAvailableBalance((BigDecimal)unitTrustRecord[3]);
            unitTrustSummaryEntity.setProductCode((String)unitTrustRecord[4]);
            unitTrustSummaryEntity.setSubProductCode((String)unitTrustRecord[5]);
            unitTrustSummaryEntity.setFundShortName((String)unitTrustRecord[6]);
            unitTrustSummaryEntity.setFundCode((String)unitTrustRecord[7]);
            unitTrustList.add(unitTrustSummaryEntity);
        };
        findAllInvestmentAccounts().forEach(investmentAccount -> {
            UnitTrustSummaryEntity unitTrustSummaryEntity = new UnitTrustSummaryEntity();
            unitTrustSummaryEntity.setAccountNumber(investmentAccount.getAccountNumber());
            unitTrustSummaryEntity.setCurrencyCode(investmentAccount.getCurrencyCode());
            unitTrustSummaryEntity.setRelId(requestContext.getCustomerId());
            unitTrustSummaryEntity.setAvailableBalance(investmentAccount.getAvailableBalance());
            unitTrustSummaryEntity.setFundShortName("");
            unitTrustSummaryEntity.setFundCode(investmentAccount.getProductCode());
            unitTrustList.add(unitTrustSummaryEntity);
        });
        return unitTrustList;
    }

    private List<AccountEntity> findAllInvestmentAccounts() {
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity a WHERE a.customerId = :customerId " +
                "and a.productCode in ('SXA','BND','CDA-F0')");
        query.setParameter("customerId", requestContext.getCustomerId());
        List<AccountEntity> accountEntityList = query.getResultList();
        log.info("Received {} AccountSummary record(s) from DB for User Id {}",
                (accountEntityList != null ? accountEntityList.size() : 0), requestContext.getCustomerId());
        return accountEntityList;
    }
}

