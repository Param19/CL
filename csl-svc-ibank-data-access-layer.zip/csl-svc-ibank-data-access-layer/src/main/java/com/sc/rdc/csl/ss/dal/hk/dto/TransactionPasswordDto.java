package com.sc.rdc.csl.ss.dal.hk.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;

import java.util.Date;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@Data
@JsonApiResource(type = "transactionpassword")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class TransactionPasswordDto {
	
	@JsonApiId
	private String id;
	private String ebid;
	private String transactionPassword;
	private String aesPassword;
	private String pswdCounter;
	private Date dateLocked;
}
