package com.sc.rdc.csl.ss.dal.pk.entity.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CustomerDetailEntity extends BaseDto {

   private static final long serialVersionUID = -1L;

   private Long      id;
   private String   customerId;
   private String   ebid;
   private String   customerIdType;
   private String   segmentCode;
}
