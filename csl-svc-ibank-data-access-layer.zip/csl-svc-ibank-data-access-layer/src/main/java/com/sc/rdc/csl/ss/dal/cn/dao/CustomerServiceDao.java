package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.rdc.csl.ss.dal.cn.entity.customer.CustomerProfileEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;

@Repository(value ="customerServiceDaoCn")
@Slf4j
public class CustomerServiceDao extends BaseDao{


    public CustomerProfileEntity getCustomerProfile(String id) {
        log.info("CustomerServiceDao:getCustomerProfile,{}", id);
        Query query = entityManagerCn.createQuery("select  o from com.sc.rdc.csl.ss.dal.cn.entity.customer.CustomerProfileEntity o WHERE o.customerId = :customerId ");
        query.setParameter("customerId", id);
        CustomerProfileEntity profile = (CustomerProfileEntity) query.getSingleResult();
        log.info("Received getCustomerProfile from DB:" + profile);
        return profile;
    }
}
