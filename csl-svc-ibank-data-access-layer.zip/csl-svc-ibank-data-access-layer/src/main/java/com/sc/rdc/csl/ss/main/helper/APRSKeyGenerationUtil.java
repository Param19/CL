package com.sc.rdc.csl.ss.main.helper;

import java.net.InetAddress;
import java.net.UnknownHostException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class APRSKeyGenerationUtil {

	private static APRSKeyGenerationUtil instance=null;
	private static volatile long uuid=0;
	private static volatile int xx=0;
	private static  byte[] netAddress = null;
	private APRSKeyGenerationUtil()
	{
		//uuid=uuid=System.currentTimeMillis();
		try {
			netAddress = InetAddress.getLocalHost().getAddress();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			log.error("Exception During access IP Address "+e.getLocalizedMessage());
		} 	
	}
	public static APRSKeyGenerationUtil getInstance()
	{
		if(instance==null)
		{
			instance=new APRSKeyGenerationUtil();
		}
		return instance;
	}
	public long getUUID()
	{
		uuid = System.currentTimeMillis();
		int x =(this.hashCode() & 0xFFFF)^ byteArrayToInt(netAddress, 1);		
		long id= Long.parseLong(String.valueOf(x)+String.valueOf(uuid & 0xFFFFFFF));
		return id;
	}
	
	public static int byteArrayToInt(byte[] b, int start) {
		int value = 0;
		for (int i = 0; i < b.length; i++) {
			int shift = (4 - 1 - i) * 8;
			value += (b[i ] & 0x000000FF) << shift;
		}
		return value;
	}
	
	public int hashCode() {
		// TODO Auto-generated method stub
		if(Integer.MAX_VALUE-1==xx){
			xx=super.hashCode();
		}
		else if(xx==0){		
			xx=super.hashCode();
		}
		return ++xx;
	}
}
