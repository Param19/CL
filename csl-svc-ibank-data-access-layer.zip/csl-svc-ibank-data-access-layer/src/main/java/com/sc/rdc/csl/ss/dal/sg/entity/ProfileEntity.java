package com.sc.rdc.csl.ss.dal.sg.entity;


import lombok.Data;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;
import java.sql.Date;

/**
 * @author Vasan.A.K (1530292)
 */
@Data
@Entity
@Table(name = "VW_CUST_IBNK", schema = "SCBCIF")
public class ProfileEntity {

    @Id
    @Column(name = "CUST_SEQ_NO")
    private Long custSeqNo;

    @Column(name = "CUST_ID")
    private String customerId;

    @Column(name = "CUST_EBID")
    private String customerEBID;

    @Column(name = "CUST_PBID")
    private String customerPBID;

    @Column(name = "CUST_ID_TYP_CD")
    private String customerIdType;

    @Column(name = "CUST_NM_1")
    private String custName1;

    @Column(name = "CUST_NM_2")
    private String custName2;

    @Column(name = "CUST_NICKNAME")
    private String custNickName;

    @Column(name = "CUST_MOBILE_PHONE")
    private String mobilePhone;

    @Column(name = "CUST_SCB_IND")
    private String scbIndicator;

    @Column(name = "CUST_ARM")
    private String armCode;

    @Column(name = "CUST_EMPLOYER")
    private String employerFlag;

    @Column(name = "CUST_EMAIL_ADDR")
    private String emailAddress;

    @Column(name = "CUST_SERV_SEQ_NO")
    private BigInteger custServSeqNo;

    @Column(name = "CUST_STATUS_CD")
    private String statusCode;

    @Column(name = "PREFERRED_LOGIN")
    private String preferredLogin;
    
    @Column(name = "DT_LAST_LOGIN")
    private Date lastLogin;

    @Column(name="TWO_FA_TYP_CD")
    private String twoFAType;

    @Column(name="ALP_COUNTER")
    private Integer alpCounter;

    @Column(name="NOTIF_TYP_CD")
    private String notificationType;

    @Column(name="IS_CARD_SELECTED")
    private String isCardSelected;

    @Column(name = "IS_LOCKED")
    @Type(type="yes_no")
    private Boolean isLocked;

    @Column(name = "LOCKED_REASON")
    private String lockedReason;
    
    @Column(name = "CUST_ACCESS_KEY")
    private String custAccessKey;
    
    @Column(name = "CURR_LANG")
    private String language;

}
