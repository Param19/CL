package com.sc.rdc.csl.ss.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.audit.LoginAudit;

@Service
public class LoginAuditServiceImpl {

	    @Autowired
	    private LoginAuditServiceFactory loginAuditServiceFactory;

	    @Autowired
	    @Qualifier("cslRequestContext")
	    CSLRequestContext requestContext;
	    
	    
	    public LoginAudit  insertLoginAuditData(LoginAudit loginAudit){
	    	return loginAuditServiceFactory.getLoginAuditService(requestContext.getCountry()).insertLoginAudit(loginAudit);
	    }
}
