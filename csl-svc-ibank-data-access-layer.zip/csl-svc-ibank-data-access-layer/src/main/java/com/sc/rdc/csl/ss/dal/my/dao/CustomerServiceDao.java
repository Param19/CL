package com.sc.rdc.csl.ss.dal.my.dao;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION;

import java.util.List;

import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.dal.my.entity.CustomerEntity;

import lombok.extern.slf4j.Slf4j;

@Repository(value ="customerServiceDaoMY")
@Slf4j
public class CustomerServiceDao extends BaseDao{

    public CustomerEntity getCustomerProfile(SsCSLUser user) {
        log.info("CustomerServiceDao:getCustomerProfile,{}", user);
      CustomerEntity customerProfile = null;
      Query query = null;
       if(StringUtils.isNotBlank(user.getUaas2id())){
    	   query = entityManagerMY.createQuery("from com.sc.rdc.csl.ss.dal.my.entity.CustomerEntity cust where cust.customerEBID = :customerEBID and cust.customerStatusCode = :activeStatus AND lastLoginDate IS NOT NULL ORDER BY lastLoginDate DESC");
           query.setParameter("customerEBID", user.getUaas2id());
           query.setParameter("activeStatus", "A");
           customerProfile = (CustomerEntity) query.getSingleResult();
       }else{
	        query = entityManagerMY.createQuery("from com.sc.rdc.csl.ss.dal.my.entity.CustomerEntity cust where cust.customerId = :customerId and cust.customerIdType = :customerIdType and cust.customerStatusCode = :activeStatus AND lastLoginDate IS NOT NULL ORDER BY lastLoginDate DESC");
	        query.setParameter("customerId", user.getCustomerId());
	        query.setParameter("customerIdType", user.getCustomerTypeId());
	        query.setParameter("activeStatus", "A");
	        customerProfile = (CustomerEntity) query.getSingleResult();
       }
        log.debug("Received getCustomerProfile from DB:" + customerProfile);
        return customerProfile;
    }
    
    public String getCustomerEBID(String customerId){
    	
    	 String GET_CUSTOMER_DETAIL = "select  o from com.sc.rdc.csl.ss.dal.my.entity.CustomerEntity o WHERE o.customerId = :customerId ";
    	 
         log.info("CustomerId:", customerId);
         Query query = entityManagerMY.createQuery(GET_CUSTOMER_DETAIL);
         query.setParameter("customerId", customerId);
         List<CustomerEntity> customerdetails = query.getResultList();
         String messageSenderId =null;
         log.info("customerdetails Record", customerdetails.size());
        if(customerdetails!=null && customerdetails.size()>0)
         {
        	CustomerEntity customerEntity = (CustomerEntity)customerdetails.get(0);
             messageSenderId = customerEntity.getCustomerEBID();
         }
         else {
             throw new BusinessException(CUSTOMER_NO_RECORD_EXCEPTION);
         }
         return messageSenderId;
    }
}

