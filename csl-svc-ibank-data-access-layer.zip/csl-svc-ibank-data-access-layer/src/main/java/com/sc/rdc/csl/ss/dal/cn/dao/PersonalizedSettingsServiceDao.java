package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.dal.cn.entity.PersonalizedSettingsEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

@Repository(value ="personalizedSettingsServiceDaoCn")
@Slf4j
public class PersonalizedSettingsServiceDao extends BaseDao{

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<PersonalizedSettingsEntity> getPersonalizedSettingsEntity() {
        log.info("PersonalizedSettingsServiceDao:getPersonalizedSettingsEntity");
        Query query = entityManagerCn.createQuery("select a from com.sc.rdc.csl.ss.dal.cn.entity.PersonalizedSettingsEntity a WHERE a.customerId = :customerId and a.preferredLanguage = :preferredLanguage")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("customerId", requestContext.getRelId());
        query.setParameter("preferredLanguage", requestContext.getLanguage());
        List<PersonalizedSettingsEntity> personalizedSettingsEntityList = query.getResultList();
        log.info("Received {} PersonalizedSettingsEntity record(s) from DB for User Id {}",
                (personalizedSettingsEntityList != null ? personalizedSettingsEntityList.size() : 0), requestContext.getRelId());
        
        return personalizedSettingsEntityList;
    }
}
