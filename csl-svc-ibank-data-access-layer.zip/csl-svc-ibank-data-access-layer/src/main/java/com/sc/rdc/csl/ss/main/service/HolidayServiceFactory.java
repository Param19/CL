package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.service.IHolidayService;
import com.webmethods.jms.log.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class HolidayServiceFactory {
    private static final String serviceName = "holidayService";
    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private Environment environment;

    @Autowired
    private CSLRequestContext cslRequestContext;
    public IHolidayService getHolidayService() {
        Log.info("Getting Holiday instance from Application context for Country : {}", cslRequestContext.getCountry());
        String countryGroup = environment.getProperty("database.country.group.".concat(cslRequestContext.getCountry().toUpperCase()));
        String countryServiceName = serviceName.concat(countryGroup != null ? countryGroup : cslRequestContext.getCountry().toUpperCase());
        return applicationContext.getBean(countryServiceName, IHolidayService.class);
    }
}
