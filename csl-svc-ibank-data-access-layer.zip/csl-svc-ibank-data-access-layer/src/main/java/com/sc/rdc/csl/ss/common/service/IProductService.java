
package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.account.BndAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.CasaAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.WealthAccountDto;
import java.util.List;


public abstract class IProductService {
   
    public List<CasaAccountDto> getIdaAccountSummary(SsCSLUser user){
        return null;
    }
    
    
    public List<BndAccountDto> getBndAccountSummary(SsCSLUser user){
       return null;  
    }
    
    
    public List<WealthAccountDto> getInvAccountSummary(SsCSLUser user){
        return null; 
    }
    
}
