package com.sc.rdc.csl.ss.common.dto.card;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.BaseDto;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountConstant;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto extends BaseDto {

    private static final long serialVersionUID = -1L;

    @JsonProperty("index")
    private Integer index;
    @JsonProperty("rel-id")
    private String relId;
    @JsonProperty("rel-type")
    private String relIdType;
    private String customerIdType;
    @JsonProperty("product-code")
    private String productCode;
    @JsonProperty("sub-prod")
    private String subProd;
    @JsonProperty("card-num")
    private String cardNum;
    @JsonProperty("account-name")
    private String accountName;
    @JsonProperty("account-description")
    private String accountDescription;
    @JsonProperty("consolidated-code")
    private String consolidatedCode;

    @JsonProperty("account-status")
    private String accountStatus;
    @JsonProperty("block-code")
    private String blockCode;
    @JsonProperty("relationship-code")
    private String relationshipCode;

    @JsonProperty("currency-code")
    private String currencyCode;
    @JsonProperty("current-balance")
    private BigDecimal currentBalance;
    @JsonProperty("available-balance")
    private BigDecimal availableBalance;

    @JsonProperty("custom-order")
    private Integer customOrder = AccountConstant.DEFAULT_ORDER;
    @JsonProperty("product-order")
    private Integer productOrder = AccountConstant.DEFAULT_ORDER;   //    private FilterProductDto filterProductDto;
}

