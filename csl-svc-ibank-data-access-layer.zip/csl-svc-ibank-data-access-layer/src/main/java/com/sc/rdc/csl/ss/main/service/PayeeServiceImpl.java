package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.dto.payee.PayeeDto;
import com.sc.rdc.csl.ss.common.service.PayeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("payeeServiceImpl")
@Slf4j
public class PayeeServiceImpl extends PayeeService {

    @Autowired
    private PayeeServiceFactory payeeServiceFactory;

    @Override
    public void addPayee(PayeeDto payeeDto) {
        PayeeService payeeService = payeeServiceFactory.getPayeeDetails("AE");
        payeeService.addPayee(payeeDto);
    }

    @Override
    public PayeeDto getPayee(String payeeId) {
        PayeeDto payeeDto = payeeServiceFactory.getPayeeDetails("AE").getPayee(payeeId);
        return payeeDto;
    }

    @Override
    public void updatePayee(PayeeDto payeeDto) {
        PayeeService payeeService = payeeServiceFactory.getPayeeDetails("AE");
        payeeService.updatePayee(payeeDto);
    }

    @Override
    public void deletePayee(String id) {
        PayeeService payeeService = payeeServiceFactory.getPayeeDetails("AE");
        payeeService.deletePayee(id);
    }

    @Override
    public List<PayeeDto> getAllPayees() {
        PayeeService payeeService = payeeServiceFactory.getPayeeDetails("AE");
        return payeeService.getAllPayees();
    }
}
