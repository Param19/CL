package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.card.CreditCardTransactionDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICreditCardService;
import com.sc.rdc.csl.ss.main.service.CrediCardServiceFactory;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class CreditCardTransactionEndpoint extends ResourceRepositoryBase<CreditCardTransactionDto, String> {

    public CreditCardTransactionEndpoint() {
        super(CreditCardTransactionDto.class);
    }

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    private CrediCardServiceFactory cardTransactionFactory;

    @Override
    public CreditCardTransactionDto findOne(String id, QuerySpec querySpec) {
        throw new BusinessException(ErrorConstant.UNSUPPORTED_OPERATION);
    }

    @Override
    public ResourceList<CreditCardTransactionDto> findAll(QuerySpec querySpec) {
        log.info("CreditCardTransactionEndpoint findall ");
        ICreditCardService service = cardTransactionFactory.getCreditCardService(cslRequestContext.getCountry());
        List<CreditCardTransactionDto> transactionDtoList = new ArrayList<>();
        ResourceList<CreditCardTransactionDto> cardTransactionDto = new DefaultResourceList<>();
        if(!CollectionUtils.isEmpty(querySpec.getFilters())) {
            FilterSpec specs = querySpec.getFilters().get(0);
            List<String> fields = specs.getAttributePath();
            if (fields.contains("cardNum")) {
                transactionDtoList = service.getTransactionHistory(String.valueOf(specs.getValue()));
                if(!transactionDtoList.isEmpty()) {
                    cardTransactionDto.addAll(transactionDtoList);
                    return cardTransactionDto;
                }
            }
        } else {
            throw new BusinessException(ErrorConstant.UNSUPPORTED_OPERATION);
        }
        return querySpec.apply(transactionDtoList);
    }
}
