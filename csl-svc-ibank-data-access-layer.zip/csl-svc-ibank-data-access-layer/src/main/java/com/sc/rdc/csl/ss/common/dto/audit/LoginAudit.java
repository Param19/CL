package com.sc.rdc.csl.ss.common.dto.audit;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonApiResource(type = "loginaudits")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoginAudit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonApiId
	private String id = UUID.randomUUID().toString();
	
	@JsonProperty("status")
	private String status;
	
	@JsonProperty("channelcd")
	private String channelCd;
	
	@JsonProperty("usecase")
	private String useCase;
	
	@JsonProperty("channel")
	private String channel;
	
	@JsonProperty("activityDesc")
	private String activityDesc;
	
	@JsonProperty("activityStatus")
	private String activityStatus;
	
	@JsonProperty("backendTxnId")
	private String backendTxnId;

	@JsonProperty("customerBackendStatus")
	private String customerBackendStatus;
	
	@JsonProperty("customerId")
	private String customerId;
	
	@JsonProperty("customerStatus")
	private String customerStatus;
	
	@JsonProperty("ebid")
	private String ebid;
	
	@JsonProperty("isAuthorized")
	private Boolean isAuthorized;
	
	@JsonProperty("isAuthNeeded")
	private Boolean isAuthNeeded;
	
	@JsonProperty("isAuthRequired")
	private Boolean isAuthRequired;
	
	@JsonProperty("isCustInfoRetrieved")
	private Boolean isCustInfoRetrieved;
	
	@JsonProperty("isFirstTimeLogin")
	private Boolean isFirstTimeLogin;
	
	@JsonProperty("logEvent")
	private String logEvent;
	
	@JsonProperty("logException")
	private String logException;
	
	@JsonProperty("logTimestamp")
	private Date logTimestamp;
	
	@JsonProperty("moDcs")
	private String moDcs;
	
	@JsonProperty("moMessage")
	private String moMessage;
	
	@JsonProperty("moMsgId")
	private String moMsgId;
	
	@JsonProperty("moMsisdn")
	private String moMsisdn;
	
	@JsonProperty("moScNo")
	private String moScNo;
	
	@JsonProperty("moTimestamp")
	private Date moTimestamp;
	
	@JsonProperty("pinMailerSerialNo")
	private String pinMailerSerialNo;
	
	@JsonProperty("sessionId")
	private String sessionId;
	
	@JsonProperty("txnId")
	private String txnId;

	
	
}
