package com.sc.rdc.csl.ss.dal.sg.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import javax.sql.DataSource;

import com.sc.rdc.csl.ss.common.helper.Constants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
public class EntityManagerConfigSg {

    @Qualifier("entityManagerFactorySg")
    @Bean("entityManagerFactorySg")
    public LocalContainerEntityManagerFactoryBean entityManagerFactorySg(@Qualifier("db2DataSourceSg") DataSource db2DataSourceSg) {
        LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactory.setDataSource(db2DataSourceSg);
        entityManagerFactory.setPersistenceXmlLocation("classpath*:com/sc/rdc/csl/ss/resource/sg/persistence/persistence-sg.xml");
        entityManagerFactory.setPersistenceUnitName(Constants.PERSISTENCE_UNIT_SG);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(false);
        vendorAdapter.setDatabase(Database.DB2);
        entityManagerFactory.setJpaVendorAdapter(vendorAdapter);
        return entityManagerFactory;
    }

    @Qualifier("transactionManagerSg")
    @Bean("transactionManagerSg")
    public JpaTransactionManager transactionManagerSg(@Qualifier("entityManagerFactorySg") LocalContainerEntityManagerFactoryBean entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory.getObject());
        return transactionManager;
    }

    @Qualifier("exceptionTranslationSg")
    @Bean("exceptionTranslationSg")
    public PersistenceExceptionTranslationPostProcessor exceptionTranslationSg() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    @Qualifier("db2DataSourceSg")
    @Bean("db2DataSourceSg")
    @ConfigurationProperties(prefix = "sg.db2.datasource")
    public DataSource db2DataSourceSg() {
        return new ComboPooledDataSource();
    }
    
        
    

}
