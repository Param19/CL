package com.sc.rdc.csl.ss.dal.in.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.loan.LoanDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ILoanService;
import com.sc.rdc.csl.ss.dal.in.dao.ProductDescServiceDao;
import com.sc.rdc.csl.ss.dal.in.dao.LoanServiceDao;
import com.sc.rdc.csl.ss.dal.in.entity.LoanEntity;

import lombok.extern.slf4j.Slf4j;

import ma.glasnost.orika.MapperFacade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service("loanServiceIn")
public class LoanService extends ILoanService {
    @Autowired
    @Qualifier("loanServiceDaoIn")
    private LoanServiceDao loanServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    @Autowired
    @Qualifier("productDescServiceDaoIn")
    private ProductDescServiceDao productDescServiceDao;


    @Transactional(value = "transactionManagerIn" , readOnly = true)
    @LogTimeTaken
    public List<LoanDto> getLoanSummary() {
        List<LoanDto> loanDtoList = new ArrayList<>();
        try {
            Optional<List<LoanEntity>> loanEntityList = Optional.ofNullable(loanServiceDao.getLoanSummary());
            loanEntityList.orElseThrow(() -> new BusinessException(ErrorConstant.LOAN_ACCOUNT_NOT_FOUND));
            loanEntityList.get().forEach(loanEntity -> {
                LoanDto loanDto = orikaMapperFacade.map(loanEntity, LoanDto.class);
                loanDto.setProductDescription(productDescServiceDao.getproductDescription(loanDto.getProductCode(), loanDto.getSubProductCode(), requestContext.getLanguage()));
                loanDtoList.add(loanDto);

            });
            log.info("Orika mapper result :", loanDtoList);
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Loan Summary for user {} , {} ", requestContext.getCustomerId(), e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return loanDtoList;
    }
    @Transactional(value = "transactionManagerIn" , readOnly = true)
    @LogTimeTaken
    public LoanDto getOneLoanDetail(String accountId) {
        try {
            Optional<LoanEntity> loanEntity = Optional.ofNullable(loanServiceDao.getOneLoanDetail(accountId));
            loanEntity.orElseThrow(() -> new BusinessException(ErrorConstant.LOAN_ACCOUNT_NOT_FOUND));
            LoanDto loanDto = orikaMapperFacade.map(loanEntity.get(), LoanDto.class);
            loanDto.setProductDescription(productDescServiceDao.getproductDescription(loanDto.getProductCode(), loanDto.getSubProductCode(), requestContext.getLanguage()));

            return loanDto;
        } catch (BusinessException businessException) {
            throw businessException;
        } catch (Exception e) {
            log.error("Exception while fetching Loan Summary for user {} , {} ", accountId);
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
    }
}
