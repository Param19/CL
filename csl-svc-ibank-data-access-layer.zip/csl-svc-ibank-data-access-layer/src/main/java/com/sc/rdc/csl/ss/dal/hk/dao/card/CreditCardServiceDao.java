package com.sc.rdc.csl.ss.dal.hk.dao.card;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.dto.card.CardDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.hk.dao.BaseDao;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CardCustEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CreditCardEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import javax.persistence.Query;
import java.util.List;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CARD_NO_RECORD_EXCEPTION;

@Repository(value ="creditCardServiceDaoHk")
@Slf4j
public class CreditCardServiceDao extends BaseDao {

    public List<CreditCardEntity> getCreditCardSummary(SsCSLUser user) {
        log.info("CreditCardServiceDao:getCreditCardSummary,{}" + user);
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.card.CreditCardEntity a WHERE a.relId = :relId")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("relId", user.getCustomerId());
        List<CreditCardEntity> creditCardEntityList = query.getResultList();

        log.info("Received {} CreditCardSummary record(s) from DB for User Id {}",
                (creditCardEntityList != null ? creditCardEntityList.size() : 0), user.getCustomerId());
        if(CollectionUtils.isEmpty(creditCardEntityList)){
            throw new BusinessException(ErrorConstant.CREDITCARD_NO_RECORD_EXCEPTION);
        }

        for (CreditCardEntity cardDto: creditCardEntityList) {
            cardDto.setCustomerId(cardDto.getRelIdType() + cardDto.getRelId());
        }

        return creditCardEntityList;
    }

    public List<CreditCardEntity> getProvidedCreditCardSummary(String customerId,List<String> creditCards) {
        log.info("CreditCardServiceDao:getCreditCardSummary,{}" + customerId);
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.card.CreditCardEntity a WHERE a.cardNum in (:cardNum)")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("cardNum", creditCards);
        List<CreditCardEntity> creditCardEntityList = query.getResultList();

        log.info("Received {} CreditCardSummary record(s) from DB for User Id {}",
                (creditCardEntityList != null ? creditCardEntityList.size() : 0), customerId);
        if(CollectionUtils.isEmpty(creditCardEntityList)){
            throw new BusinessException(ErrorConstant.CREDITCARD_NO_RECORD_EXCEPTION);
        }

        for (CreditCardEntity cardDto: creditCardEntityList) {
            cardDto.setCustomerId(cardDto.getRelIdType() + cardDto.getRelId());
        }

        return creditCardEntityList;
    }

    public CreditCardEntity getCreditCardDetails(String cardNo, SsCSLUser user) {
        CardDto cardDto = new CardDto();
        log.info("CreditCardServiceDao: getCreditCardDetails,{}", user);
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.card.CreditCardEntity a WHERE a.cardNum = :cardNum")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("cardNum", cardNo);
        List<CreditCardEntity> carddetails_data = query.getResultList();
        CreditCardEntity cardDetails = null;
        if(carddetails_data!=null && carddetails_data.size()>0)
        {
            cardDetails = (CreditCardEntity)carddetails_data.get(0);
        }
        else{
            cardDetails = getCreditCardDetailsforCCMS(cardNo);
        }
        cardDetails.setCustomerId(cardDetails.getRelIdType() + cardDetails.getRelId());
        log.info("Received Credit Card Details from DB for User Id {}, {} ", cardNo, cardDetails);
        return cardDetails;

    }


    public CreditCardEntity getCreditCardDetailsforCCMS(String cardNo) {
        CreditCardEntity creditCardEntityVO = null;
        log.info("CreditCardServiceDao:getCreditCardSummary,{}" + cardNo);
        Query query = entityManagerHk.createQuery("select o from com.sc.rdc.csl.ss.dal.hk.entity.card.CardCustEntity o WHERE o.cardNo = :cardNo")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("cardNo", cardNo);

        List<CardCustEntity> carddetails = query.getResultList();

        if(carddetails!=null && carddetails.size()>0)
        {
            CardCustEntity cardCustEntity = (CardCustEntity)carddetails.get(0);
            creditCardEntityVO = new CreditCardEntity();
            creditCardEntityVO.setRelId(cardCustEntity.getCustomerId());
            creditCardEntityVO.setRelIdType(cardCustEntity.getCustIdType());
        }
        else {
            throw new BusinessException(CARD_NO_RECORD_EXCEPTION);
        }
        return creditCardEntityVO;
    }

}