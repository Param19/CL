package com.sc.rdc.csl.ss.common.dto.wld;


public enum SourceOfFund {

    BUSINESS("BUSINESS"),
    SALARY("SALARY"),
    INHRET("INHRET");

    private String fund;

    private SourceOfFund() {
    }

    private SourceOfFund(String fund) {
        this.fund = fund;
    }

    @Override
    public String toString() {
        return fund;
    }

}
