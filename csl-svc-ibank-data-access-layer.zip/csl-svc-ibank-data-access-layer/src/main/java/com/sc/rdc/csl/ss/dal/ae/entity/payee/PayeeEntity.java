package com.sc.rdc.csl.ss.dal.ae.entity.payee;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PayeeEntity extends BaseDto {

    //@SequenceGenerator(name = "mygen")
    private Long id;
    private String payeeId;
    private String ebid;
    private String ibanNo;
    private String nickName;
    private String payeeType;
    private String acctNumber;
    private String payeeName;
    private String acctTypeCode;
    private String acctCurrency;
    private String address1;
    private String address2;
    private String address3;
    private String city;
    private String state;
    private String postcode;
    private String statusCd;
    private char isProcessed;
    private String email;
    private long version;
    private String bankBicCd;
    private String refNo;
    private String institutionName;
    private String acctCountry;
    private char emailAlert;
    private String makerId;
    private Date makerTime;
    private String checkerId;
    private Date checkerTime;
    private String actionCd;
    private String ctryCd;
    private String hostRespCd;
    private String hostRespDesc;
    private String benfcryCd;
    private String bankCd;
    private String payeeCountry;
}
