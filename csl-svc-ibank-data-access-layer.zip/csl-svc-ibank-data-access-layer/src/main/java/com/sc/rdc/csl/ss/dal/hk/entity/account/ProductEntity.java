package com.sc.rdc.csl.ss.dal.hk.entity.account;


import com.sc.rdc.csl.ss.common.dto.BaseDto;
import java.math.BigDecimal;

/**
 * @author 1236399
 * @since Apr 8, 2008 8:07:33 PM
 */
public class ProductEntity extends BaseDto {

    private static final long serialVersionUID = -1L;

    private Integer index;
    private String customerId;
    private String customerIdType;
    private String productCode;
    private String subProductCode;
    private String accountNumber;
    private String accountName;
    private String accountDescription;
    private String consolidatedCode;

    private String accountStatus;
    private String blockCode;
    private String relationshipCode;

    private String currencyCode;
    private BigDecimal currentBalance;
    private BigDecimal availableBalance;

    private Integer customOrder = AccountConstant.DEFAULT_ORDER;
    private Integer productOrder = AccountConstant.DEFAULT_ORDER;

    // complete info populate from BEH/24x7
    // e.g. when get card list, isFullInfo = false, after calling GetCardDetails will set isFullInfo = true
    private boolean isFullInfo;

    private boolean isOnline;	// is from online or 24x7

    //For Loan: do not remove invalid status from loanlist but set flag instead.
    private boolean isValidStatus;

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerIdType() {
        return customerIdType;
    }

    public void setCustomerIdType(String customerIdType) {
        this.customerIdType = customerIdType;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public String getSubProductCode() {
        return subProductCode;
    }

    public void setSubProductCode(String subProductCode) {
        this.subProductCode = subProductCode;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountDescription() {
        return accountDescription;
    }

    public void setAccountDescription(String accountDescription) {
        this.accountDescription = accountDescription;
    }

    public String getConsolidatedCode() {
        return consolidatedCode;
    }

    public void setConsolidatedCode(String consolidatedCode) {
        this.consolidatedCode = consolidatedCode;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getBlockCode() {
        return blockCode;
    }

    public void setBlockCode(String blockCode) {
        this.blockCode = blockCode;
    }

    public String getRelationshipCode() {
        return relationshipCode;
    }

    public void setRelationshipCode(String relationshipCode) {
        this.relationshipCode = relationshipCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(BigDecimal currentBalance) {
        this.currentBalance = currentBalance;
    }

    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(BigDecimal availableBalance) {
        this.availableBalance = availableBalance;
    }

    public Integer getCustomOrder() {
        return customOrder;
    }

    public void setCustomOrder(Integer customOrder) {
        this.customOrder = customOrder;
    }

    public Integer getProductOrder() {
        return productOrder;
    }

    public void setProductOrder(Integer productOrder) {
        this.productOrder = productOrder;
    }

    public boolean getIsFullInfo() {
        return isFullInfo;
    }

    public void setIsFullInfo(boolean fullInfo) {
        isFullInfo = fullInfo;
    }

    public boolean getIsOnline() {
        return isOnline;
    }

    public void setIsOnline(boolean isOnline) {
        this.isOnline = isOnline;
    }

    public boolean getIsValidStatus() {
        return isValidStatus;
    }

    public void setIsValidStatus(boolean isValidStatus) {
        this.isValidStatus = isValidStatus;
    }
}
