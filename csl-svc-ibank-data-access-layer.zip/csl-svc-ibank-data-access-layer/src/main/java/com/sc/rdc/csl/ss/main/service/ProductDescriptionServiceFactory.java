package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.ProductDescriptionService;
import com.sc.rdc.csl.ss.dal.hk.service.ProductDescService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.COUNTRY_NOT_ALLOWED;

@Component
@Slf4j
public class ProductDescriptionServiceFactory {

    @Qualifier("productDescServiceHK")
    @Autowired
    private ProductDescService productDescService;


    Map<String, ProductDescriptionService> map = new HashMap<>();


    public ProductDescriptionService getproductDescription(String country)
    {
        if (map.size() == 0)
            initMap();
        ProductDescriptionService cCardService = map.get(StringUtils.upperCase(country));
        if (cCardService != null)
            return cCardService;
        log.error("Country {} is not allowed to call Credit Card Service", country);
        throw new BusinessException(TemplateErrorCode.create(COUNTRY_NOT_ALLOWED, country, "CUSTOMER"));
    }
    private void initMap() {
        map.put(Constants.HK, productDescService);
    }
}
