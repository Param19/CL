package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.wld.ApplicationDto;


public abstract class IWealthLendingService  {

    public  SsBaseDto findWldCustomerDetails(SsCSLUser user){
        return null;
    }

    public SsBaseDto submitApplication(ApplicationDto applicationDto, SsCSLUser user) {
        return null;
    }

    public SsBaseDto updateApplication(ApplicationDto applicationDto, SsCSLUser user) {
        return null;
    }

    public SsBaseDto getApplication(String id, SsCSLUser user) {
        return null;
    }

    public SsBaseDto getAllApplication(String appStatus, SsCSLUser user) {
        return null;
    }
}
