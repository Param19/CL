package com.sc.rdc.csl.ss.common.dto.customer;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Data
@JsonApiResource(type = "profile")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Profile implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long custSeqNo;
    @JsonApiId
    private String relId;
    private String customerId;
    private String customerEBID;
    private String customerPBID;
    private String customerIdType;
    private String custName1;
    private String custName2;
    private String custNickName;
    private String mailAddr1;
    private String mailAddr2;
    private String mailAddr3;
    private String mailAddr4;
    private String mailDistrict;
    private String area;
    private String postalCode;
    private String country;
    private String residenceCode;
    private String nationalityCode;
    private String nationId;
    private String statusCode;
    private String openDate;
    private String branchCode;
    private String armCode;
    private String pbo;
    private String opbMarketingSegment;
    private String gender;
    private Date dob;
    private String maritalStatusCode;
    private String ethnic;
    private String staffRank;
    private String personalPhone;
    private String personalPhoneExt;
    private String businessPhone;
    private String businessPhoneExt;
    private String mobileCompany;
    private String mobilePhone;
    private String mobilePhoneBOA;
    private Double dailyLimit;
    private String employerFlag;
    private String scbIndicator;
    private String payIndicator;
    private String emailAddress;
    private Boolean isCOPP;
    private String dateLastCOPP;
    private String remark;
    private String segmentCode;
    private String subSegmentCode;
    private String mmStatus;
    private String mmMailCode;
    private String pbHoldMailFlag;
    private Date createdDate;
    private String userId;
    private String notificationType;
    private String twoFAType;
    private String preferredLogin;
    private String isCardSelected;
    private Integer alpCounter;
    private Boolean isLocked;
    private String lockedReason;
    private String language;
    private String custAccessKey;

    public String getRelId() {
        return customerIdType+customerId;
    }

    public String getPreferredLogin() {
        if (preferredLogin == null) {
            return twoFAType;
        }
        return preferredLogin;
    }
}
