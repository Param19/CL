package com.sc.rdc.csl.ss.dal.ae.entity;


import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

@Data
public class FilterProductEntity extends BaseDto {
    private static final long serialVersionUID = -1L;

    private String accountCode;
    private String productCode;
    private String productDescription;
    private String subProductCode;
    private String productKey;
    private String accountTypeAlias;

}


