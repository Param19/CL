package com.sc.rdc.csl.ss.dal.hk.service.holiday;

import com.sc.rdc.csl.ss.common.dto.holiday.HolidayDto;
import com.sc.rdc.csl.ss.common.service.IHolidayService;
import com.sc.rdc.csl.ss.dal.hk.dao.holiday.HolidayServiceDao;
import com.sc.rdc.csl.ss.dal.hk.entity.holiday.HolidayEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import java.util.List;

@Slf4j
@Service("holidayServiceHK")
public class HolidayService extends IHolidayService {
    @Autowired
    @Qualifier("holidayServiceDaoHk")
    private HolidayServiceDao holidayServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    public List<HolidayDto> getHolidaySummary() {
        List<HolidayEntity> hEntityList = holidayServiceDao.getHolidaySummary();
        log.info("Orika mapper result :", hEntityList);
        return orikaMapperFacade.mapAsList(hEntityList, HolidayDto.class);
    }
}
