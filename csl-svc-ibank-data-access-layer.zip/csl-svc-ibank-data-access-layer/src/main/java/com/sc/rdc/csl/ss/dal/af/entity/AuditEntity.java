package com.sc.rdc.csl.ss.dal.af.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import lombok.Data;

@Data
public class AuditEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String sessionId;
	private String txnId;
	private long id;
	private String useCase;
	private String logEvent;

	private String backendTxnId;
	private Timestamp logTimestamp;
	private String logException;
	private String activityStatus;
	private String activityDesc;

	private String customerId;
	private String ebid;
	private String pinchangeStaus;
	private String errorCode;
	private String cardNumber;
	private String cardType;
	private String customerType;

	private String cardEmbossedName;
	private String reasonForFailure;
	private String channel;
	private String cardActivationStatus;
	private String txnType;
	private String countryCode;
	
	
}
