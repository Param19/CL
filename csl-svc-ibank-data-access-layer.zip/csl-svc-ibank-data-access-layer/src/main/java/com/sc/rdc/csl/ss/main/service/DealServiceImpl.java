package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.DealInfo;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by 1347884 on 11/29/2017.
 */
@Slf4j
@Service
@Validated
public class DealServiceImpl {

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    @Autowired
    private DealServiceFactory dealServiceFactory;

    public List<DealInfo> getDealInfo(QuerySpec querySpec) {
        log.info("getDealInfo Operation : querySpec : " + querySpec);
        DealInfo dealInfo = populateQuerySpec(querySpec);
        log.info("getDealInfo dealInfo toString: " + dealInfo.toString());
        log.info("getDealInfo dealInfo : " + dealInfo);
        List<DealInfo> dealInfoList = null;
        dealInfoList = dealServiceFactory.getDealService(dealInfo.getCountry()).getDealInfo();
        log.info("getDealInfo dealInfoList : " + dealInfoList);

        return dealInfoList;
    }

    public DealInfo populateQuerySpec(QuerySpec querySpec) {
        List<FilterSpec> filterSpecs = querySpec.getFilters();
        Map<Object, Object> filterMap = filterSpecs.stream()
                .collect(Collectors.toMap(x -> x.getAttributePath().get(0), FilterSpec::getValue));
        return CSLJsonUtils.convertValue(filterMap, DealInfo.class);
    }
}
