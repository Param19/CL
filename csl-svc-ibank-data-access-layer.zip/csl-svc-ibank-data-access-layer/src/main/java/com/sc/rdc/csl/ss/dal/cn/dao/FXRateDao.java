package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.dal.cn.entity.FXRateEntity;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_PAYMENT_EXCEPTION;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Repository(value = "fxRateDao")
public class FXRateDao extends BaseDao {

    public List<FXRateEntity> getAllFXRate(String rateType) {
        List<FXRateEntity> fxRateEntities = null;
        try {
            Query query = entityManagerCn.createQuery("SELECT o FROM FXRateEntity o WHERE o.rateType = :rateType");
            query.setParameter("rateType", rateType);
            fxRateEntities = query.getResultList();
            return fxRateEntities;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }
}
