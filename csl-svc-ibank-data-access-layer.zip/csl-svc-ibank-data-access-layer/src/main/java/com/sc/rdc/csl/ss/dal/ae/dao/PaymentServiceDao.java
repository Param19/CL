package com.sc.rdc.csl.ss.dal.ae.dao;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.dal.ae.entity.payment.InternationalTransferEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_PAYMENT_EXCEPTION;

@Repository(value = "paymentServiceDaoAe")
@Slf4j
public class PaymentServiceDao extends BaseDao {

    public InternationalTransferEntity insertPayment(InternationalTransferEntity paymentEntity) {
        log.debug("PaymentServiceDao:insertPayment,{}", paymentEntity);
        try {
            paymentEntity = entityManagerAe.merge(paymentEntity);
            return paymentEntity;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

}
