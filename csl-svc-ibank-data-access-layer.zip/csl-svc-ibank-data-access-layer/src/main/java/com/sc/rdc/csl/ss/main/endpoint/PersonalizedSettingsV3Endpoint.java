package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.bank.BankDetailsDto;
import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsV3Summary;
import com.sc.rdc.csl.ss.common.service.PersonalizedSettingV3Service;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class PersonalizedSettingsV3Endpoint extends ResourceRepositoryBase<PersonalizedSettingsV3Summary, String> {

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

   @Autowired
    @Qualifier("personalizedSettingV3ServiceImpl")
    private PersonalizedSettingV3Service personalizedSettingV3Service;

    @Override
    public PersonalizedSettingsV3Summary findOne(String id, QuerySpec querySpec) {
        PersonalizedSettingsV3Summary personalizedSettingsV3Summary = new PersonalizedSettingsV3Summary() ;
        personalizedSettingsV3Summary.setUaas2id(cslRequestContext.getUaas2id());
        personalizedSettingsV3Summary.setCountryCode(cslRequestContext.getCountry());
        personalizedSettingsV3Summary.setLanguage(cslRequestContext.getLanguage());
        personalizedSettingsV3Summary = personalizedSettingV3Service.getPersonalizedAccountSummary(personalizedSettingsV3Summary);
        return personalizedSettingsV3Summary;
    }

    public PersonalizedSettingsV3Endpoint() {
        super(PersonalizedSettingsV3Summary.class);
    }


    @Override
    public ResourceList<PersonalizedSettingsV3Summary> findAll(QuerySpec querySpec) {
        BankDetailsDto bankDto = null;

     return null;

    }
}
