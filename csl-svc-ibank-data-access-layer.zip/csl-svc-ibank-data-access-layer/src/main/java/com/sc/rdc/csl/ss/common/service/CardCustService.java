package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.card.CardCustDto;

import java.util.List;


public abstract class CardCustService {

    public CardCustDto getCardCust(CardCustDto cardCustDto) {
        return null;
    }

    public List<CardCustDto> getCardList(CardCustDto cardCustDto) {
        return null;
    }
}
