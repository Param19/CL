package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.loan.LoanDto;
import com.sc.rdc.csl.ss.main.service.LoanServiceImpl;

import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class LoanEndpoint extends ResourceRepositoryBase<LoanDto, String> {

    @Autowired
    private LoanServiceImpl loanService;

    @Autowired
    private CSLRequestContext cslRequestContext;

    public LoanEndpoint(){
        super(LoanDto.class);
    }
    @Override
    public ResourceList<LoanDto> findAll(QuerySpec querySpec) {
        List<LoanDto> loanDetails = null;
        loanDetails = loanService.getLoanSummary();
        return querySpec.apply(loanDetails);
    }
    public LoanDto findOne(String id, QuerySpec querySpec) {
        LoanDto oneLoanDetails = null;
        try {
            log.debug("[Loan Service findOne Entry]");
            oneLoanDetails = loanService.getOneLoanDetails(id, querySpec);
        }
        catch(BusinessException ex){
            log.error("Exception occured while calling Loan Service." + ex.getMessage());
        }
        finally {
            log.debug("[Loan Service findOne Exit]");
        }
        return oneLoanDetails;
    }
}
