package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.card.CardDto;
import com.sc.rdc.csl.ss.common.dto.card.CreditCardTransactionDto;

import java.util.List;

public abstract class ICreditCardService {

    public List<CardDto> getCreditCardSummary(SsCSLUser user) {
        return null;
    }
    public CardDto getCreditCardDetails(String cardNo, SsCSLUser user , boolean includeTransactions){ return null; }
    public List<CreditCardTransactionDto> getTransactionHistory(String cardNo){return null;}
    public List<CardDto> getProvidedCreditCardSummary(List<String> cardNumbers){return null;}
}
