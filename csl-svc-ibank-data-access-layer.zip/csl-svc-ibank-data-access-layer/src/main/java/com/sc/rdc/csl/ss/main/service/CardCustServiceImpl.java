package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.dto.card.CardCustDto;
import com.sc.rdc.csl.ss.common.service.CardCustService;
import com.sc.rdc.csl.ss.main.helper.ErrorCodeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("cardCustServiceImpl")
@Slf4j
public class CardCustServiceImpl extends CardCustService {

  
    @Autowired
    private ErrorCodeUtil errorCodeUtil;

    @Autowired
    private CardCustServiceFactory cardCustServiceFactory;

    @Override
    public CardCustDto getCardCust(CardCustDto cardCustDto) {

        CardCustDto customerIdDto_data = cardCustServiceFactory.getCardCust(cardCustDto.getCountryCode()).getCardCust(cardCustDto);
        return customerIdDto_data;
    }

    @Override
    public List<CardCustDto> getCardList(CardCustDto cardCustDto) {
       return cardCustServiceFactory.getCardCust(cardCustDto.getCountryCode()).getCardList(cardCustDto);
    }
}
