package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.limit.TransactionLimit;

import java.util.ArrayList;
import java.util.List;

public abstract class TransactionLimitBaseService {

    /**
     * Default implementation
     * @param ebid
     * @return
     */
    public List<TransactionLimit> getTransactionLimits(String ebid) {
        return new ArrayList<>();
    }
}
