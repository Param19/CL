package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.holiday.HolidayDto;
import com.sc.rdc.csl.ss.main.service.HolidayServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class HolidayEndpoint extends ResourceRepositoryBase<HolidayDto, String> {

    @Autowired
    @Qualifier("holidayServiceImpl")
    private HolidayServiceImpl holidayService;

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    public HolidayEndpoint(){
        super(HolidayDto.class);
    }
    @Override
    public ResourceList<HolidayDto> findAll(QuerySpec querySpec) {
        List<HolidayDto> holidayDetails = null;
        holidayDetails = holidayService.getHolidaySummary();
        return querySpec.apply(holidayDetails);
    }
}
