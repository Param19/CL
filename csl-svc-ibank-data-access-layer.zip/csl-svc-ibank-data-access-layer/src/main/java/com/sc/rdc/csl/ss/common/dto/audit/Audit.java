package com.sc.rdc.csl.ss.common.dto.audit;

import java.io.Serializable;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonApiResource(type = "audit")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Audit extends SsBaseDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@JsonApiId
	private String id = UUID.randomUUID().toString();
	private String action;
	private String auditInfo;
	private String cardNumber;
	private String cardType;
	private String transactionId;
	private String functionCd;
	private String actionType;
	private String className;
	private String secRelId;
	private String purgeFlag;
	private String trnsactionFlag;
	private String programId;
	private String hashFlag;
	private String statusCd;
	
	/*private String sessionId;
	private String logEvent;
	private String backTxnId;
	private String embossedName;
	private String errorCd;*/
	
	
}
