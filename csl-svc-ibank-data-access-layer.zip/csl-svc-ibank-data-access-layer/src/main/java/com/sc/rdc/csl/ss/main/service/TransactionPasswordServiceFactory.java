package com.sc.rdc.csl.ss.main.service;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.service.ITransactionPasswordService;
import com.webmethods.jms.log.Log;

@Component
@Slf4j
public class TransactionPasswordServiceFactory {
    private static final String serviceName = "transactionPasswordService";
    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private Environment environment;

    @Autowired
    private CSLRequestContext cslRequestContext;
    public ITransactionPasswordService getTransactionPasswordService() {
        Log.info("Getting Holiday instance from Application context for Country : {}", cslRequestContext.getCountry());
        String countryGroup = environment.getProperty("database.country.group.".concat(cslRequestContext.getCountry().toUpperCase()));
        String countryServiceName = serviceName.concat(countryGroup != null ? countryGroup : cslRequestContext.getCountry().toUpperCase());
        return applicationContext.getBean(countryServiceName, ITransactionPasswordService.class);
    }
}
