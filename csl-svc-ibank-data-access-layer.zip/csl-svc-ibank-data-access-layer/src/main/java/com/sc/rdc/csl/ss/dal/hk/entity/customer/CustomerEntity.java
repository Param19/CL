package com.sc.rdc.csl.ss.dal.hk.entity.customer;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * @author 1448092
 * @since 2017
 */
@Data
public class CustomerEntity implements Serializable {
  
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;		// CUST_SERV_SEQ_NO
    private String userId;
    private String userPassword;
    private String customerEBID;
    private String customerPBID;
    private String customerIdType;
    private String customerId;
    private String customerName1;
    private String customerName2;
    
    private String customerStatusCode;	// IBANK customer status code
    private String language;
    private Date lastLoginDate;
    private Date firstLoginDate;
    private String isLoggedIn;
    private Boolean isActivated;
    private Integer loginCounter;
    
    private String accessKey; 		// CUST_ACCESS_KEY
    private String twoFAType;
    private Integer alpCounter;
    private String notificationType;
    private String mobileNumber;
    private Boolean isLocked;
    private String emailAddress;
    private String nickName;
    private String systemType;		// IBNK or ORR
    
    private String brandIndicator;	// CUST_SCB_IND
    private String armCode;			// CUST_ARM
    private String relTyp;			// REL_TYP
    private String packageStatus;
    
    private Integer loginSuccessCount;
    
    private Long customerSequenceNo;	// CUST_SEQ_NO
    
    private String txnPasswordStatus;  
    private String migrationStatus;
    private boolean e2eMigrationStatus;
    
    
}
