package com.sc.rdc.csl.ss.common.dto.wld;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;



@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

@JsonApiResource(type = "mailbox")
public class MailServiceEntityDto extends SsBaseDto {

    @JsonApiId
    private String id;

    @JsonProperty("messageSenderId")
    private String messageSenderId;

    @JsonProperty("messageCategory")
    private String messageCategory;

    @JsonProperty("messageSubject")
    private String messageSubject;

    @JsonProperty("messageBody")
    private String messageBody;

    @JsonProperty("reference")
    private String reference;



    @JsonProperty("statusDescription")
    private String statusdescription;

    @JsonProperty("statusCode")
    private Integer statusCode;

}
