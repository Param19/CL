package com.sc.rdc.csl.ss.dal.hk.entity.holiday;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author 1571806
 */
@Data
public class HolidayEntity implements Serializable {

	private static final long serialVersionUID = 1L;
	private Date date;
	private String description;
	private Integer year;
	private Integer month;
	private Integer day;
}
