package com.sc.rdc.csl.ss.common.dto.account;
import com.fasterxml.jackson.annotation.JsonInclude;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.Data;

@Data
@XmlType(name = "wealthInfo")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class WealthInfo {
    private String wealthIndicatorValue;
    private String wealthODAccountnumber;
}
