package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.unittrust.UnitTrustDto;

import java.util.Collections;
import java.util.List;

public abstract class IUnitTrustService {
    public List<UnitTrustDto> findAllUnitTrusts() {
        return Collections.<UnitTrustDto>emptyList();
    }
}
