package com.sc.rdc.csl.ss.common.dto;

import java.io.Serializable;
import java.util.Date;

public class BaseDto implements Serializable, Cloneable {

    private static final long serialVersionUID = -1858511132982371318L;
    private Date updatedDate;
    private String updatedBy;
    private Date createdDate;
    private String createdBy;
    private String countryCode;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }
}