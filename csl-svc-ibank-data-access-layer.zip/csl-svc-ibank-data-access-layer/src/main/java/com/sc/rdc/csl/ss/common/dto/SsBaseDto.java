package com.sc.rdc.csl.ss.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class SsBaseDto  {
    @JsonIgnore
    protected Integer statusCode;
    protected String code;
    @JsonIgnore
    private String countryCode = null;
    @JsonIgnore
    private String language = null;
    @JsonIgnore
    private String uaas2id = null;
}
