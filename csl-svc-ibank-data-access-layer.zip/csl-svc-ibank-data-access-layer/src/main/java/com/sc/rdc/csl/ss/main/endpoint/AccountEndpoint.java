package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.AccountDto;
import com.sc.rdc.csl.ss.main.helper.CommonEnricher;
import com.sc.rdc.csl.ss.main.service.AccountServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class AccountEndpoint extends ResourceRepositoryBase<AccountDto, String> {

    @Autowired
    private AccountServiceImpl accountService;

    @Autowired
    private CSLRequestContext cslRequestContext;

    public AccountEndpoint(){
        super(AccountDto.class);
    }

    @Override
    public ResourceList<AccountDto> findAll(QuerySpec querySpec) {
    	Map<String, Object> filterMap = CommonEnricher.populateQuerySpec(querySpec);
    	String filterValue = (String)filterMap.get("accountDesFilter");
        log.info("Filter value: {}", filterValue);
    	if(StringUtils.isNotEmpty(filterValue) && "true".equalsIgnoreCase(filterValue)){
    		return querySpec.apply(accountService.getAccountDescription());
    	} else {
    		return querySpec.apply(accountService.getAccountSummary());
    	}
    }

    @Override
    public ResourceList<AccountDto> findAll(Iterable<String> ids, QuerySpec querySpec) {
        List<String> accountNoList = new ArrayList<>();
        ids.forEach(id -> accountNoList.add(id));
        return querySpec.apply(accountService.findAllAccount(accountNoList,querySpec));
    }

    @Override
    public AccountDto findOne(String accountNo, QuerySpec querySpec) {
        return  accountService.findAccount(accountNo, querySpec);
    }
}
