package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.ProductDescriptionDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ProductDescriptionService;
import com.webmethods.jms.log.Log;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ProductDescriptionEndpoint extends ResourceRepositoryBase<ProductDescriptionDto, String>
{

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    @Qualifier("productDescriptionServiceImpl")
    private ProductDescriptionService productDescriptionService;



    public ProductDescriptionEndpoint() {
        super(ProductDescriptionDto.class);
    }

    @Override
    public ProductDescriptionDto findOne(String id, QuerySpec querySpec) {

        try {
            ProductDescriptionDto productDescriptionDto = new ProductDescriptionDto();
            productDescriptionDto.setCountryCode(cslRequestContext.getCountry());
            productDescriptionDto.setLanguage(cslRequestContext.getLanguage());
            log.info("Country :"+cslRequestContext.getCountry());
            Log.info("Language :"+cslRequestContext.getLanguage());
            productDescriptionDto = productDescriptionService.getproductDescription(productDescriptionDto);
            return productDescriptionDto;
        } finally {
            log.debug("[ProductDescriptionDto findOne Exit]");
        }
    }

    @Override
    public ResourceList<ProductDescriptionDto> findAll(QuerySpec querySpec) {
        try {
            log.debug("[ProductDescriptionDto findAll Entry]");
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        } finally {
            log.debug("[ProductDescriptionDto findAll Exit]");
        }
    }

}
