package com.sc.rdc.csl.ss.dal.in.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.in.entity.LoanEntity;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

@Repository(value ="loanServiceDaoIn")
@Slf4j
public class LoanServiceDao extends BaseDao {

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<LoanEntity> getLoanSummary() {
        log.info("LoanServiceDao:getLoanSummary,{}", requestContext.getRelId());
        Query query = entityManagerIn.createQuery("select a from com.sc.rdc.csl.ss.dal.in.entity.LoanEntity a WHERE a.customerNumber = :customerNumber")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("customerNumber", requestContext.getRelId());
        List<LoanEntity> loanEntityList = query.getResultList();
        log.info("Received {} LoanSummary record(s) from DB for User Id {}",
                (loanEntityList != null ? loanEntityList.size() : 0), requestContext.getRelId());
        if(!(loanEntityList != null && !loanEntityList.isEmpty()))
            throw new BusinessException(ErrorConstant.LOAN_ACCOUNT_NOT_FOUND_FOR_RELID);
        return loanEntityList;
    }

    public LoanEntity getOneLoanDetail(String accountId) {
        log.info("LoanServiceDao:getOneLoandetail");
        Query query = entityManagerIn.createQuery("select a from com.sc.rdc.csl.ss.dal.in.entity.LoanEntity a WHERE a.customerNumber = :customerNumber and a.accountNumber = :accountNumber").setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);;
        query.setParameter("customerNumber", requestContext.getRelId());
        query.setParameter("accountNumber", accountId);
        LoanEntity loanEntity = (LoanEntity)query.getSingleResult();
        log.info("Received LoanDetails from DB for Loan Account Id ", accountId);
        if (loanEntity == null) {
            throw new BusinessException(ErrorConstant.LOAN_ACCOUNT_NOT_FOUND);
        }
        return loanEntity;
    }
}
