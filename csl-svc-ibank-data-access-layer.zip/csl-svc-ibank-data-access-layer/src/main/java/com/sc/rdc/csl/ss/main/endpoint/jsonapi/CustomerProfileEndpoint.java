package com.sc.rdc.csl.ss.main.endpoint.jsonapi;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerProfile;
import com.sc.rdc.csl.ss.main.service.CustomerServiceImpl;
import io.katharsis.errorhandling.exception.ResourceNotFoundException;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CustomerProfileEndpoint extends ResourceRepositoryBase<CustomerProfile,String> {

    public CustomerProfileEndpoint() {
        super(CustomerProfile.class);
    }

    @Autowired
    private CustomerServiceImpl customerService;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Override
    public ResourceList<CustomerProfile> findAll(QuerySpec querySpec) {
        log.info("getAccountSummary {}",cslRequestContext);
        ResourceList resourceList = new DefaultResourceList();
        resourceList.add(getCustomerProfile());
        return querySpec.apply(resourceList);
    }

    @Override
    public CustomerProfile findOne(String id, QuerySpec querySpec) {
        ResourceList<CustomerProfile> result = new DefaultResourceList<>();
        result.add((CustomerProfile)getCustomerProfile());
    	return querySpec.apply(result).stream().findFirst()
                .orElseThrow(() -> new TechnicalException(new ResourceNotFoundException(id)));
    }

    public SsBaseDto getCustomerProfile() {
        SsCSLUser user = new SsCSLUser(cslRequestContext);
        SsBaseDto customer = customerService.getCustomerProfile(user);
        return customer;
    }

}
