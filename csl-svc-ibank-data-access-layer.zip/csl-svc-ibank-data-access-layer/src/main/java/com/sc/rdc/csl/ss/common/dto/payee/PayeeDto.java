package com.sc.rdc.csl.ss.common.dto.payee;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

import java.util.Date;


@Data
@JsonApiResource(type = "payee")
public class PayeeDto extends SsBaseDto {

    @JsonApiId
    private String id;
    @JsonProperty("payee-id")
    private String payeeId;
    @JsonProperty("payee-name")
    private String payeeName;
    @JsonProperty("nick-name")
    private String nickName;
    @JsonProperty("payee-type")
    private String payeeType;
    @JsonProperty("acct-number")
    private String acctNumber;
    @JsonProperty("acct-type-code")
    private String acctTypeCode;
    @JsonProperty("acct-currency")
    private String acctCurrency;
    @JsonProperty("acct-country")
    private String acctCountry;
    @JsonProperty("institution-name")
    private String institutionName;
    @JsonProperty("address1")
    private String address1;
    @JsonProperty("address2")
    private String address2;
    @JsonProperty("address3")
    private String address3;
    @JsonProperty("city")
    private String city;
    @JsonProperty("postcode")
    private String postcode;
    @JsonProperty("payee-country")
    private String payeeCountry;
    @JsonProperty("email")
    private String email;
    @JsonProperty("ebid")
    private String ebid;
    @JsonProperty("dt-created")
    private Date dtCreated;
    @JsonProperty("created-by")
    private String createdBy;
    @JsonProperty("dt-upd")
    private Date dtUpd;
    @JsonProperty("upd-by")
    private String updBy;
    @JsonProperty("version")
    private long version;
    @JsonProperty("ctry-cd")
    private String ctryCd;
    @JsonProperty("is-payee-update")
    private String isPayeeUpdate;
    @JsonProperty("ref-no")
    private String refNo;
    @JsonProperty("old-payee-id")
    private String oldPayeeId;
}
