package com.sc.rdc.csl.ss.main.helper;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import javax.ws.rs.ext.ParamConverter;
import javax.ws.rs.ext.ParamConverterProvider;
import javax.ws.rs.ext.Provider;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
@Provider
public class UserParameterConverter implements ParamConverterProvider {

    private static final String USER_OBJECT = "com.sc.rdc.csl.ss.common.dto.SsCSLUser";
    
    @Override
    public <T> ParamConverter<T> getConverter(final Class<T> rawType, final Type genericType, final Annotation[] annotations) {
        
        if( !StringUtils.equals(rawType.getName(), USER_OBJECT)){
            return null;
        }
        return new ParamConverter<T>() {
            @Override
            public T fromString(final String value) {
                return CSLJsonUtils.parseJson(value, rawType);
            }
            @Override
            public String toString(final T value) {
                return CSLJsonUtils.toJson(value, rawType);
            }
        };
    }

}
