package com.sc.rdc.csl.ss.dal.sg.dao;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.dal.sg.entity.CustomerStatusEntity;
import com.sc.rdc.csl.ss.dal.sg.entity.ProfileEntity;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.util.Date;


@Repository(value ="customerServiceDaoSg")
@Slf4j
public class CustomerServiceDao extends BaseDao {

    public ProfileEntity getCustomerProfile(SsCSLUser user) {
        log.info("CustomerServiceDao:getCustomerProfile,{}", user);
        TypedQuery<ProfileEntity> query = null;
        ProfileEntity profile = null;
        if(StringUtils.isNotBlank(user.getUaas2id())){
        	query = entityManagerSg.createQuery("select a from ProfileEntity a WHERE a.customerEBID = :customerEBID and a.statusCode =:statusCode and a.lastLogin is not null order by a.lastLogin desc",ProfileEntity.class);
	        query.setParameter("customerEBID", user.getUaas2id());
	        query.setParameter("statusCode", "A");
	        query.setFirstResult(0);
	        query.setMaxResults(1);
	        profile = query.getSingleResult();
        }else if(StringUtils.isNotBlank(user.getCustomerId())){
	        query = entityManagerSg.createQuery("select a from ProfileEntity a WHERE a.customerId = :customerId and a.statusCode =:statusCode and a.lastLogin is not null order by a.lastLogin desc",ProfileEntity.class);
	        query.setParameter("customerId", user.getCustomerId());
	        query.setParameter("statusCode", "A");
	        query.setFirstResult(0);
	        query.setMaxResults(1);
	        profile = query.getSingleResult();
        }
        log.info("Received getCustomerProfile from DB:" + profile);
        return profile;
    }

    public CustomerStatusEntity getCustomerStatus(Long customerSeqNo) {
        TypedQuery<CustomerStatusEntity> query = entityManagerSg.createQuery("select c from com.sc.rdc.csl.ss.dal.sg.entity.CustomerStatusEntity c WHERE c.customerProfileId = :customerProfileId",CustomerStatusEntity.class);
        query.setParameter("customerProfileId", customerSeqNo);
        query.setMaxResults(1);
        CustomerStatusEntity profile = query.getSingleResult();
        return profile;
    }

    public void update(CustomerStatusEntity entity){
        entity.setUpdatedDate(new Date());
        entityManagerSg.merge(entity);
    }
}
