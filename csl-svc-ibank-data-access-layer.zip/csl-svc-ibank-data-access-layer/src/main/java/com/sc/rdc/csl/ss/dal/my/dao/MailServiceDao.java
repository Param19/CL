package com.sc.rdc.csl.ss.dal.my.dao;

import com.sc.rdc.csl.ss.dal.my.entity.MailServiceEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.math.BigInteger;

@Repository(value = "mailServiceDaoMY")
@Slf4j
public class MailServiceDao extends BaseDao {

    public void insertMailData(MailServiceEntity mailServiceEntityVO) {
        entityManagerMY.persist(mailServiceEntityVO);
        log.info("Successfully Inserted");
    }

    public Integer getNextSequence() {
        log.info("MailServiceDao:getNextSequence,{}");
        Query query = entityManagerMY.createNativeQuery("SELECT (NEXTVAL FOR CFE.MSG_MAILBOX) FROM SYSIBM.SYSDUMMY1");
        Integer nextInterval = ((BigInteger) query.getSingleResult()).intValue();
        log.info("NextSequence:" + nextInterval);
        return nextInterval;
    }

}
