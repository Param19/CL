package com.sc.rdc.csl.ss.dal.ae.entity;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class FtTxnLimitsEntity extends BaseDto {

    private Long id;
    private String customerSegment;
    private String limitTypeCode;
    private String txnTypeCode;
    private BigDecimal defLimit;
    private String statusCode;
    private String countryCode;
    private String limitTypeDesc;
    private String txnTypeDesc;


}
