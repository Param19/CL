package com.sc.rdc.csl.ss.dal.hk.dao;

import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerStatusEntity;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerEntity;

import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@Repository(value ="customerServiceDaoHK")
@Slf4j
public class CustomerServiceDao extends BaseDao{

    public CustomerEntity getCustomerProfile(SsCSLUser user) {
        log.info("CustomerServiceDao:getCustomerProfile,{}", user);
      CustomerEntity customerProfile = null;
      Query query = null;
       if(StringUtils.isNotBlank(user.getUaas2id())){
    	   query = entityManagerHk.createQuery("from com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerEntity cust where cust.customerEBID = :customerEBID and cust.customerStatusCode = :activeStatus AND lastLoginDate IS NOT NULL ORDER BY lastLoginDate DESC");
           query.setParameter("customerEBID", user.getUaas2id());
           query.setParameter("activeStatus", "A");
           customerProfile = (CustomerEntity) query.getSingleResult();
       }else{
	        query = entityManagerHk.createQuery("from com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerEntity cust where cust.customerId = :customerId and cust.customerIdType = :customerIdType and cust.customerStatusCode = :activeStatus AND lastLoginDate IS NOT NULL ORDER BY lastLoginDate DESC");
	        query.setParameter("customerId", user.getCustomerId());
	        query.setParameter("customerIdType", user.getCustomerTypeId());
	        query.setParameter("activeStatus", "A");
	        customerProfile = (CustomerEntity) query.getSingleResult();
       }
        log.debug("Received getCustomerProfile from DB:" + customerProfile);
        return customerProfile;
    }

    public CustomerStatusEntity getCustomerStatus(Long customerSeqNo) {
        TypedQuery<CustomerStatusEntity> query = entityManagerHk.createQuery("select c from com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerStatusEntity c WHERE c.customerProfileId = :customerProfileId",CustomerStatusEntity.class);
        query.setParameter("customerProfileId", customerSeqNo);
        query.setMaxResults(1);
        CustomerStatusEntity profile = query.getSingleResult();
        return profile;
    }

    public void update(CustomerStatusEntity entity){
        entity.setUpdatedDate(new Date());
        entityManagerHk.merge(entity);
    }
}

