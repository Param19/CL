package com.sc.rdc.csl.ss.dal.pk.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.pk.entity.customer.ReferenceEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION;

@Repository(value = "referenceDetailsDaoPk")
@Slf4j
public class ReferenceDao extends BaseDao {

    @Autowired
    private CSLRequestContext cslRequestContext;

    public static String GET_REFERENCE_DETAIL = "select  o from com.sc.rdc.csl.ss.dal.pk.entity.customer.ReferenceEntity o WHERE o.type = :type and o.referenceCode= :segmentCode and o.countryCode= :country";

    public ReferenceEntity getReferenceDetails(String type, String segmentCode) {

        log.info("Type: {} : Segment code: {}", type, segmentCode);
        Query query = entityManagerPk.createQuery(GET_REFERENCE_DETAIL);
        query.setParameter("type", type);
        query.setParameter("segmentCode",segmentCode);
        query.setParameter("country",cslRequestContext.getCountry());
        ReferenceEntity referenceEntity = (ReferenceEntity)query.getSingleResult();
        log.info("ReferenceEntity Record: {}", referenceEntity);
       if(referenceEntity!=null) {
           return referenceEntity;
       } else {
            throw new BusinessException(CUSTOMER_NO_RECORD_EXCEPTION);
        }
    }


}
