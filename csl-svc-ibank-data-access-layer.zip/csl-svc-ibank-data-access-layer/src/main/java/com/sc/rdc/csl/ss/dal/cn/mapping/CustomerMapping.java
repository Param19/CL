/**
 * CASAMapping.java / Jun 16, 2017 / CSL-SVC-CASAS-1.0.0
 */
package com.sc.rdc.csl.ss.dal.cn.mapping;

import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.dal.cn.entity.ProfileEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class CustomerMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        orikaMapperFactory
                .classMap(Profile.class, ProfileEntity.class)
                .mapNulls(false)
                .byDefault()
                .register();

    }

}

