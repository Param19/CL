package com.sc.rdc.csl.ss.common.service;


import com.sc.rdc.csl.ss.common.dto.account.ProductDescriptionDto;

public abstract class ProductDescriptionService {

    public ProductDescriptionDto getproductDescription(ProductDescriptionDto productDescriptionDto) {
        return null;
    }

}
