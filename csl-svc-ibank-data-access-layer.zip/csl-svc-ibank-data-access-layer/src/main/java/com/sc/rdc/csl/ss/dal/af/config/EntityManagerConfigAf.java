package com.sc.rdc.csl.ss.dal.af.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.sc.rdc.csl.ss.common.helper.Constants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
public class EntityManagerConfigAf {

    @Qualifier("entityManagerFactoryAf")
    @Bean("entityManagerFactoryAf")
    public LocalContainerEntityManagerFactoryBean entityManagerFactoryAf(@Qualifier("db2DataSourceAf") DataSource db2DataSourceAf) {
        LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactory.setDataSource(db2DataSourceAf);
        entityManagerFactory.setPersistenceXmlLocation("classpath*:com/sc/rdc/csl/ss/resource/af/persistence/persistence-af.xml");
        entityManagerFactory.setPersistenceUnitName(Constants.PERSISTENCE_UNIT_AF);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(false);
        vendorAdapter.setDatabase(Database.DB2);
        entityManagerFactory.setJpaVendorAdapter(vendorAdapter);
        return entityManagerFactory;
    }

    @Qualifier("transactionManagerAf")
    @Bean("transactionManagerAf")
    public JpaTransactionManager transactionManagerAf(@Qualifier("entityManagerFactoryAf") LocalContainerEntityManagerFactoryBean entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory.getObject());
        return transactionManager;
    }

    @Qualifier("exceptionTranslationAf")
    @Bean("exceptionTranslationAf")
    public PersistenceExceptionTranslationPostProcessor exceptionTranslationAf() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    @Qualifier("db2DataSourceAf")
    @ConfigurationProperties(prefix = "af.db2.datasource")
    @Bean("db2DataSourceAf")
    public DataSource db2DataSourceAf() {
        return new ComboPooledDataSource();
    }
}
