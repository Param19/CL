package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.customer.AccountPersonalized;
import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsSummary;
import java.util.List;

public abstract class IPersinalizedSettingsService {
    
    public List<AccountPersonalized> getPersonalizedAccountSummary(SsCSLUser user) {
         return  null;
    }

    public PersonalizedSettingsSummary getPersonalizedSummary (SsCSLUser user) {
        return  null;
    }
}
