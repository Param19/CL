
package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.loan.LoanDto;

import io.katharsis.queryspec.QuerySpec;

import java.util.List;

public abstract class ILoanService {
    public List<LoanDto> getLoanSummary() {
        return null;
    }
    public LoanDto getOneLoanDetail(String accountId, QuerySpec querySpec) {
        return null;
    }

}
