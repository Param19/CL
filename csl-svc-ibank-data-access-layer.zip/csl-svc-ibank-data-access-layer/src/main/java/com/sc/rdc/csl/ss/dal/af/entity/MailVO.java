package com.sc.rdc.csl.ss.dal.af.entity;


import lombok.Data;

import java.util.Date;

@Data
public class MailVO extends BaseVO {

    private static final long serialVersionUID = -7392896651990406165L;

    private String countryCode;

    private String messageMasterId;

    private String messageFrom;

    private String messageFromAddressType;

    private String messageTo;

    private String messageToAddressType;

    private String messageCategory;

    private String messageSubject;

    private String messageBody;

    private String messageStatus;

    private Date messageStatusDate;

    private Boolean isDeletedByCustomer;

    private Boolean isRepliedByBO;

    private Date dateDeletedByBO;

    private String messageStatusByBO;

    private Date messageStatusDateByBO;

    private Boolean isDeletedByBO;

    private Date dateRepliedByBO;

    private String mailReferenceNumber;

    private String messageType;

    /*for handle the checkbox list*/
    private boolean isSelected;

}
