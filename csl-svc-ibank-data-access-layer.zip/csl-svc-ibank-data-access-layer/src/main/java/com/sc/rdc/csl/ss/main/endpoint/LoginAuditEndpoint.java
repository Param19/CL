package com.sc.rdc.csl.ss.main.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.rdc.csl.ss.common.dto.audit.LoginAudit;
import com.sc.rdc.csl.ss.common.helper.AuditConstant;
import com.sc.rdc.csl.ss.main.service.LoginAuditServiceImpl;

import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
@Component
@Slf4j
public class LoginAuditEndpoint extends ResourceRepositoryBase<LoginAudit, String> {

	   protected LoginAuditEndpoint() {
		super(LoginAudit.class);
		
	}

	   @Autowired
	    private LoginAuditServiceImpl loginAuditService;

		@Override
		public ResourceList<LoginAudit> findAll(QuerySpec arg0) {
			// Not implemented
			return null;
		}
		
		@Override
		public LoginAudit save(LoginAudit resource) {
			 try{
					loginAuditService.insertLoginAuditData(resource);
				}
				catch(Exception e){
					log.error("Exception while doing login audit data insert " + e.getMessage());
					resource.setStatus(AuditConstant.S_FAILURE);
				}
				
				return resource;
		}

}
