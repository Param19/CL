
package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.account.AccountDto;
import io.katharsis.queryspec.QuerySpec;

import java.util.List;


public abstract class IAccountService {
    public List<AccountDto> getAccountSummary() {
        return null;
    }
    
    public List<AccountDto> getAccountDescription() {
        return null;
    }

    public AccountDto findAccount(String accountNo, QuerySpec querySpec) { return null; }

    public List<AccountDto> findAllAccount(List<String> accountNo, QuerySpec querySpec) { return null; }
}
