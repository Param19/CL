package com.sc.rdc.csl.ss.common.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.BaseDto;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountPersonalized extends BaseDto {
	private static final long serialVersionUID = 1L;

	private Long id;
	private String accountNickName;
	private String productDescription;
	private String isNameDisplayable;
	private String isNameReadOnly;
	private String accountNumber;
	private String isNumberDisplayable;
	private String isNumberReadOnly;
	private String isRemoved;
	private Integer orderNumber;
	private Boolean isVisible;
	private String prdCode;
	private String subPrdCode;
	private String currencyCode;
	private String accountCurrencyCode;
	private Boolean isAccountVisible;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getAccountNickName() {
		return accountNickName;
	}
	public void setAccountNickName(String accountNickName) {
		this.accountNickName = accountNickName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getIsNameDisplayable() {
		return isNameDisplayable;
	}
	public void setIsNameDisplayable(String isNameDisplayable) {
		this.isNameDisplayable = isNameDisplayable;
	}
	public String getIsNameReadOnly() {
		return isNameReadOnly;
	}
	public void setIsNameReadOnly(String isNameReadOnly) {
		this.isNameReadOnly = isNameReadOnly;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getIsNumberDisplayable() {
		return isNumberDisplayable;
	}
	public void setIsNumberDisplayable(String isNumberDisplayable) {
		this.isNumberDisplayable = isNumberDisplayable;
	}
	public String getIsNumberReadOnly() {
		return isNumberReadOnly;
	}
	public void setIsNumberReadOnly(String isNumberReadOnly) {
		this.isNumberReadOnly = isNumberReadOnly;
	}
	public String getIsRemoved() {
		return isRemoved;
	}
	public void setIsRemoved(String isRemoved) {
		this.isRemoved = isRemoved;
	}
	public Integer getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(Integer orderNumber) {
		this.orderNumber = orderNumber;
	}
	public Boolean getIsVisible() {
		return isVisible;
	}
	public void setIsVisible(Boolean isVisible) {
		this.isVisible = isVisible;
	}
	public String getPrdCode() {
		return prdCode;
	}
	public void setPrdCode(String prdCode) {
		this.prdCode = prdCode;
	}
	public String getSubPrdCode() {
		return subPrdCode;
	}
	public void setSubPrdCode(String subPrdCode) {
		this.subPrdCode = subPrdCode;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getAccountCurrencyCode() {
		return accountCurrencyCode;
	}
	public void setAccountCurrencyCode(String accountCurrencyCode) {
		this.accountCurrencyCode = accountCurrencyCode;
	}
	public Boolean getIsAccountVisible() {
		return isAccountVisible;
	}
	public void setIsAccountVisible(Boolean isAccountVisible) {
		this.isAccountVisible = isAccountVisible;
	}
}