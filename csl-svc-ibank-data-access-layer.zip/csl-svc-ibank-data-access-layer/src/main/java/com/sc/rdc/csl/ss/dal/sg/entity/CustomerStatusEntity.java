package com.sc.rdc.csl.ss.dal.sg.entity;


import lombok.Data;

import java.util.Date;

@Data
public class CustomerStatusEntity {
    private static final long serialVersionUID = 1L;

    private Long id;
    private Long customerProfileId;
    // for 2FA
    private Integer alpCounter;
    private Boolean isLocked;
    private String lockedReason;
    private String twoFAType;
    private String isCardSelected;
    private String preferredLogin;
    private String notificationMode;
    private Date updatedDate;
    private String updatedBy;

}
