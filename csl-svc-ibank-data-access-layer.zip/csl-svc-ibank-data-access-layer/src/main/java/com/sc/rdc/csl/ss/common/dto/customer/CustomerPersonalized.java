package com.sc.rdc.csl.ss.common.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerPersonalized extends BaseDto {
	private static final long serialVersionUID = 1L;

	private String defaultLanguage;
	private String currentLanguage;
}