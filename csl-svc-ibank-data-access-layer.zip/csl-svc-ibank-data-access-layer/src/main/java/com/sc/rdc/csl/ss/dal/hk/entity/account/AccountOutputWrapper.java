package com.sc.rdc.csl.ss.dal.hk.entity.account;


import com.sc.rdc.csl.ss.common.dto.account.BndAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.CasaAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.WealthAccountDto;
import java.util.List;
import lombok.Data;

@Data
public class AccountOutputWrapper {
   private List<CasaAccountDto> casaAccountList;
   private List<BndAccountDto> bndAccountDtoList;
   private List<WealthAccountDto> wealthAccountList;

}
