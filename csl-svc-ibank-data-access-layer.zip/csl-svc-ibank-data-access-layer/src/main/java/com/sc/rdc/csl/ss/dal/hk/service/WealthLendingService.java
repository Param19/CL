package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingApplicationEntity;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.service.IWealthLendingService;
import com.sc.rdc.csl.ss.common.dto.wld.ApplicationDto;
import com.sc.rdc.csl.ss.common.dto.wld.ApplicationSummary;
import com.sc.rdc.csl.ss.dal.hk.config.DozerUtilsHk;
import com.sc.rdc.csl.ss.dal.hk.dao.WealthLendingServiceDao;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Slf4j
@Service(value = "wealthLendingServiceHk")
public class WealthLendingService extends IWealthLendingService{

    
    @Qualifier("dozerUtilsHk")
    @Autowired  
    private DozerUtilsHk dozerUtilsHk;
    
    @Qualifier("dozerBeanMapperHk")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;
            
    @Qualifier("wealthLendingServiceDaoHk")        
    @Autowired
    private WealthLendingServiceDao wealthLendingServiceDao;

    @Override
    public SsBaseDto findWldCustomerDetails(SsCSLUser user)  {
       return  dozerUtilsHk.convertCustomer(wealthLendingServiceDao.findWldCustomerDetails(user));
    }

    @Transactional("transactionManagerHk")
    @Override
    @LogTimeTaken
    public  SsBaseDto submitApplication(ApplicationDto applicationDto, SsCSLUser user){
        WealthLendingApplicationEntity entity = dozerBeanMapper.map(applicationDto, WealthLendingApplicationEntity.class);
        entity.setCustomerIdType(user.getRelId().substring(0, 2));
        entity.setCustomerId(user.getRelId().substring(2, user.getRelId().length()));
        entity = wealthLendingServiceDao.insertApplication(entity);
        wealthLendingServiceDao.updateWealthProCustStatus(entity);
        ApplicationDto dto = dozerBeanMapper.map(entity, ApplicationDto.class);
        return dto;
    }

    @Transactional("transactionManagerHk")
    @LogTimeTaken
    @Override
    public  SsBaseDto updateApplication(ApplicationDto applicationDto, SsCSLUser user){
        WealthLendingApplicationEntity entity = dozerBeanMapper.map(applicationDto, WealthLendingApplicationEntity.class);
        entity = wealthLendingServiceDao.updateApplication(entity);
        ApplicationDto resApplicationDto = dozerBeanMapper.map(entity, ApplicationDto.class);
        return resApplicationDto; 
    }
    
    @Override
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public  SsBaseDto getApplication(String id, SsCSLUser user){
        WealthLendingApplicationEntity entity = wealthLendingServiceDao.getApplication(id);
        ApplicationDto applicationDto = dozerBeanMapper.map(entity, ApplicationDto.class);
        return  applicationDto;
    }
    
    @Override
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public SsBaseDto getAllApplication(String appStatus,SsCSLUser user){
        List<WealthLendingApplicationEntity> entityList = wealthLendingServiceDao.getAllApplication(appStatus);
        ApplicationSummary applicationSummary = new ApplicationSummary();
        applicationSummary.setCode("0");
        applicationSummary.setApplicationDtoList(dozerUtilsHk.convertApplicationDto(entityList));
        return applicationSummary;
    }    

}
