package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.rdc.csl.ss.common.dto.account.Transaction;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ITransactionService;
import com.sc.rdc.csl.ss.dal.hk.dao.AccountTransactionDao;
import com.sc.rdc.csl.ss.dal.hk.dao.card.CreditCardTransactionDao;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountTransactionEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CardTxnHistoryEntity;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service("transactionServiceHk")
@Slf4j
public class TransactionService extends ITransactionService {

    @Autowired
    @Qualifier("accountTransactionDaoHk")
    AccountTransactionDao accountTransactionDao;

    @Autowired
    @Qualifier("creditCardTxnServiceDaoHk")
    CreditCardTransactionDao creditCardTransactionDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Override
    public List<Transaction> getTransactions(List<String> accountNos, QuerySpec querySpec) {

        List<String> casaAccounts = new ArrayList<>();
        List<String> creditCards = new ArrayList<>();
        List<Transaction> transactions = new ArrayList<>();
        accountNos.forEach(account -> {
            String accountNo = account.split("-")[1];
            if (account.toLowerCase().startsWith("casa-")) {
                casaAccounts.add(accountNo);
            } else if (account.toLowerCase().startsWith("cc-")){
                creditCards.add(accountNo);
            } else {
                throw new TechnicalException(ErrorConstant.INVALID_ACCOUNT_FORMAT);
            }
        });
        transactions.addAll(getCasaTransactions(casaAccounts,querySpec));
        transactions.addAll(getCreditCardTransactions(creditCards,querySpec));
        return transactions;
    }



    private List<Transaction> getCasaTransactions(List<String> accountNos,QuerySpec querySpec) {
        List<Transaction> transactions = new ArrayList<>();
        if(!accountNos.isEmpty()) {
            Map<String, String> transactionDetailMap = populateTransactionsMap(querySpec);
            log.info("Transactions Map :: {} ", transactionDetailMap);
            try {
                List<AccountTransactionEntity> accountTransactionEntities = accountTransactionDao.getTransactions(accountNos, transactionDetailMap.get(Constants.FROM_DATE), transactionDetailMap.get(Constants.TO_DATE));
                accountTransactionEntities.forEach(accountTransactionEntity -> {
                    transactions.add(orikaMapperFacade.map(accountTransactionEntity, Transaction.class));
                });
            } catch (ParseException e) {
                log.error("Error while getting Casa transactions :: {}  ", e.getMessage());
            }
            log.info("Casa Transactions List Size :: {} ",transactions.size());
        }
        return transactions;
    }
    private List<Transaction> getCreditCardTransactions(List<String> accountNos,QuerySpec querySpec) {
        List<Transaction> transactions = new ArrayList<>();
        if(!accountNos.isEmpty()) {
            Map<String, String> transactionDetailMap = populateTransactionsMap(querySpec);
            log.info("Transactions Map :: {} ", transactionDetailMap);
            try {
                List<CardTxnHistoryEntity> accountTransactionEntities = creditCardTransactionDao.getCardTransactionHistory(accountNos, transactionDetailMap.get(Constants.FROM_DATE), transactionDetailMap.get(Constants.TO_DATE));
                accountTransactionEntities.forEach(accountTransactionEntity -> {
                    transactions.add(orikaMapperFacade.map(accountTransactionEntity, Transaction.class));
                });
            } catch (ParseException e) {
                log.error("Error while getting Credit Card transactions :: {}  ", e.getMessage());
            }
            log.info("Credit Card Transactions List Size :: {} ",transactions.size());
        }
        return transactions;

    }

    private Map<String, String> populateTransactionsMap(QuerySpec querySpec) {
        Map<String,String> transactionDetailMap = new HashMap<>();
        List<FilterSpec> filterSpecs = querySpec.getFilters();
        filterSpecs.forEach(filterSpec -> {
            List<String> filter = filterSpec.getAttributePath();
            if(filter.contains(Constants.FROM_DATE)) {
                transactionDetailMap.put(Constants.FROM_DATE,String.valueOf(filterSpec.getValue()));
            } else if (filter.contains(Constants.TO_DATE)) {
                transactionDetailMap.put(Constants.TO_DATE,String.valueOf(filterSpec.getValue()));
            }
        });
        log.info("Transaction Map :: {} ",transactionDetailMap);
        if(transactionDetailMap.isEmpty() || transactionDetailMap.size() < 2) {
            throw new TechnicalException(ErrorConstant.INVALID_FILTER_PARAMS);
        }
        return transactionDetailMap;
    }



}
