package com.sc.rdc.csl.ss.dal.cn.entity;


import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Data
@Entity
@Table(name = "CUST_TXN_LIMIT", schema = "CFE")
public class LimitsEntity {

    @Id
    @Column(name = "TXN_SEQ_NO")
    private Long id;

    @Column(name = "EBID")
    private String ebid;

    @Column(name = "CUSTOMER_ID")
    private String customerId;

    @Column(name = "CUST_TYPE")
    private String customerIdType;

    @Column(name = "CATEGORY")
    private String category;

    @Column(name = "TXN_TYPE")
    private String transactionType;

    @Column(name = "BP_MERCHANT_TYPE")
    private String merchantType;

    @Column(name = "BP_MERCHANT_CODE")
    private String merchantCode;

    @Column(name = "FT_PAYEE_INDICATOR")
    private String payeeIndicator;

    @Column(name = "MAX_LIMIT")
    private BigDecimal maximumLimit;

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "AUTHORIZATION_STATUS")
    private String authStatus;

    @Column(name = "APPROVED_DATE")
    private Date approvedDate;

    @Column(name = "APPROVER_ID")
    private String approverId;

    @Column(name = "DT_UPD")
    private Date updatedDate;

    @Column(name = "UPD_BY")
    private String updatedBy;

    @Column(name = "DT_CREATED")
    private Date createdDate;

    @Column(name = "DEF_LIMIT")
    private BigDecimal defLimit;

    @Column(name = "SEGMENT")
    private String segment;

    @Column(name = "CREATED_BY")
    private String createdBy;
}
