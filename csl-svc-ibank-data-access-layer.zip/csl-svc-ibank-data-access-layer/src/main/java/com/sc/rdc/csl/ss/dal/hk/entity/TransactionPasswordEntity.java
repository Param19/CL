package com.sc.rdc.csl.ss.dal.hk.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class TransactionPasswordEntity implements Serializable {

	private String id;
	private String transactionPassword;
	private String ebid;
	private String aesPassword;
	private String pswdCounter;
	private Date dateLocked;
}
