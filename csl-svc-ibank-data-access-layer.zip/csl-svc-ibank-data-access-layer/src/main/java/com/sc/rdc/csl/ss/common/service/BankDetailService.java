package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.bank.BankDetailsDto;

import java.util.List;


public abstract class BankDetailService {

    public List<BankDetailsDto> getBankDetails(BankDetailsDto bankDetailsDto) {
        return null;
    }
}
