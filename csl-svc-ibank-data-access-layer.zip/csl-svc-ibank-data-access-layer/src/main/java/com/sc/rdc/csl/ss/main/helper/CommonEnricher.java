package com.sc.rdc.csl.ss.main.helper;

import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CommonEnricher {

    public static Map<String, Object> populateQuerySpec(QuerySpec querySpec) {
        List<FilterSpec> filterSpecs = querySpec.getFilters();
        Map<String, Object> filterMap = filterSpecs.stream().collect(
                Collectors.toMap(x -> x.getAttributePath().get(0), FilterSpec::getValue));
        return filterMap;
    }

	
}
