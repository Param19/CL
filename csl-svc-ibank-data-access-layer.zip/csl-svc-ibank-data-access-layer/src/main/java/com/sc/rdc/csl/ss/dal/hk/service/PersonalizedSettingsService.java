
package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.customer.AccountPersonalized;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerPersonalized;
import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsSummary;
import com.sc.rdc.csl.ss.common.service.IPersinalizedSettingsService;
import com.sc.rdc.csl.ss.dal.hk.dao.PersonalizedSettingsDao;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerPersonalizedSettingsEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.DeviceGroupEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.PersonalizedSettingsEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service(value="personalizedSettingsServiceHk")
@Slf4j
public class PersonalizedSettingsService extends IPersinalizedSettingsService{
    
    @Qualifier("dozerBeanMapperHk")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;
   
    @Qualifier("personalizedSettingsDaoHk")        
    @Autowired
    private PersonalizedSettingsDao personalizedSettingsDaoHk;

    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public PersonalizedSettingsSummary getPersonalizedSummary(SsCSLUser user)  {
        PersonalizedSettingsSummary personalizedSettingsSummary = new PersonalizedSettingsSummary();
        List<AccountPersonalized> accountPersonalizedList = getPersonalizedAccountSummary(user);
        CustomerPersonalized  customerPersonalized = getPersonalizedCustomerSummary(user);
        personalizedSettingsSummary.setAccountPersonalizedSummary(accountPersonalizedList);
        personalizedSettingsSummary.setCustomerPersonalizedSummary(customerPersonalized);
        return personalizedSettingsSummary;
    }
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public List<AccountPersonalized> getPersonalizedAccountSummary(SsCSLUser user)  {
        List<AccountPersonalized> accountPersonalizedList = new ArrayList<>();
        AccountPersonalized personalized = null;
        Set<DeviceGroupEntity> deviceGroupList = null;
        DeviceGroupEntity deviceGroupDto = null;
        List<PersonalizedSettingsEntity> personalizedList = personalizedSettingsDaoHk.getPersonalizedAccountSummary(user.getUaas2id());
        if (personalizedList != null) {
            for (PersonalizedSettingsEntity personalSettings : personalizedList) {
                personalized = new AccountPersonalized();
                dozerBeanMapper.map(personalSettings,personalized, "PersonalizedSettingsDto");
                deviceGroupList = personalSettings.getDeviceGroupList();
                if (CollectionUtils.isNotEmpty(deviceGroupList)) {
                    deviceGroupDto = (DeviceGroupEntity) deviceGroupList .iterator().next(); 
                    Boolean isVisible = deviceGroupDto.getIsVisible();
                    personalized.setIsVisible(isVisible);
                }
                accountPersonalizedList.add(personalized);
            }
        }
 
        return accountPersonalizedList;
    }

    private CustomerPersonalized getPersonalizedCustomerSummary(SsCSLUser user) {
        CustomerPersonalized customerPersonalized = new CustomerPersonalized();
        CustomerPersonalizedSettingsEntity customerPersonalizedSettingsEntity = personalizedSettingsDaoHk.getCustomerPersonalizedSummary(user.getUaas2id());
        if(customerPersonalizedSettingsEntity != null) {
            customerPersonalized = dozerBeanMapper.map(customerPersonalizedSettingsEntity, CustomerPersonalized.class);
        }
        return customerPersonalized;
    }
}
