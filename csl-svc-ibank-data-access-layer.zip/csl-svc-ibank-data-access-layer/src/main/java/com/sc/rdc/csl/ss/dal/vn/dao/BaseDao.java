
package com.sc.rdc.csl.ss.dal.vn.dao;

import com.sc.rdc.csl.ss.common.helper.Constants;
import org.springframework.context.annotation.Lazy;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author 1546088
 */
public class BaseDao {

    @Lazy
    @PersistenceContext(unitName = Constants.PERSISTENCE_UNIT_VN)
    protected EntityManager entityManagerVN;
}
