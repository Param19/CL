package com.sc.rdc.csl.ss.dal.in.entity.customer;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@Table(name = "TBL_AUD_C2C_IVR_INFO", schema = "SCBAUD")
public class IVRInfoEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID", nullable = false)
    private Long id;

    @Column(name = "MOBILE", nullable = false)
    private String mobile;

    @Column(name = "COUNTRY", nullable = false)
    private String country;

    @Column(name = "NAME", nullable = false)
    private String name;

    @Column(name = "SEGMENT", nullable = false)
    private String segment;

    @Column(name = "GENDER", nullable = false)
    private String gender;

    @Column(name = "ARMCODE", nullable = false)
    private String armcode;

    @Column(name = "LANG", nullable = false)
    private String lang;

    @Column(name = "CUSTOMER_ID", nullable = false)
    private String customerId;

    @Column(name = "CUSTOMER_ID_TYPE")
    private String customerIdType;

    @Column(name = "DATETIME", nullable = false)
    private String datetime;

}