package com.sc.rdc.csl.ss.dal.hk.entity.customer;

import com.sc.rdc.csl.ss.common.dto.BaseDto;

public class CustomerPersonalizedSettingsEntity extends BaseDto {

    private static final long serialVersionUID = -1L;

    private Long id;
    private Long customerProfileId;
    private String defaultLanguage;
    private String currentLanguage;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    public Long getCustomerProfileId() {
        return customerProfileId;
    }

    public void setCustomerProfileId(Long customerProfileId) {
        this.customerProfileId = customerProfileId;
    }

    public String getDefaultLanguage() {
        return defaultLanguage;
    }

    public void setDefaultLanguage(String defaultLanguage) {
        this.defaultLanguage = defaultLanguage;
    }

    public String getCurrentLanguage() {
        return currentLanguage;
    }

    public void setCurrentLanguage(String currentLanguage) {
        this.currentLanguage = currentLanguage;
    }
}
