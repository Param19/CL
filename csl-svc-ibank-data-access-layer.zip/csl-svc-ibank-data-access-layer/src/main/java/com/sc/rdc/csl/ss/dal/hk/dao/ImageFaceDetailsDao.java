package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.rdc.csl.ss.dal.hk.entity.card.AtmCardType;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerDetailEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

@Repository(value = "ImageFaceDetailsDaoHk")
@Slf4j
public class ImageFaceDetailsDao extends BaseDao {

    public static String GET_DC_SUBTYPES = "select  A from com.sc.rdc.csl.ss.dal.hk.entity.card.AtmCardType A, WHERE A.atmCardTypeId = :atmCardTypeId ";

    public String getDcSubtypes(String atmCardTypeId) {

        log.info("atmCardTypeId:", atmCardTypeId);
        Query query = entityManagerHk.createQuery(GET_DC_SUBTYPES);
        query.setParameter("atmCardTypeId", atmCardTypeId);
        List<AtmCardType> atmCardTypestmCardType = query.getResultList();
        String messageSenderId = null;
        return messageSenderId;
    }

    public CustomerDetailEntity getCustomerDetail(String customerId) {
        log.info(" getCustomerDetail CustomerId:", customerId);
        Query query = entityManagerHk.createQuery(GET_DC_SUBTYPES);
        query.setParameter("customerId", customerId);
        List<CustomerDetailEntity> customerdetails = query.getResultList();
        if (!customerdetails.isEmpty()) {
            return customerdetails.get(0);
        }
        return null;
    }
}
