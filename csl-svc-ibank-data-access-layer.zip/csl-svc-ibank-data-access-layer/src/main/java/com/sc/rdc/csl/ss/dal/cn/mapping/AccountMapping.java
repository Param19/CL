/**
 * CASAMapping.java / Jun 16, 2017 / CSL-SVC-CASAS-1.0.0
 */
package com.sc.rdc.csl.ss.dal.cn.mapping;

import com.sc.rdc.csl.ss.common.dto.account.AccountDto;
import com.sc.rdc.csl.ss.dal.cn.entity.AccountEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class AccountMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        // Account
        orikaMapperFactory
                .classMap(AccountEntity.class, AccountDto.class)
                //.field("localCurrentBalance", "localCurrentBalance")
                .field("customerId", "customerId")
                //.mapNulls(false)
                .byDefault()
                .register();

    }
}

