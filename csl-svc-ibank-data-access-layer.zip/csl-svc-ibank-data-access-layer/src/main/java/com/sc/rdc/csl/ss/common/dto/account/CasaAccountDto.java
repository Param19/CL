package com.sc.rdc.csl.ss.common.dto.account;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import lombok.Data;

@Data
@XmlType(name = "casaAccountDto")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CasaAccountDto extends SsBaseDto {
    private String operationMode;
    private String linkedRelationshipNumber;
    private String linkedRelationshipTypeCode;
    private String accountToCustomerName;
    private String moneyMasterInd;
    private String aggregateInd;
    private String payrollInd;
    private String customerInformation;
    private String accountNumber;
    private String accountProductCode;
    private String accountSubProductCode;
    private String currentStatus;       
    private String accountCurrencyCode;
    private BigDecimal ledgerBalance;
    private BigDecimal ledgerBalanceLCY;
    private BigDecimal availableBalance;
    private BigDecimal availableBalanceLCY;
    private BigDecimal avlBalWOWealthPro;
    private BigDecimal avlBalWOWealthProLCY;
    private String linkedRelationshipTypeCode2;        
    private String linkedRelationshipTypeCode3;                
    private String shortName;
    private String requestSequenceNumber;  
    private WealthInfo wealthInfo;
    private TermInfo termInfo;
    private LimitDetails limitDetails;
 }
                        