package com.sc.rdc.csl.ss.main.service;


import com.sc.rdc.csl.ss.common.dto.card.CardFaceDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("dcImageFaceServiceImpl")
@Slf4j
public class DcImageFaceServiceImpl {

    @Autowired
    private DcImageFaceFactory dcImageFaceFactory;

    public List<CardFaceDto> getDcImageFaces(String segmentCd, String ctry) {
        log.info("getDcImageFaces starts");
        List<CardFaceDto> cardFaceDtoList = dcImageFaceFactory.getDcImageService(ctry).getDcImageFaces(segmentCd, ctry);
        log.info("getDcImageFaces ends");
        return cardFaceDtoList;
    }


}