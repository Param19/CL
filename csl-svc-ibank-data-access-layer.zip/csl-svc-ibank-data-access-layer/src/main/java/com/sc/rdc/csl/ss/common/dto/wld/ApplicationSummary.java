package com.sc.rdc.csl.ss.common.dto.wld;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.util.List;
import lombok.Data;

@Data
public class ApplicationSummary extends SsBaseDto {
   private List<ApplicationDto> applicationDtoList ; 
}
