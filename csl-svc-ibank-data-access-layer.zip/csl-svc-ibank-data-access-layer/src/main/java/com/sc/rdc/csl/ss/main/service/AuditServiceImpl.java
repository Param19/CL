package com.sc.rdc.csl.ss.main.service;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.util.CSLAssert;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.audit.Audit;
import com.sc.rdc.csl.ss.common.helper.AuditConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IAuditService;

import lombok.extern.slf4j.Slf4j;

@Service("auditServiceImpl")
@Slf4j
public class AuditServiceImpl extends IAuditService {

    @Autowired
    private AuditServiceFactory auditServiceFactory;

    @Autowired
	CSLRequestContext cslRequestContext;
    
    @Override
    public Audit auditTransaction(Audit audit,SsCSLUser user) {
        validateHeaders(user);
        validateBody(audit,user);
        audit = auditServiceFactory.getAuditService(user.getCountry()).auditTransaction(audit, user);
        return audit;
    }

    private void validateHeaders(SsCSLUser cslUser) {
        CSLAssert.notNull(cslUser, ErrorConstant.AUDIT_NO_HEADER);
        CSLAssert.hasLength(cslUser.getCountry(), ErrorConstant.AUDIT_NO_COUNTRY);
        CSLAssert.hasLength(cslUser.getRelId(), ErrorConstant.AUDIT_NO_RELID);
    }
    
    private void validateBody(Audit audit,SsCSLUser user) {
	        CSLAssert.notNull(audit, ErrorConstant.AUDIT_INFO);
	        CSLAssert.hasLength(audit.getAuditInfo(), ErrorConstant.AUDIT_INFO);
	        CSLAssert.doesNotContain(AuditConstant.DATETIME, audit.getAuditInfo(), ErrorConstant.AUDIT_INFO_INVALID);
	        CSLAssert.hasLength(StringUtils.substringAfter(audit.getAuditInfo(),AuditConstant.DATETIME+"="), ErrorConstant.AUDIT_INFO_INVALID);
	        CSLAssert.hasLength(audit.getFunctionCd(), ErrorConstant.AUDIT_INFO_INVALID);
	        CSLAssert.hasLength(cslRequestContext.getRequestId(),ErrorConstant.AUDIT_NO_REQUESTID);
	        
    }
}
