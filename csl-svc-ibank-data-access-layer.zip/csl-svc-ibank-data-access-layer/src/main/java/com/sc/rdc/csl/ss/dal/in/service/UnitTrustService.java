package com.sc.rdc.csl.ss.dal.in.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.unittrust.UnitTrustDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IUnitTrustService;
import com.sc.rdc.csl.ss.dal.in.dao.ProductDescServiceDao;
import com.sc.rdc.csl.ss.dal.in.dao.UnitTrustDao;
import com.sc.rdc.csl.ss.dal.in.entity.UnitTrustSummaryEntity;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service("unitTrustServiceIn")
public class UnitTrustService extends IUnitTrustService {

    @Autowired
    @Qualifier("unitTrustDaoIn")
    private UnitTrustDao unitTrustDao;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    @Autowired
    @Qualifier("productDescServiceDaoIn")
    private ProductDescServiceDao productDescServiceDao;

    @Transactional(value = "transactionManagerIn" , readOnly = true)
    @LogTimeTaken
    public List<UnitTrustDto> findAllUnitTrusts() {

        List<UnitTrustDto> unitTrustDtos = new ArrayList<>();
        try {
            Optional<List<UnitTrustSummaryEntity>> unitTrustEntities = Optional.ofNullable(unitTrustDao.findAllUnitTrusts());
            unitTrustEntities.get().forEach(unitTrust -> {
                UnitTrustDto unitTrustDto = new UnitTrustDto();
                unitTrustDto.setId((unitTrust.getAccountNumber() + "-" + unitTrust.getFundCode()).trim());
                unitTrustDto.setAccountNumber(unitTrust.getAccountNumber().trim());
                unitTrustDto.setCurrencyCode(unitTrust.getCurrencyCode().trim());
                unitTrustDto.setRelId(unitTrust.getRelId().trim());
                unitTrustDto.setAvailableBalance(unitTrust.getAvailableBalance());
                unitTrustDto.setFundShortName(unitTrust.getFundShortName().trim());
                unitTrustDto.setProductdescription(productDescServiceDao.getproductDescription(unitTrust.getProductCode(), unitTrust.getSubProductCode(), requestContext.getLanguage()));
                unitTrustDtos.add(unitTrustDto);
            });
        } catch (Exception e) {
            log.error("Exception while fetching Unit Trusts {}", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_UNIT_TRUST);
        }
        return unitTrustDtos;
    }
}

