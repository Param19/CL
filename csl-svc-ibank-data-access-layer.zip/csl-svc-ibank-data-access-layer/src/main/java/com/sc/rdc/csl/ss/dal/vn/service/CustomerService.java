package com.sc.rdc.csl.ss.dal.vn.service;


import java.util.Optional;

import com.sc.csl.retail.core.log.LogTimeTaken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerProfile;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICustomerService;
import com.sc.rdc.csl.ss.dal.vn.config.DozerUtilsVN;
import com.sc.rdc.csl.ss.dal.vn.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.vn.entity.CustomerEntity;

import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service("customerServiceVN")
public class CustomerService extends ICustomerService {

    @Autowired
    @Qualifier("customerServiceDaoVN")
    private CustomerServiceDao customerServiceDao;


    @Qualifier("dozerUtilsVN")
    @Autowired  
    private DozerUtilsVN dozerUtilsVN;

    @Transactional(value = "transactionManagerVN",readOnly = true)
    @LogTimeTaken
    public CustomerProfile getCustomerProfile(SsCSLUser user) {
    	CustomerProfile customer = new CustomerProfile();
        try {
            Optional<CustomerEntity> customerEntity = Optional.ofNullable(customerServiceDao.getCustomerProfile(user));
            customerEntity.orElseThrow(() -> new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION));
            log.info("DB VALUE :"+customerEntity.get());
            //Profile profile = orikaMapper.map(customerEntity.get(), Profile.class);
            //customer.setProfile(profile);
            
            Profile profile = dozerUtilsVN.convertCustomer(new Profile(), customerEntity.get(),"CustomerProfile");
            log.info("profile after mapping :"+profile);
            customer.setStatusCode(SsConstant.SS_SUCCESS_STATUS);
            customer.setProfile(profile);
        } catch (Exception e) {
        	log.info("exception details "+e.getClass());
        	if(e instanceof BusinessException)
        		throw e;
        	if(e instanceof EmptyResultDataAccessException)
        		throw new BusinessException(ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION);
        	else{
        		log.error("Exception while fetching Customerprofile {} , {} ", user.getCustomerId(), e.getMessage());
        		throw new TechnicalException(ErrorConstant.ERR_FETCHING_CUSTOMER);
        	}
        }
        return customer;
    }

}
