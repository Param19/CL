package com.sc.rdc.csl.ss.dal.vn.config;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
public class SsDozerConfigVN {

        
	@Bean("dozerMappingFilesVN")
	public DozerMappingFilesVN dozerMappingFiles() {
		return new DozerMappingFilesVN();
	}


	@Bean("dozerBeanMapperVN")
	public DozerBeanMapper dozerBeanMapperVN( DozerMappingFilesVN dozerMappingFiles) {
		dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/vn/dozer/customer-profile-mappings.xml");
		dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/vn/dozer/audit-mappings.xml");
		return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
	}

	@Setter
	@Getter
	private class DozerMappingFilesVN {
 		private List<String> mappingFiles = new ArrayList<>();
	}
        
        
}
