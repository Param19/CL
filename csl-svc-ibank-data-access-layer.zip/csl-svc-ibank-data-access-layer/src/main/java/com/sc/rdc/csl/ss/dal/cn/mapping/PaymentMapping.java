/**
 * CASAMapping.java / Jun 16, 2017 / CSL-SVC-CASAS-1.0.0
 */
package com.sc.rdc.csl.ss.dal.cn.mapping;

import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import com.sc.rdc.csl.ss.common.dto.payment.ScheduledTransactionsSafeDto;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.PaymentEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.payment.ScheduledTransactionsSafeEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class PaymentMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        // Payment
        orikaMapperFactory
                .classMap(PaymentEntity.class, PaymentDto.class)
                .field("transactionId", "transactionId")
                .exclude("transactionStatusCode")
                .byDefault()
                .register();

        // ScheduledTransactionsSafe
        orikaMapperFactory
                .classMap(ScheduledTransactionsSafeEntity.class, ScheduledTransactionsSafeDto.class)
                .byDefault()
                .register();

    }
}

