package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.IAccountService;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component()
@Slf4j
public class AccountServiceFactory {
    
    @Qualifier("accountServiceCn")
    @Autowired
    private IAccountService accountServiceCn;

    @Qualifier("accountServiceHk")
    @Autowired
    private IAccountService accountServiceHk;

    @Qualifier("accountServiceSg")
    @Autowired
    private IAccountService accountServiceSg;

    @Qualifier("accountServiceIn")
    @Autowired
    private IAccountService accountServiceIn;

    @Qualifier("accountServiceAe")
    @Autowired
    private IAccountService accountServiceAe;

    public IAccountService getAccountService(String country)
    {
        switch (StringUtils.upperCase(country)) {
            case Constants.HK:
                return accountServiceHk;
            case Constants.CN:
                return accountServiceCn;
            case Constants.SG:
                return accountServiceSg;
            case Constants.IN:
                return accountServiceIn;
            case Constants.AE:
                return accountServiceAe;
            default: 
                log.error("############ Country not supported ###########");
                return null;
        }
    }
}
