package com.sc.rdc.csl.ss.dal.in.dao;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.in.entity.UnitTrustSummaryEntity;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Repository(value ="unitTrustDaoIn")
@Slf4j
public class UnitTrustDao extends BaseDao {

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<UnitTrustSummaryEntity> findAllUnitTrusts() {
        List<UnitTrustSummaryEntity> unitTrustList = new ArrayList<>();
        Query query = entityManagerIn.createQuery("select b.accountNumber, b.currencyCode, b.relId, b.availableBalance, b.productCode, b.subProductCode, t.fundShortName, t.fundCode from com.sc.rdc.csl.ss.dal.in.entity.UnitTrustBalanceEntity b, " +
                "com.sc.rdc.csl.ss.dal.in.entity.UnitTrustTransactionHistoryEntity t where b.accountNumber = t.accountNumber and b.relId = :relId");
        query.setParameter("relId", requestContext.getCustomerId());
        List<Object[]> unitTrusts = query.getResultList();
        log.info("No of UnitTrusts {} for User Id {}", unitTrusts.size(), requestContext.getRelId());
        for (Object[] unitTrustRecord : unitTrusts) {
            UnitTrustSummaryEntity unitTrustSummaryEntity = new UnitTrustSummaryEntity();
            unitTrustSummaryEntity.setAccountNumber((String)unitTrustRecord[0]);
            unitTrustSummaryEntity.setCurrencyCode((String)unitTrustRecord[1]);
            unitTrustSummaryEntity.setRelId((String)unitTrustRecord[2]);
            unitTrustSummaryEntity.setAvailableBalance((BigDecimal)unitTrustRecord[3]);
            unitTrustSummaryEntity.setProductCode((String)unitTrustRecord[4]);
            unitTrustSummaryEntity.setSubProductCode((String)unitTrustRecord[5]);
            unitTrustSummaryEntity.setFundShortName((String)unitTrustRecord[6]);
            unitTrustSummaryEntity.setFundCode((String)unitTrustRecord[7]);
            unitTrustList.add(unitTrustSummaryEntity);
        };
        return unitTrustList;
    }
}

