package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.account.DealInfo;

import java.util.List;

/**
 * Created by 1347884 on 11/29/2017.
 */
public abstract class IDealService {

    public List<DealInfo> getDealInfo() {
        return null;
    }

}
