package com.sc.rdc.csl.ss.main.service;


import com.sc.rdc.csl.ss.common.dto.account.ProductDescriptionDto;
import com.sc.rdc.csl.ss.common.service.ProductDescriptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productDescriptionServiceImpl")
@Slf4j
public class ProductDescriptionServiceImpl extends ProductDescriptionService {

    @Autowired
    private ProductDescriptionServiceFactory productDescriptionServiceFactory;

    @Override
    public ProductDescriptionDto getproductDescription(ProductDescriptionDto productDescriptionDto) {

        ProductDescriptionDto productDescription  = productDescriptionServiceFactory.getproductDescription(productDescriptionDto.getCountryCode()).getproductDescription(productDescriptionDto);

        return productDescription;
    }
}
