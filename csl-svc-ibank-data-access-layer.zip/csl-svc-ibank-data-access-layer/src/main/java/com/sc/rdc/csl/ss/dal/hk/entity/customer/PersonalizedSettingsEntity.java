package com.sc.rdc.csl.ss.dal.hk.entity.customer;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import com.sc.rdc.csl.ss.dal.hk.entity.account.ProductEntity;
import java.math.BigDecimal;
import java.util.Set;

public class PersonalizedSettingsEntity extends BaseDto {

    private static final long serialVersionUID = -1L;

    private String settingId;
    private String name;
    private Boolean isNameDisplayable;
    private Boolean isNameReadOnly;
    private String accountNumber;
    private Boolean isNumberDisplayable;
    private Boolean isNumberReadOnly;
    private Boolean isRemoved;
    private String settingType;
    private String customerId;
    private Integer orderNumber;
    private String preferredLanguage;
    private BigDecimal limitDecreasingAmount;
    private BigDecimal transferLimitAmount;
    private BigDecimal ttLimitAmount;
    private String limitDecreasingCurrency;
    private String customerEBID;
    private String proCode;
    private String productName;
    private Set deviceGroupList;
    private BigDecimal coLimitAmount;
    private String currencyCode;

    private DeviceGroupEntity deviceGroupDto;

    // for account sorting product display purpose
    private String productDisplayName;
    private ProductEntity productDto;

    /**
     * @return the customerEBID
     */
    public String getCustomerEBID() {
        return customerEBID;
    }

    /**
     * @param customerEBID the customerEBID to set
     */
    public void setCustomerEBID(String customerEBID) {
        this.customerEBID = customerEBID;
    }

    /**
     * @return the isNameDisplayable
     */
    public Boolean getIsNameDisplayable() {
        return isNameDisplayable;
    }

    /**
     * @param isNameDisplayable the isNameDisplayable to set
     */
    public void setIsNameDisplayable(Boolean isNameDisplayable) {
        this.isNameDisplayable = isNameDisplayable;
    }

    /**
     * @return the isNameReadOnly
     */
    public Boolean getIsNameReadOnly() {
        return isNameReadOnly;
    }

    /**
     * @param isNameReadOnly the isNameReadOnly to set
     */
    public void setIsNameReadOnly(Boolean isNameReadOnly) {
        this.isNameReadOnly = isNameReadOnly;
    }

    /**
     * @return the isNumberDisplayable
     */
    public Boolean getIsNumberDisplayable() {
        return isNumberDisplayable;
    }

    /**
     * @param isNumberDisplayable the isNumberDisplayable to set
     */
    public void setIsNumberDisplayable(Boolean isNumberDisplayable) {
        this.isNumberDisplayable = isNumberDisplayable;
    }

    /**
     * @return the isNumberReadOnly
     */
    public Boolean getIsNumberReadOnly() {
        return isNumberReadOnly;
    }

    /**
     * @param isNumberReadOnly the isNumberReadOnly to set
     */
    public void setIsNumberReadOnly(Boolean isNumberReadOnly) {
        this.isNumberReadOnly = isNumberReadOnly;
    }

    /**
     * @return the isRemoved
     */
    public Boolean getIsRemoved() {
        return isRemoved;
    }

    /**
     * @param isRemoved the isRemoved to set
     */
    public void setIsRemoved(Boolean isRemoved) {
        this.isRemoved = isRemoved;
    }

    /**
     * @return the limitDecreasingAmount
     */
    public BigDecimal getLimitDecreasingAmount() {
        return limitDecreasingAmount;
    }

    /**
     * @param limitDecreasingAmount the limitDecreasingAmount to set
     */
    public void setLimitDecreasingAmount(BigDecimal limitDecreasingAmount) {
        this.limitDecreasingAmount = limitDecreasingAmount;
    }

    /**
     * @return
     */
    public BigDecimal getTransferLimitAmount() {
        return transferLimitAmount;
    }

    /**
     * @param transferLimitAmount
     */
    public void setTransferLimitAmount(BigDecimal transferLimitAmount) {
        this.transferLimitAmount = transferLimitAmount;
    }

    /**
     * @return the limitDecreasingCurrency
     */
    public String getLimitDecreasingCurrency() {
        return limitDecreasingCurrency;
    }

    /**
     * @param limitDecreasingCurrency the limitDecreasingCurrency to set
     */
    public void setLimitDecreasingCurrency(String limitDecreasingCurrency) {
        this.limitDecreasingCurrency = limitDecreasingCurrency;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the orderNumber
     */
    public Integer getOrderNumber() {
        return orderNumber;
    }

    /**
     * @param orderNumber the orderNumber to set
     */
    public void setOrderNumber(Integer orderNumber) {
        this.orderNumber = orderNumber;
    }

    /**
     * @return the preferredLanguage
     */
    public String getPreferredLanguage() {
        return preferredLanguage;
    }

    /**
     * @param preferredLanguage the preferredLanguage to set
     */
    public void setPreferredLanguage(String preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    /**
     * @return the productId
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the productId to set
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * @return the settingId
     */
    public String getSettingId() {
        return settingId;
    }

    /**
     * @param settingId the settingId to set
     */
    public void setSettingId(String settingId) {
        this.settingId = settingId;
    }

    /**
     * @return the settingType
     */
    public String getSettingType() {
        return settingType;
    }

    /**
     * @param settingType the settingType to set
     */
    public void setSettingType(String settingType) {
        this.settingType = settingType;
    }

    /**
     * @return the userId
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * @param customerId the userId to set
     */
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Set getDeviceGroupList() {
        return deviceGroupList;
    }

    public void setDeviceGroupList(Set deviceGroupList) {
        this.deviceGroupList = deviceGroupList;
    }

    public String getProCode() {
        return proCode;
    }

    public void setProCode(String proCode) {
        this.proCode = proCode;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductDisplayName() {
        return productDisplayName;
    }

    public void setProductDisplayName(String productDisplayName) {
        this.productDisplayName = productDisplayName;
    }

    public DeviceGroupEntity getDeviceGroupDto() {
        return deviceGroupDto;
    }

    public void setDeviceGroupVO(DeviceGroupEntity deviceGroupDto) {
        this.deviceGroupDto = deviceGroupDto;
    }

    public ProductEntity getProductDto() {
        return productDto;
    }

    public void setProductDto(ProductEntity productDto) {
        this.productDto = productDto;
    }

    public BigDecimal getTtLimitAmount() {
        return ttLimitAmount;
    }

    public void setTtLimitAmount(BigDecimal ttLimitAmount) {
        this.ttLimitAmount = ttLimitAmount;
    }

    public BigDecimal getCoLimitAmount() {
        return coLimitAmount;
    }

    public void setCoLimitAmount(BigDecimal coLimitAmount) {
        this.coLimitAmount = coLimitAmount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }


}
