package com.sc.rdc.csl.ss.dal.sg.dao;

import com.sc.rdc.csl.ss.dal.sg.entity.TransactionLimitEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.util.List;


@Repository(value ="transactionLimitDaoSg")
@Slf4j
public class TransactionLimitDao extends BaseDao {


    public List<TransactionLimitEntity> getTransactionLimits(String ebid) {
        TypedQuery<TransactionLimitEntity> query = entityManagerSg.createQuery("select t from com.sc.rdc.csl.ss.dal.sg.entity.TransactionLimitEntity t WHERE t.ebid= :ebid ",TransactionLimitEntity.class);
        query.setParameter("ebid", ebid);
        return query.getResultList();
    }
}
