package com.sc.rdc.csl.ss.dal.sg.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.account.ProductDescriptionDto;
import com.sc.rdc.csl.ss.dal.sg.entity.FilterProductEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CARD_NO_RECORD_EXCEPTION;

@Repository(value = "productDescServiceDaoSg")
@Slf4j
public class ProductDescServiceDao extends BaseDao {


    private static final String FILTER_PRODUCT_QUERY = "select f from com.sc.rdc.csl.ss.dal.sg.entity.FilterProductEntity f where  f.lang = :lang";
    private static final String FILTER_PRODUCT_QUERY_BY_PRO_CODE = "select f from com.sc.rdc.csl.ss.dal.sg.entity.FilterProductEntity f where  "
    		+ "f.lang = :lang and f.productCode = :productCode and f.subProductCode = :subProductCode";
    
    public ProductDescriptionDto getproductDescription(ProductDescriptionDto productDescriptionDto) {
        Query query = entityManagerSg.createQuery(FILTER_PRODUCT_QUERY);

        query.setParameter("lang", productDescriptionDto.getLanguage());
        log.info("query {}", query);
        List<FilterProductEntity> filterProductEntity = query.getResultList();
        Map<String, String> productDetails = new HashMap<>();
        ProductDescriptionDto productDescriptionVO = null;
        if(filterProductEntity!=null && filterProductEntity.size()>0) {
            for (FilterProductEntity productdescResponse : filterProductEntity) {
                productDescriptionVO = new ProductDescriptionDto();
                productDetails.put(productdescResponse.getAccountCode(), productdescResponse.getAccountTypeAlias());
                productDescriptionVO.setProductDescription(productDetails);
            }
        }
        else {
            throw new BusinessException(CARD_NO_RECORD_EXCEPTION);
        }
        return productDescriptionVO;
    }

    public String getproductDescription(String productCode, String subProductCode, String language) {
        Query query = entityManagerSg.createQuery(FILTER_PRODUCT_QUERY_BY_PRO_CODE);

        query.setParameter("lang", language);
        query.setParameter("productCode", productCode);
        query.setParameter("subProductCode", subProductCode);
        log.info("query {}", query);
        List<FilterProductEntity> filterProductEntity = query.getResultList();
        String productDescription = null;
        if(filterProductEntity!=null && filterProductEntity.size()>0) {
            for (FilterProductEntity productdescResponse : filterProductEntity) {
            	productDescription = productdescResponse.getAccountTypeAlias();
            }
        }
        else {
            return "";
        }
        return productDescription;
    }



}
