package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.rdc.csl.ss.common.dto.bank.BankDetailsDto;
import com.sc.rdc.csl.ss.dal.hk.entity.bank.BankEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Repository(value = "bankDetailServiceDaoHk")
@Slf4j
public class BankDetailDao extends BaseDao {

    public static String GET_BANK_DETAIL = "select  o from com.sc.rdc.csl.ss.dal.hk.entity.bank.BankEntity o WHERE o.language = :language AND o.isDisplayable = :isDisplayable order by other1";

    public static final String IS_DiSPLAYABLE = "Y";
    public List<BankDetailsDto> getBankDetails(BankDetailsDto bankDetailsDto){

        List<BankDetailsDto> bankDataDetailList_data=null;
        log.info("getApplication::getApplication,{}", bankDetailsDto.getLanguage());
        BankDetailsDto bankdetailsVO = null;
        BankDetailsDto bankDetails_DataDto = null;
        Query query = entityManagerHk.createQuery(GET_BANK_DETAIL);
        query.setParameter("language", bankDetailsDto.getLanguage());
        query.setParameter("isDisplayable",true);
        bankDataDetailList_data = new ArrayList<BankDetailsDto>();
        List<BankEntity> bankDataDetailList = query.getResultList();
        for (BankEntity bankDataResponse : bankDataDetailList) {
            bankDetails_DataDto = new BankDetailsDto();
            bankDetails_DataDto.setBankCode(bankDataResponse.getBankCode());
            bankDetails_DataDto.setBankName(bankDataResponse.getBankName());
            bankDetails_DataDto.setId(String.valueOf(bankDataResponse.getId()));
            bankDataDetailList_data.add(bankDetails_DataDto);
        }
        return bankDataDetailList_data;
    }
}
