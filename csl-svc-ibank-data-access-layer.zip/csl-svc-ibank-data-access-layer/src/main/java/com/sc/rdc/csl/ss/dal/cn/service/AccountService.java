package com.sc.rdc.csl.ss.dal.cn.service;


import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.AccountDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IAccountService;
import com.sc.rdc.csl.ss.dal.cn.dao.AccountServiceDao;
import com.sc.rdc.csl.ss.dal.cn.dao.PersonalizedSettingsServiceDao;
import com.sc.rdc.csl.ss.dal.cn.dao.ProductServiceDao;
import com.sc.rdc.csl.ss.dal.cn.entity.AccountEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.FilterProductEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.PersonalizedSettingsEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Slf4j
@Service("accountServiceCn")
public class AccountService extends IAccountService {

    @Autowired
    @Qualifier("accountServiceDaoCn")
    private AccountServiceDao accountServiceDao;

    @Autowired
    @Qualifier("personalizedSettingsServiceDaoCn")
    private PersonalizedSettingsServiceDao personalizedSettingsServiceDao;

    @Autowired
    @Qualifier("productServiceDaoCn")
    private ProductServiceDao productServiceDao;
    
    @Autowired
    private MapperFacade orikaMapperFacade;
    
    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Transactional(value = "transactionManagerCn", readOnly = true)
    @LogTimeTaken
    public List<AccountDto> getAccountSummary() {
        List<AccountDto> accountDtoList = new ArrayList<AccountDto>();

        try {
            Optional<List<AccountEntity>> accountEntityList = Optional.ofNullable(accountServiceDao.getAccountSummary());
            Optional<List<PersonalizedSettingsEntity>> personalizedSettingsEntityList = Optional.ofNullable(personalizedSettingsServiceDao.getPersonalizedSettingsEntity());
            accountEntityList =  buildAccountList(accountEntityList, personalizedSettingsEntityList);
            log.info("accountEntityList after setting the account description ::{}", accountEntityList);
            accountEntityList.get().forEach(accountEntity -> {
                accountDtoList.add(orikaMapperFacade.map(accountEntity, AccountDto.class));
            });
            
            log.info("Orika mapper result :{}", accountDtoList);
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Account Summary for user  , {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return accountDtoList;
    }

    @Transactional(value = "transactionManagerCn", readOnly = true)
    @LogTimeTaken
    public List<AccountDto> getAccountDescription() {
    	
    	List<AccountDto> accountDescriptionDtos = new ArrayList<AccountDto>();
        try {

            Optional<List<AccountEntity>> accountEntityList = Optional.ofNullable(accountServiceDao.getAccountSummary());
            Optional<List<PersonalizedSettingsEntity>> personalizedSettingsEntityList = Optional.ofNullable(personalizedSettingsServiceDao.getPersonalizedSettingsEntity());

            accountEntityList =  buildAccountList(accountEntityList, personalizedSettingsEntityList);

            accountEntityList.get().forEach(accountEntity -> {
            	AccountDto accountDescriptionDto =  new AccountDto();
            	accountDescriptionDto.setAccountDescription(accountEntity.getAccountDescription());
            	accountDescriptionDto.setCurrencyCode(accountEntity.getCurrencyCode());
            	accountDescriptionDto.setAccountNumber(accountEntity.getAccountNumber());
            	accountDescriptionDto.setProductCode(accountEntity.getSubProductCode());
            	accountDescriptionDto.setAccountDesFilter("true");
            	accountDescriptionDtos.add(accountDescriptionDto);
            });
            
            log.info("accountDescriptionDto after setting the account description ::{}", accountDescriptionDtos);
            
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Account Summary for user  , {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return accountDescriptionDtos;
    }

        private Optional<List<AccountEntity>> buildAccountList(Optional<List<AccountEntity>> accountEntityList, Optional<List<PersonalizedSettingsEntity>> personalizedSettingsEntityList){

            Map<String, PersonalizedSettingsEntity> personalizedSettingsMap = new HashMap<>();
            personalizedSettingsEntityList.get().forEach(personalizedSettingsEntity -> {
                personalizedSettingsMap.put(personalizedSettingsEntity.getLimitDecreasingCurrency()+"-"+personalizedSettingsEntity.getAccountNumber(),personalizedSettingsEntity);
            });
            ArrayList<String> accountCodeList = new ArrayList<String>();
            accountEntityList.get().forEach(accountEntity -> {
                if(StringUtils.isNotEmpty(accountEntity.getProductCode()) && StringUtils.isNotEmpty(accountEntity.getSubProductCode())){
                    accountCodeList.add(accountEntity.getProductCode()+"-"+accountEntity.getSubProductCode());
                }
            });
            Set<String> uniqueAccountCodeList = new HashSet<String>(accountCodeList);
            String lang = requestContext.getLanguage();
            if("cn".equalsIgnoreCase(lang)){
                lang = "zh_CN";
            }
            List<FilterProductEntity> filterProductEntityList =  productServiceDao.getFilterProduct(uniqueAccountCodeList, lang);
            log.info("filterProductEntityList after setting the filterProductEntityList ::{}", filterProductEntityList);
            log.info("accountCodeList :{}",accountCodeList);
            if(accountEntityList!= null && filterProductEntityList != null){
                accountEntityList.get().forEach(accountEntity -> {
                    for(FilterProductEntity entity: filterProductEntityList){
                        if(entity!=null && StringUtils.isNotEmpty(entity.getProductCode()) && StringUtils.isNotEmpty(entity.getSubProductCode())){
                            if(accountEntity.getProductCode().equalsIgnoreCase(entity.getProductCode()) && accountEntity.getSubProductCode().equalsIgnoreCase(entity.getSubProductCode())){
                                accountEntity.setAccountDescription(entity.getAccountTypeAlias());
                            }
                        }
                    }
                });
            }
            log.info("accountEntityList after setting the account description ::{}", accountEntityList);
            accountEntityList.get().forEach(accountEntity -> {
                PersonalizedSettingsEntity personalizedSettingsEntity = personalizedSettingsMap.get(accountEntity.getCurrencyCode()+"-"+accountEntity.getAccountNumber());
                if(personalizedSettingsEntity!=null && StringUtils.isNotEmpty(personalizedSettingsEntity.getName()))
                    accountEntity.setAccountDescription(personalizedSettingsEntity.getName());
            });

            log.info("accountEntityList after setting the personalizedSettingsEntity description ::{}", accountEntityList);

            return accountEntityList;
    }

}
