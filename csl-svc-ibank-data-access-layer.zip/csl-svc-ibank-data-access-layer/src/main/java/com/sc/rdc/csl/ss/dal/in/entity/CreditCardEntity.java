package com.sc.rdc.csl.ss.dal.in.entity;

import io.katharsis.resource.annotations.JsonApiId;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

@Data
public class CreditCardEntity implements Serializable{

    @JsonApiId
    private String uuid = UUID.randomUUID().toString();
    private Long id;
    private String customerNumber;
    private String orgCode;
    private String cardType;
    private String expDt;
    private String sourceCode;
    private String statementFlag;
    private String pastDueFlag;					//paymentDueDateStatus
    private Date openedDate;
    private Date billDueDate;
    private Date lastBillDate;					//lastStmtBalAmount
    private Date lastPaymentDate;
    private BigDecimal creditLimit;
    private BigDecimal localCreditLimit;
    private BigDecimal availableLimit;
    private BigDecimal currentMinDue;
    private BigDecimal minimumPayment;
    private BigDecimal localMinimumPayment;
    private BigDecimal lastBillAmount;
    private BigDecimal localLastBillAmount;
    private BigDecimal lastPaymentAmount;
    private BigDecimal totalAmountDue;
    private BigDecimal lastStmtBalAmount;
    private BigDecimal outstandingAmount;

    private Boolean combinedLimitIndicator;
    private BigDecimal localCurrentBalance;
    private BigDecimal conversionRate;
    //    private CardLimitDto cardLimitDto;
    private Boolean isATMComboCard = false;

    private String relId;
    private String relIdType;
    private Date updatedDate;

    private String updatedBy;
    private Integer index;
    private String customerId;
    private String customerIdType;
    private String productCode;
    private String subProd;
    private String cardNum;
    private String accountName;
    private String accountDescription;
    private String consolidatedCode;

    private String accountStatus;
    private String blockCode;
    private String relationshipCode;
    private String currencyCode;
    private BigDecimal currentBalance;
    private BigDecimal availableBalance;
}
