package com.sc.rdc.csl.ss.dal.ae.config;

import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component
public class DozerUtilsAe {

    @Qualifier("dozerBeanMapperAe")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    public Profile convertCustomer(Profile profile, CustomerVO customerEntity, String mapId)  {
        if (customerEntity== null || profile==null) {
            return null;
        }
        dozerBeanMapper.map(customerEntity, profile,mapId);
        return profile;
    }

}
