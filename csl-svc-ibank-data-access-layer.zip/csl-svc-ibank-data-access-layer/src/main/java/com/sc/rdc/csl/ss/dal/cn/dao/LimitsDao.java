package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.cn.entity.LimitsEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.List;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_PAYMENT_EXCEPTION;
import static com.sc.rdc.csl.ss.dal.cn.config.LimitsConstant.CUSTOMER_DAILY_LIMIT;
import static com.sc.rdc.csl.ss.dal.cn.config.LimitsConstant.STATUS_ENABLED;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Repository(value = "limitsDaoCN")
public class LimitsDao extends BaseDao {

    @Autowired
    private CSLRequestContext cslRequestContext;

    public List<LimitsEntity> getAllLimits(List<String> category, String segment, String countryCode) {
        List<LimitsEntity> limitsEntityList = null;
        try {
            Query query = entityManagerCn.createQuery("SELECT o FROM LimitsEntity o WHERE o.category in :category and o.segment = :segment and o.countryCode = :countryCode");
            query.setParameter("category", category);
            query.setParameter("segment", segment);
            query.setParameter("countryCode", countryCode);
            limitsEntityList = query.getResultList();
            return limitsEntityList;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

    public BigDecimal getCustomerDefaultLimit(String ebid, String transactionType, String segmentType) {
        try {
            Query query = entityManagerCn.createQuery("SELECT o.defLimit from LimitsEntity o where o.customerId = :customerId and o.ebid = :ebid and " +
                    "o.transactionType = :transactionType and o.category = :category and o.segment = :segment and " +
                    "o.countryCode = :countryCode and o.status = :status");
            query.setParameter("customerId", cslRequestContext.getCustomerId());
            query.setParameter("ebid", ebid);
            query.setParameter("transactionType", transactionType);
            query.setParameter("category", CUSTOMER_DAILY_LIMIT);
            query.setParameter("segment", segmentType);
            query.setParameter("countryCode", cslRequestContext.getCountry());
            query.setParameter("status", STATUS_ENABLED);
            return (BigDecimal) query.getSingleResult();
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }
}
