
package com.sc.rdc.csl.ss.dal.sg.dao;

import com.sc.rdc.csl.ss.dal.sg.entity.FilterProductEntity;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;
import javax.persistence.Query;

@Repository(value = "productServiceDaoSg")
@Slf4j
public class ProductServiceDao extends BaseDao {

    private static final String FILTER_PRODUCT_QUERY = "select f from com.sc.rdc.csl.ss.dal.sg.entity.FilterProductEntity f where f.accountCode IN (:accountCode) and f.lang = :lang";

    public List<FilterProductEntity> getFilterProduct(Set<String> accountCodeList, String lang) {
        Query query = entityManagerSg.createQuery(FILTER_PRODUCT_QUERY);
        query.setParameter("accountCode", accountCodeList);
        query.setParameter("lang", lang);
        log.info("query {}", query);
        try {
            return (List<FilterProductEntity>) query.getResultList();
        } catch (javax.persistence.NoResultException e) {
            log.warn("No record found in FilterProductEntity for Account Code:{} & lang:{}", accountCodeList, lang);
            return null;
        }
    }

}
