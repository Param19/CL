package com.sc.rdc.csl.ss.common.dto.account;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.util.List;
import lombok.Data;

@Data
public class CasaAccountSummary extends SsBaseDto {
   private List<CasaAccountDto> wealthAccountList ; 
}
