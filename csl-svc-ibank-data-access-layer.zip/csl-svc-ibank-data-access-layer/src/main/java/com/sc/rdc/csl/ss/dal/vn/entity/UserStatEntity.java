package com.sc.rdc.csl.ss.dal.vn.entity;

import lombok.Data;

@Data
/*@Entity
@Table(name = "DB2INST1", schema = "USERSTAT")*/
public class UserStatEntity {

	//@Id
	//@Column(name = "USERID")
	private String userId;
	
	//@Column(name = "CUSTIDTYPE")
	private String custIdType;
	
	//@Column(name = "CNTRYCODE")
	private String coutnryCode;
}
