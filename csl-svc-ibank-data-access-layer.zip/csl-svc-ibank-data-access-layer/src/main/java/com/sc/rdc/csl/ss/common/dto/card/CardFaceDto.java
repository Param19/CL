package com.sc.rdc.csl.ss.common.dto.card;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

@Data

@JsonApiResource(type = "card-faces")
public class CardFaceDto extends SsBaseDto {

    @JsonApiId
    @JsonProperty("card-face-id")
    private String cardFaceId;

    @JsonProperty("sub-type")
    private String subType;

    @JsonProperty("cust-seg")
    private String custSeg;

    @JsonProperty("atm-card-type")
    private String atmCardType;

    @JsonProperty("image-content")
    private byte[] imageContent;

    @JsonProperty("label-eng")
    private String labelEng;

    @JsonProperty("label-chn")
    private String labelChn;

    @JsonProperty("label-hk")
    private String labelHk;

}
