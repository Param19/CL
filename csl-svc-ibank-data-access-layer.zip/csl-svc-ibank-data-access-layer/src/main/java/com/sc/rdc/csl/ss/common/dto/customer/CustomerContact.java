package com.sc.rdc.csl.ss.common.dto.customer;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.Setter;

/**
 * @author 1452875
 * @since Jun 30, 2017
 */
@Setter
@Getter
@JsonApiResource(type = "contacts")
public class CustomerContact {

    private static final long serialVersionUID = 7058050166460825314L;
    @JsonApiId
    private String contactTypeCode = null;
    @JsonProperty("contact-type-desc")
    private String contactTypeDesc = null;
    @JsonProperty("contact-classification")
    private String contactClassification = null;
    @JsonProperty("contact-details")
    private String contactDetails = null;
    @JsonProperty("rel-id")
    private String relId = null;
    @JsonProperty("customer-name")
    private String customerName = null;
    @JsonProperty("customer-email")
    private String customerEmail = null;
    @JsonProperty("contact-sequence-number")
    private String contactSequenceNumber = null;
    
}
