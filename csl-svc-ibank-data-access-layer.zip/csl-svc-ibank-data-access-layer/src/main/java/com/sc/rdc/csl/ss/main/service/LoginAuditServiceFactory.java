package com.sc.rdc.csl.ss.main.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.AbstractLoginAuditService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component()
public class LoginAuditServiceFactory {
	 	@Qualifier("loginAuditServiceHk")
	    @Autowired
	    private AbstractLoginAuditService loginAuditServiceHk;

	    @Qualifier("loginAuditServiceSg")
	    @Autowired
	    private AbstractLoginAuditService loanServiceSg;

	    @Qualifier("loginAuditServiceIn")
	    @Autowired
	    private AbstractLoginAuditService loanServiceIn;

	    public AbstractLoginAuditService getLoginAuditService(String country)
	    {
	        switch (StringUtils.upperCase(country)) {
	            case Constants.HK:
	                return loginAuditServiceHk;
	            case Constants.SG:
	                return loanServiceSg;
	            case Constants.IN:
	                return loanServiceIn;
	            default: 
	                log.error("############ Country not supported ###########");
	                throw new BusinessException(TemplateErrorCode.create(ErrorConstant.AUDIT_SERVICE_NOT_ALLOWED, "LoginAuditService", country));
	        }
	    }
}
