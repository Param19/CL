package com.sc.rdc.csl.ss.dal.sg.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.sg.entity.AccountTransactionEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Repository(value ="accountTransactionDaoSg")
@Slf4j
public class AccountTransactionDao extends BaseDao {

    public List<AccountTransactionEntity> getAccountTransactions(String accountNo, String fromDate) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date effectiveDate = format.parse(fromDate);
        Date today = new Date();
        Query query = entityManagerSg.createQuery("select a from com.sc.rdc.csl.ss.dal.sg.entity.AccountTransactionEntity a WHERE a.accountNo = :accountNo " +
                "and a.transactionEffectiveDate between :effectiveDate and :today")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("accountNo", accountNo);
        query.setParameter("effectiveDate", effectiveDate);
        query.setParameter("today", today);
        List<AccountTransactionEntity> accountTransactionEntities = query.getResultList();
        log.info("Received {} AccountTransaction record(s) from DB for Account No {}",
                (accountTransactionEntities != null ? accountTransactionEntities.size() : 0), accountNo);
        if(!(accountTransactionEntities !=null && accountTransactionEntities.size() > 0))
            throw new BusinessException(ErrorConstant.CASA_NO_TRANSACTION_FOUND);
        return accountTransactionEntities;
    }

    public List<AccountTransactionEntity> getTransactions(List<String> accountNos , String fromDate,String toDate) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = format.parse(fromDate);
        Date endDate  = format.parse(toDate);
        Query query = entityManagerSg.createQuery("select a from com.sc.rdc.csl.ss.dal.sg.entity.AccountTransactionEntity a WHERE a.accountNo in ( :accountNo )" +
                "and a.transactionEffectiveDate between :startDate and :endDate");
        query.setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("accountNo", accountNos);
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        List<AccountTransactionEntity> accountTransactionEntities = query.getResultList();
        log.info("Received {} AccountTransaction record(s) from DB for Account No {}",
                (accountTransactionEntities != null ? accountTransactionEntities.size() : 0), accountNos);
        if(!(accountTransactionEntities !=null && accountTransactionEntities.size() > 0))
            log.warn("NO TRANSACTIONS FOUND BETWEEN {} & {} ",startDate,endDate);
        return accountTransactionEntities;
    }

}