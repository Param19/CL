package com.sc.rdc.csl.ss.dal.cn.entity.customer;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;


/**
 * TBL_CUST
 * @author 1493439
 */
@Data
public class CustomerProfileEntity extends BaseDto {
    private static final long serialVersionUID = 1L;

    private Long id;
    private String customerEBID;
    private String customerPBID;
    private String customerId;
    private String customerIdType;
    private String customerName1;
    private String customerName2;
    private String nickName;
    private String customerMMName1;
    private String customerMMName2;
    private String address1;
    private String address2;
    private String address3;
    private String address4;
    private String district;
    private String area;
    private String country;
    private String postalCode;
    private String residenceCode;
    private String nationalityCode;
    private String nationId;
    private String statusCode;
    private Date openDate;
    private String branchCode;
    private String armCode;
    private String pbo;
    private String opbMarketingSegment;
    private String sex;
    private Date dateOfBirth;
    private String maritalStatusCode;
    private String ethnic;
    private String staffRank;
    private String personalPhone;
    private String personalPhoneExt;
    private String businessPhone;
    private String businessPhoneExt;
    private String mobileCompany;
    private String mobilePhone;
    private String mobilePhoneBOA;
    private Double dailyLimit;
    private String employerFlag;
    private String scbIndicator;
    private String payIndicator;
    private String emailAddress;
    private Boolean isCOPP;
    private Date dateLastCOPP;
    private String remark;
    private String relTyp;
    private String relSubTyp;
    private Integer index;
    private String mmAddress1;
    private String mmAddress2;
    private String mmAddress3;
    private String mmAddress4;
    private String mmDistrict;
    private String mmArea;
    private String mmCountry;
    private String mmPostalCode;
    private Boolean isSmsAlert;
    private Boolean isEmailAlert;
    private String mmStatus;
    private String mmMailCode;
    private String pbHoldMailFlag;
    private String fullName;
    private String fullNameNonEng;
    private String flatNumber;
    private String flatNoNonEng;
    private String buildingName;
    private String buildingNameNonEng;
    private String nearestLandmark;
    private String nearestLandmarkNonEng;
    private String streetName;
    private String streetNameNonEng;
    private String postBox;
    private String postBoxNonEng;
    private String countryDesc;
    private String cityName;
    private String cityNameNonEng;
    private String postalCodeNonEng;
    private String addressTypeCode;
    private String addressTypeDesc;
    private String houseTypeCode;
    private String countryCode;
    private String cityCode;
    private String mailingAddress;
    private BigDecimal rentPerAnnum;
    private String contactTypeCode;
    private String contactDetails;
    private String contactLangCode;
    private int contactSequenceNo;
    private String custSegmentCode;
    private String operation;
    private String changeContactType;
    private String errorCode;
    private String failureReason;
    private String addressLangCode;
    private String mailingAddressNonEng;
    private String addressTypeCodeNonEng;
    private String placeOfBirth;
    private String placeOfBirthNonEng;
    private String residenceState;
    private String residenceStateNonEng;
    private String numYearsAtCurrentAddress;
    private String accountNo;
    private String positionTitle;
    private String positionTitleNonEng;
    private String firstNameNonEng;
    private String lastNameNonEng;
    private String firstName;
    private String lastName;
    private String middleName;
    private String middleNameNonEng;

}
