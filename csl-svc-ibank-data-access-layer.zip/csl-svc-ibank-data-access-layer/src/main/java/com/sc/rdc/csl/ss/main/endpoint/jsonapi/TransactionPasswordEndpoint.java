package com.sc.rdc.csl.ss.main.endpoint.jsonapi;

import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.hk.dto.TransactionPasswordDto;
import com.sc.rdc.csl.ss.main.service.TransactionPasswordServiceImpl;

@Component
@Slf4j
public class TransactionPasswordEndpoint extends ResourceRepositoryBase<TransactionPasswordDto, String> {

	@Autowired
	@Qualifier("transactionPasswordServiceImpl")
	private TransactionPasswordServiceImpl transactionPasswordService;

	@Autowired
	@Qualifier("cslRequestContext")
	private CSLRequestContext cslRequestContext;

	public TransactionPasswordEndpoint() {
		super(TransactionPasswordDto.class);
	}

	@Override
	public ResourceList<TransactionPasswordDto> findAll(QuerySpec querySpec) {
		throw new BusinessException(ErrorConstant.ERR_GENERIC_EXCEPTION);
	}

	@Override
	public TransactionPasswordDto findOne(String ebid, QuerySpec querySpec) {
		return transactionPasswordService.getTransactionPassword(ebid);
	}
	
	@Override
	public <S extends TransactionPasswordDto> S save(S resource) {
		transactionPasswordService.save(resource);
		return resource;
	}
}
