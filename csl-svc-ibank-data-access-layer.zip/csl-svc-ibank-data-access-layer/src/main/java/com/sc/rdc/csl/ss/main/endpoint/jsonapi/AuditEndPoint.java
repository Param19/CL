package com.sc.rdc.csl.ss.main.endpoint.jsonapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.audit.Audit;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.main.service.AuditServiceImpl;

import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Data
public class AuditEndPoint extends ResourceRepositoryBase<Audit, String> {


	@Autowired
	CSLRequestContext cslRequestContext;
	
	@Autowired
	@Qualifier("auditServiceImpl")
	AuditServiceImpl auditService;
	
	protected AuditEndPoint() {
		super(Audit.class);
	}

	@Override
	public ResourceList<Audit> findAll(QuerySpec querySpec) {try {
        log.debug("[AuditRepository findAll Entry]");
        throw new BusinessException(ErrorConstant.ERR_FETCHING_AUDIT);
    } finally {
        log.debug("[AuditRepository findAll Exit]");
    }
	}

	@Override
	public Audit create(Audit audit) {
		audit=auditService.auditTransaction(audit,prepareRequestDto().addCSLRequestContext(cslRequestContext));
		return audit;
	}
	
	private SsCSLUser prepareRequestDto(){
		SsCSLUser user = new SsCSLUser();
		user.setChannel(cslRequestContext.getChannel());
		user.setCountry(cslRequestContext.getCountry());
		user.setRelId(cslRequestContext.getRelId());
		user.setLanguage(cslRequestContext.getLanguage());
		user.setUaas2id(cslRequestContext.getUaas2id());
		return user;
	}
}
