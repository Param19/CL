package com.sc.rdc.csl.ss.common.dto.account;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonApiResource(type = "accounts")
public class AccountDto extends SsBaseDto implements Serializable {

    @JsonApiId
    private String uuid = UUID.randomUUID().toString();
    //private String accountNumber;

    private BigDecimal localCurrentBalance;
    private BigDecimal localAvailableBalance;

    private BigDecimal principal;
    private String term;
    private BigDecimal interestRate;
    private Date issueDate;
    private Date currentMaturityDate;
    private BigDecimal interestAtMaturity;

    private Date tradeDate;
    private Date valueDate;
    private String alternateCurrency;
    private BigDecimal conversionRate;
    private Date fixingDate;
    private BigDecimal fixingRate;
    private BigDecimal repaymentDepositCurrency;
    private BigDecimal repaymentAlternateCurrency;

    private String issueNumber;
    private String issueDescription;
    private BigDecimal currentFaceAmount;
    private BigDecimal availableFaceAmount;
    private BigDecimal marketPrice;
    private BigDecimal currentMarketValue;
    private BigDecimal availableMarketValue;
    // Extra
    private BigDecimal principalPlusInterest;

    //for Account Details
    private String interestDisposalCode;
    private String principalDisposalCode;
    private String specialInstruction;
    private String termCode;
    private Date accountOpeningDate;

    private String odClass;

    //Added for CBIS Changes GetDepositTrancheDetails (FD Services)
    private String smcdFlag;
    private String trancheID;
    private String trancheDesc;
    private String couponPaymentFrequencey;
    private String fundsAccountNumber;
    private String maturityDate;
    private String branchName;

    private Date accountOpenDate;

    private String accountShortNameNonEnglish; // account name from host (in zh)


    private String fundsCurrencyCode;
    private String fundsProductCode;

    // payment
    private String accountTitle;


    // Properties from ProductEntity

    private Integer index;
    private String customerId;
    private String customerIdType;
    private String productCode;
    private String subProductCode;
    private String accountNumber;
    private String accountName;
    private String accountDescription;
    private String consolidatedCode;

    private String accountStatus;
    private String accountStatusDesc;
    private String blockCode;
    private String relationshipCode;

    private String currencyCode;
    private BigDecimal currentBalance;

    // CURRENT BALANCE IN STRING SINCE BIGDECIMAL CONVERTED TO EXPO VAL
    private String currentBalanceStr;

    private BigDecimal availableBalance;

    private Integer customOrder = SsConstant.DEFAULT_ORDER;
    private Integer productOrder = SsConstant.DEFAULT_ORDER;

    private Boolean isFullInfo;
    private Boolean isOnline;	// is from online or 24x7
    private Boolean isValidStatus;
    //private boolean isFullInfo;
    private Date hostUpdatedDate; // For online updated date
    //private boolean isOnline;	// is from online or 24x7

    //private boolean isValidStatus;
    //Code added for CBIS
    private String dealTypeCode;
    private String masterNo;
    private String branchCode;
    private String segmentCode;
    private Date lastUpdatedDate;

    private String kidFlag;
    private String ibFlag;
    private String riskCode;

    private String accountDesFilter;
    private String fromDate;

    //Added for AE
    private String iban;
    private String accountShortName;
    private Boolean islamic;
    private String masterNumber;
    private String primaryFlag;
    private String currOutstandingBal;

    @JsonApiRelation(lookUp = LookupIncludeBehavior.NONE, opposite = "account")
    private List<Transaction> transactions = new ArrayList<>();
}
