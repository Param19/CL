package com.sc.rdc.csl.ss.dal.in.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.in.entity.LoginAuditEntity;

import lombok.extern.slf4j.Slf4j;

@Repository(value ="loginAuditDaoIn")
@Slf4j

public class LoginAuditDao extends BaseDao{

	 @Autowired
	    @Qualifier("cslRequestContext")
	    CSLRequestContext requestContext;
	 
	
	 public void insertLoginAudit(LoginAuditEntity loginAuditEntity){
		 log.info("insertLoginAudit - START");
		
		 entityManagerIn.persist(loginAuditEntity);
		 
		 log.info("insertLoginAudit - END - SUCCESS");
		 
	 }
	
}
