package com.sc.rdc.csl.ss.dal.ae.entity;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class FundTransferEntity extends BaseDto {

	private static final long serialVersionUID = 1L;

    private Long id;
	private Long payeeId;
	private String requestId;
	private String fromcardnumber;
	private String transcurrency;
	private BigDecimal paymentamt;
	private String pref;
	private String utilcode;
	private String toAccountNumber;
	private String cardstatus;
	private String authcode;
	private BigDecimal availablelimit;
	private String toIBAN;
	private String toAccountType;
	private String toAccountName;
	private String toAccountDesc; // personalize setting
	private String toAccountStatus;
	private String toAccountrelCode;
	private String toAccountCurrencyCode;
	private BigDecimal toAccountcurrentBalance;
	private BigDecimal toAccountavailableBalance;
	private BigDecimal localCurrencyAmt;
	private String tranFrequency;
	private String editTransferTxnRefNum;
	private String iSCCSOF;
	private BigDecimal actualTransAmt;
	private BigDecimal remitanceAmount;
	private BigDecimal fundTransferLimit;
	private String purposeOfTransfer;
	private String chargesInd;
	private BigDecimal charges;
	private String chargesAccCurrencyCode;
	private String chargesAccNum;
	private BigDecimal chargesToDebit;
	private BigDecimal chargesToCredit;
	private char isCCY;
	private String txnReference1;
	
	private String txnReference2;
	
	private String txnReference3;
	
	private String txnReference4;
	
	private BigDecimal channelMargin;	//		Channel Margin
	
	private String bankBICCode;

	
	private String benficaryCode;
	
	private String standingOrderFuncCode;
	
	private String availCashLmt;
	
	private String bankChargesx;	
	
	private String bankChargesy;
	
	private String financeCharges;
	
	private String ccTransType;
	
	private String glToAccCntryCd;
	
	private String glToAccBranchName;
	
	private String glPayeeName;
	
	private String transDate;
	
	/** recurring start date **/
	private String recurrStartDate;

	/** Denotes the end date of a recurring payment */
	private String recurrEndDate;
	
	private String payeeBankName;
	//DFS Changes
	private String beneResidentCtryName;
	
	private String beneficiaryAddress;
	
	/** TransactionTypeCodeDesc */
	private String TransactionTypeCodeDesc;
    private String transactionRefNo;
    private String customerId;
    private String customerEBID;
    private String fromAccountType;
    private String fromAccountNumber;
}
