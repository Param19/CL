package com.sc.rdc.csl.ss.dal.pk.dao;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_PAYMENT_EXCEPTION;

import javax.persistence.TypedQuery;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.af.entity.QRPaymentEntity;
import com.sc.rdc.csl.ss.dal.af.entity.QrCodePayment;

@Repository(value = "paymentServiceDaoPk")
@Slf4j
public class PaymentServiceDao extends BaseDao {
	
	@Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;
	
	//public static String FIND_PAYMENT1 = "select q from com.sc.rdc.csl.ss.dal.af.entity.QrCodePayment q WHERE q.paymentid = :paymentId1";
	public static String FIND_PAYMENT1 = "select q from QrCodePayment q WHERE q.paymentid= :paymentId1";
	
    public QRPaymentEntity insertPayment(QRPaymentEntity paymentEntity) {
        log.debug("PaymentServiceDao:insertPayment,{}", paymentEntity);
        try {
        	paymentEntity.setPaymentId("2");
        	paymentEntity.setCountryCode("PK");
        	
            paymentEntity = entityManagerPk.merge(paymentEntity);
            return paymentEntity;
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }
    
    public QrCodePayment updatePayment(QrCodePayment paymentEntity) {
        log.info("PaymentServiceDao:updatePayment,{}", paymentEntity);
        try {
            paymentEntity = entityManagerPk.merge(paymentEntity);
            log.info("PaymentServiceDao:updatePayment completed ,{}", paymentEntity);
            return paymentEntity;
        } catch (Exception e) {
        	log.error(e.getMessage());
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }
    
    public QrCodePayment getPayment(String paymentId) {
        log.debug("PaymentServiceDao:getPayment,{}", paymentId);
        try {
            TypedQuery<QrCodePayment> query = entityManagerPk.createQuery(FIND_PAYMENT1, QrCodePayment.class);
            log.info("Before set param");
            query.setParameter("paymentId1", paymentId);
            log.info("Before qry exec");
            QrCodePayment paymentVo = query.getSingleResult();
            log.info("After qry exec");
            return paymentVo;
        } catch (Exception e) {
        	log.error("Error : " + e.getMessage() + e.getStackTrace());
            throw new TechnicalException(TemplateErrorCode.create(SS_PAYMENT_EXCEPTION, e.getMessage()));
        }
    }

}
