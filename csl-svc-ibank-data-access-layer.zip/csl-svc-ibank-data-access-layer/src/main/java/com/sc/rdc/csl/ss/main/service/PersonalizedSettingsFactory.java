
package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.IPersinalizedSettingsService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component()
@Slf4j
public class PersonalizedSettingsFactory {
    
    @Qualifier("personalizedSettingsServiceHk")
    @Autowired
    private IPersinalizedSettingsService iPersinalizedSettingsServiceHk;
    
    public IPersinalizedSettingsService getPersinalizedSettingsService(String country)
    {
        switch (StringUtils.upperCase(country)) {
            case Constants.HK: 
                return iPersinalizedSettingsServiceHk;
            default: 
                log.error("############ Country not supported ###########");
                return null;
        }
    }
    
}
