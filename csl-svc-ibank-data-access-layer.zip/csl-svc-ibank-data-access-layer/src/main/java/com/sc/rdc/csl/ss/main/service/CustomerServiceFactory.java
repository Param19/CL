package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.ICustomerService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component()
@Slf4j
public class CustomerServiceFactory {

    @Autowired
    @Qualifier("customerServiceCn")
    private ICustomerService customerServiceCn;
   
    @Autowired
    @Qualifier("customerServiceVN")
    private ICustomerService customerServiceVN;
    
    @Autowired
    @Qualifier("customerServiceMY")
    private ICustomerService customerServiceMY;

    @Autowired
    @Qualifier("customerServiceSg")
    private ICustomerService customerServiceSg;
    
    @Autowired
    @Qualifier("customerServiceHK")
    private ICustomerService customerServiceHK;
    
    @Autowired
    @Qualifier("customerServiceIn")
    private ICustomerService customerServiceIn;

    @Autowired
    @Qualifier("customerServiceAf")
    private ICustomerService customerServiceAf;

    @Autowired
    @Qualifier("customerServiceAe")
    private ICustomerService customerServiceAe;


    Map<String, ICustomerService> map = new HashMap<>();

    public ICustomerService getCustomerService(String country) {

            switch (StringUtils.upperCase(country)) {
                case Constants.HK:
                    return customerServiceHK;
                case Constants.CN:
                    return customerServiceCn;
                case Constants.SG:
                    return customerServiceSg;
                case Constants.IN:
                    return customerServiceIn;
                case Constants.VN:
                    return customerServiceVN;
                case Constants.MY:
                    return customerServiceMY;
                case Constants.AF:
                    return customerServiceAf;
                case Constants.CI:
                    return customerServiceAf;
                case Constants.AE:
                    return customerServiceAe;
            	case Constants.NG:
        			return customerServiceAf;
        		case Constants.KE:
        			return customerServiceAf;
        		case Constants.GH:
        			return customerServiceAf;
        		case Constants.BW:
        			return customerServiceAf;
        		case Constants.ZM:
        			return customerServiceAf;
                default:
                    log.error("############ Country not supported ###########");
                    return null;
        
        

    }
    }
}
