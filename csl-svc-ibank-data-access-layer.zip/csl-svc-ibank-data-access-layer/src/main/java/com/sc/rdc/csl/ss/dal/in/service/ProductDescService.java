package com.sc.rdc.csl.ss.dal.in.service;


import com.sc.rdc.csl.ss.common.dto.account.ProductDescriptionDto;
import com.sc.rdc.csl.ss.common.service.ProductDescriptionService;
import com.sc.rdc.csl.ss.dal.in.dao.ProductDescServiceDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Slf4j
@Service(value = "productDescServiceIN")
public class ProductDescService extends ProductDescriptionService {

    @Qualifier("productDescServiceDaoIn")
    @Autowired
    private ProductDescServiceDao productDescServiceDao;



    public ProductDescriptionDto getproductDescription(ProductDescriptionDto productDescriptionDto) {
        productDescriptionDto =  productDescServiceDao.getproductDescription(productDescriptionDto);

       return productDescriptionDto;
    }
    
    public String getproductDescription(String productCode, String subProductCode, String language) {
    	return productDescServiceDao.getproductDescription(productCode, subProductCode, language);
    }
}
