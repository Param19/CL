package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.ILoanService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component()
@Slf4j
public class LoanServiceFactory {
    
    @Qualifier("loanServiceHk")
    @Autowired
    private ILoanService loanServiceHk;

    @Qualifier("loanServiceSg")
    @Autowired
    private ILoanService loanServiceSg;

    @Qualifier("loanServiceIn")
    @Autowired
    private ILoanService loanServiceIn;

    public ILoanService getLoanService(String country)
    {
        switch (StringUtils.upperCase(country)) {
            case Constants.HK:
                return loanServiceHk;
            case Constants.SG:
                return loanServiceSg;
            case Constants.IN:
                return loanServiceIn;
            default: 
                log.error("############ Country not supported ###########");
                return null;
        }
    }
}
