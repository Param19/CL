package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;

public abstract class MailService {

    public SsBaseDto submitMailData(MailServiceEntityDto mailServiceEntityDto, SsCSLUser user) {
        return null;
    }
}
