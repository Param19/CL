package com.sc.rdc.csl.ss.dal.hk.dao.card;

import com.sc.rdc.csl.ss.common.dto.card.CardFaceDto;
import com.sc.rdc.csl.ss.dal.hk.dao.BaseDao;
import com.sc.rdc.csl.ss.dal.hk.entity.card.AtmCardType;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CardFaceDetails;
import com.webmethods.jms.log.Log;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Repository(value = "dcImageFaceDaoHK")
@Slf4j
public class DcImageFaceDao extends BaseDao {
    public static String commaSplit = ",";
    public static String custSegPB = "PRBN";
    public static String custSegEX = "EXBN";
    public static String custSegEA = "GMMN";
    public static String custSegYes = "Y";
    public static String GET_ELG_TYPES = "select  A from com.sc.rdc.csl.ss.dal.hk.entity.card.AtmCardType A ";
    public static String GET_ELG_TYPES_ATMTYPE = "select  A from com.sc.rdc.csl.ss.dal.hk.entity.card.AtmCardType A where A.atmCardType = :atmCardType ";
    public static String GET_ELG_IMAGES = "select  A from com.sc.rdc.csl.ss.dal.hk.entity.card.CardFaceDetails A where A.atmCardType = :atmCardType and A.subCardType in :subCardType ";

    public List<CardFaceDto> getEligibleCardTypes(String custSegment, String ctry) {
        log.info("getEligibleCardTypes starts {} {}", custSegment, ctry);
        List<CardFaceDetails> cardFaceDetailsList = null;
        String subCardType = null;
        List<String> subCardTypesList = null;
        Boolean flag = false;
        CardFaceDto cardFaceDto = null;
        List<CardFaceDto> cardFaceDtos = null;
        List<AtmCardType> atmCardTypeList = null;
        Query queryImg = null;
        try {
            Query query = entityManagerHk.createQuery(GET_ELG_TYPES);
            atmCardTypeList = (List<AtmCardType>) query.getResultList();
            log.info("First query executed");
            if (CollectionUtils.isNotEmpty(atmCardTypeList)) {
                cardFaceDtos = new ArrayList<>();
                Log.info("Size atmCardTypeList {}", CollectionUtils.size(atmCardTypeList));
                for (AtmCardType atmCardTypeDB : atmCardTypeList) {
                    if (atmCardTypeDB != null) {
                        log.info("atmCardTypeDB {}", atmCardTypeDB);
                        if (StringUtils.isNotEmpty(atmCardTypeDB.getIsPriority()) &&
                                atmCardTypeDB.getIsPriority().equalsIgnoreCase(custSegYes)
                                && StringUtils.isNotEmpty(custSegment) && custSegment.trim().equalsIgnoreCase(custSegPB)) {
                            flag = true;
                        } else if (StringUtils.isNotEmpty(atmCardTypeDB.getIsPremimum()) &&
                                atmCardTypeDB.getIsPremimum().equalsIgnoreCase(custSegYes)
                                && StringUtils.isNotEmpty(custSegment) && custSegment.trim().equalsIgnoreCase(custSegEX)) {
                            flag = true;
                        } else if (StringUtils.isNotEmpty(atmCardTypeDB.getIsMass()) &&
                                atmCardTypeDB.getIsMass().equalsIgnoreCase(custSegYes)
                                && StringUtils.isNotEmpty(custSegment) && custSegment.trim().equalsIgnoreCase(custSegEA)) {
                            flag = true;
                        }
                        log.info("flag {}", flag);
                        if (flag && StringUtils.isNotEmpty(atmCardTypeDB.getSubCardType())) {
                            subCardType = atmCardTypeDB.getSubCardType();
                            subCardTypesList = Arrays.asList(subCardType.split(commaSplit));
                            queryImg = entityManagerHk.createQuery(GET_ELG_IMAGES);
                            queryImg.setParameter("atmCardType", atmCardTypeDB.getAtmCardType());
                            queryImg.setParameter("subCardType", subCardTypesList);
                            cardFaceDetailsList = (List<CardFaceDetails>) queryImg.getResultList();
                            log.info("second query executed {} {}", atmCardTypeDB.getAtmCardType(), subCardType);
                            log.info("SizeDetailList {}", CollectionUtils.size(cardFaceDetailsList));
                            for (CardFaceDetails cardFaceDetails : cardFaceDetailsList) {
                                cardFaceDto = new CardFaceDto();
                                cardFaceDto.setCustSeg(custSegment);
                                cardFaceDto.setCountryCode(ctry);
                                cardFaceDto.setAtmCardType(String.valueOf(atmCardTypeDB.getAtmCardType()));
                                log.info("Sub Type", cardFaceDetails.getSubCardType());
                                cardFaceDto.setSubType(cardFaceDetails.getSubCardType());
                                cardFaceDto.setImageContent(cardFaceDetails.getCardFaceContent());
                                cardFaceDto.setLabelChn(cardFaceDetails.getLabelChin());
                                cardFaceDto.setLabelEng(cardFaceDetails.getLabelEng());
                                cardFaceDto.setLabelHk(cardFaceDetails.getLabelHng());
                                cardFaceDtos.add(cardFaceDto);
                            }

                        }
                        flag = false;
                    }
                }
            }

        } catch (Exception e) {
            log.error("getEligibleCardTypes Exception {}", e);
        }
        return cardFaceDtos;
    }
}
