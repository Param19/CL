package com.sc.rdc.csl.ss.dal.af.config;

import lombok.Getter;
import lombok.Setter;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class SsDozerConfigAf {

    @Bean("dozerMappingFilesAf")
    public DozerMappingFilesAf dozerMappingFiles() {
        return new DozerMappingFilesAf();
    }

    @Bean("dozerBeanMapperAf")
    public DozerBeanMapper dozerBeanMapper(DozerMappingFilesAf dozerMappingFiles) {
        dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/af/dozer/customer-profile-mappings.xml");
        return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
    }

    @Setter
    @Getter
    private class DozerMappingFilesAf {
        private List<String> mappingFiles = new ArrayList<>();
    }

}

