package com.sc.rdc.csl.ss.dal.hk.service;

import java.lang.reflect.InvocationTargetException;

import javax.transaction.Transactional;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ITransactionPasswordService;
import com.sc.rdc.csl.ss.dal.hk.dao.TransactionPasswordDao;
import com.sc.rdc.csl.ss.dal.hk.dto.TransactionPasswordDto;
import com.sc.rdc.csl.ss.dal.hk.entity.TransactionPasswordEntity;

@Slf4j
@Service("transactionPasswordServiceHK")
public class TransactionPasswordService extends ITransactionPasswordService {

	@Autowired
	@Qualifier("transactionPasswordDaoServiceHk")
	private TransactionPasswordDao transactionPasswordDao;

	@Autowired
	@Qualifier("cslRequestContext")
	CSLRequestContext requestContext;

	@Autowired
	private MapperFacade orikaMapperFacade;

	public TransactionPasswordDto getTransactionPassword(String ebid) {
		TransactionPasswordEntity transactionPasswordEntity = transactionPasswordDao.getTransactionPassword(ebid);
		log.info("Orika mapper result :", transactionPasswordEntity);
		return orikaMapperFacade.map(transactionPasswordEntity, TransactionPasswordDto.class);
	}

	@Transactional
	public void save(TransactionPasswordDto transactionPasswordDto) {
		TransactionPasswordEntity requestTransactionPasswordEntity = orikaMapperFacade.map(transactionPasswordDto,
				TransactionPasswordEntity.class);
		TransactionPasswordEntity savedTransactionPasswordEntity = transactionPasswordDao
				.getTransactionPassword(requestContext.getUaas2id());
		try {
			NullAwareBeanUtilsBean nabu = new NullAwareBeanUtilsBean();
			nabu.copyProperties(savedTransactionPasswordEntity, requestTransactionPasswordEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			new BusinessException(ErrorConstant.TRANSACTION_PASSWORD_SAVE_FAILED);
		}
		transactionPasswordDao.save(savedTransactionPasswordEntity);
	}
	
	public class NullAwareBeanUtilsBean extends BeanUtilsBean {
		@Override
		public void copyProperty(Object dest, String name, Object value) throws IllegalAccessException,
				InvocationTargetException {
			if (value == null) {
				return;
			}
			super.copyProperty(dest, name, value);
		}
	} 
}
