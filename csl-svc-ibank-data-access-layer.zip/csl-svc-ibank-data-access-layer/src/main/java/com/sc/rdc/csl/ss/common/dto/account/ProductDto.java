package com.sc.rdc.csl.ss.common.dto.account;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProductDto extends BaseDto {

	private static final long serialVersionUID = -61659510606665628L;

	private String accountDescription;
	private String accountName;
	private String accountNumber;
	private BigDecimal availableBalance;
	private String currencyCode;
	private BigDecimal currentBalance;
	private String kidFlag;
	private BigDecimal localAvailableBalance;
	private BigDecimal localCurrentBalance;
	private String operInstruction;
	private Boolean onlineFlag;
	private String productCode;
	private String productDescription;
	private String productGroup;
	private Long resourceId;
	private String resourcePath;
	private String subProductCode;
	private String islamic;
	private String dealFlag;
	private String ctryCode;
	private String consolidatedCode;

	public String getCtryCode() {
		return ctryCode;
	}

	public void setCtryCode(String ctryCode) {
		this.ctryCode = ctryCode;
	}

	public String getDealFlag() {
		return dealFlag;
	}

	public void setDealFlag(String dealFlag) {
		this.dealFlag = dealFlag;
	}

	public String getIslamic() {
		return islamic;
	}

	public void setIslamic(String islamic) {
		this.islamic = islamic;
	}

	public String getAccountDescription() {
		return accountDescription;
	}

	public void setAccountDescription(String accountDescription) {
		this.accountDescription = accountDescription;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(BigDecimal availableBalance) {
		this.availableBalance = availableBalance;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getKidFlag() {
		return kidFlag;
	}

	public void setKidFlag(String kidFlag) {
		this.kidFlag = kidFlag;
	}

	public BigDecimal getLocalAvailableBalance() {
		return localAvailableBalance;
	}

	public void setLocalAvailableBalance(BigDecimal localAvailableBalance) {
		this.localAvailableBalance = localAvailableBalance;
	}

	public BigDecimal getLocalCurrentBalance() {
		return localCurrentBalance;
	}

	public void setLocalCurrentBalance(BigDecimal localCurrentBalance) {
		this.localCurrentBalance = localCurrentBalance;
	}

	public String getOperInstruction() {
		return operInstruction;
	}

	public void setOperInstruction(String operInstruction) {
		this.operInstruction = operInstruction;
	}

	public Boolean getOnlineFlag() {
		return onlineFlag;
	}

	public void setOnlineFlag(Boolean onlineFlag) {
		this.onlineFlag = onlineFlag;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductGroup() {
		return productGroup;
	}

	public void setProductGroup(String productGroup) {
		this.productGroup = productGroup;
	}

	public Long getResourceId() {
		return resourceId;
	}

	public void setResourceId(Long resourceId) {
		this.resourceId = resourceId;
	}

	public String getResourcePath() {
		return resourcePath;
	}

	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}

	public String getSubProductCode() {
		return subProductCode;
	}

	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}
	public String getConsolidatedCode() {
		return consolidatedCode;
	}

	public void setConsolidatedCode(String consolidatedCode) {
		this.consolidatedCode = consolidatedCode;
	}
}