package com.sc.rdc.csl.ss.dal.cn.entity;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.usertype.UserType;

import javax.sql.rowset.serial.SerialClob;
import java.io.Serializable;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StringClobType implements UserType
{
  public int[] sqlTypes()
  {
    return new int[] { 2005 };
  }

  public Class returnedClass()
  {
    return String.class;
  }

  public boolean equals(Object x, Object y)
  {
    return (x == y) || ((x != null) && (y != null) && (x.equals(y)));
  }

  public Object nullSafeGet(ResultSet rs, String[] names,SessionImplementor session, Object owner) throws HibernateException, SQLException
  {
    Clob clob = rs.getClob(names[0]);
    return clob.getSubString(1L, (int)clob.length());
  }

  public void nullSafeSet(PreparedStatement st, Object value, int index, SessionImplementor session) throws HibernateException, SQLException
  {
    String s = (String)value;
   st.setClob(index, new SerialClob(s.toCharArray()));
  }

  public Object deepCopy(Object value)
  {
    return value == null ? null : String.valueOf(value);
  }

  public boolean isMutable()
  {
    return false;
  }

  public Object assemble(Serializable cached, Object owner)
    throws HibernateException
  {
    return cached;
  }

  public Serializable disassemble(Object value)
    throws HibernateException
  {
    return (Serializable)value;
  }

  public int hashCode(Object x)
    throws HibernateException
  {
    return x.hashCode();
  }

  public Object replace(Object original, Object target, Object owner)
    throws HibernateException
  {
    return original;
  }
}