package com.sc.rdc.csl.ss.dal.af.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class BaseVO implements Serializable, Cloneable {

    private static final long serialVersionUID = 1L;

    private String uuid;

    private Long id;

    private Date createdDate;

    private String createdBy;

    private Date updatedDate;

    private String updatedBy;

    private Long version;

}
