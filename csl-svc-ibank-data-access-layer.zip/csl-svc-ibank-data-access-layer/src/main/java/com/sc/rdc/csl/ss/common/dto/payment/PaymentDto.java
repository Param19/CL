package com.sc.rdc.csl.ss.common.dto.payment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

/**
 * Created by 1546088 on 4/8/17.
 */
@Getter
@Setter
@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonApiResource(type = "payments")
public class PaymentDto extends SsBaseDto {

    private static final long serialVersionUID = 1L;

    @JsonApiId
    private String uuid = UUID.randomUUID().toString();

    private Long id;
    private String transactionId;
    private Long notificationId;
    private String fromAccountNumber;
    private String toAccountNumber;
    private String currencyCode;
    private BigDecimal amount;
    private String message;
    private String reference;
    private Date transferDate;
    private Date processedTimestamp;
    private String destinationAccountName;
    private String transactionStatus;
    private String transactionType;
    private String recurInterval;
    private Date recurEndDate;
    private String bankCode;
    private String bankName;
    private String sourceAccountName;
    private String customerId;
    private String customerIdType;
    private String customerEBID;
    private String transactionStatusCode;
    private String authorizationCode;
    private String macValue;
    private String paymentMode;
    private String repaymentType;
    private String merchantId;
    private String merchantCategory;
    private String merchantCode;
    private Long payeeId;
    private Date settlementDate;
    private String billType;
    private String sourceAccountRelCode;
    private String sourceCurrencyCode;
    private String rdsLogNumber;
    private BigDecimal conversionRate;
    private BigDecimal sourceAmount;
    private String transactionCurrencyCode;
    private String isCrossCurrency;
    private String remitanceAmount;
    // extra fields
    //private TransferFXRateVO transferFXRateVO;
    //private ProductVO fromAccountVO;
    //private ProductVO toAccountVO;
    //private PayeeVO payeeVO;

    private String branchCode;
    private String branchName;
    private String hostReasonCode;

    // sourceAmount might be in foreign currency (this is for RAE OTPL limit checking)
    private BigDecimal localCurrencyAmount;

    //private TransactionStatusVO transactionStatusVO;
    private String ackMessageCode;
    private String ackErrorCode;        // business error code

    // Bill Payment
    //private MerchantVO merchantVO;
    //private BillerVO billerVO;

    private String bvTransactionId;
    private String secondBillAccountNumber;
    private Date billDate;
    private String policyNo;
    private String textBoxOne;
    private String textBoxTwo;
    private String textBoxThree;
    private String textBoxFour;
    private String textBoxFive;
    private String textBoxSix;
    private String textBoxSeven;
    private String mobilePhoneNumber;

    private String currentTime;
    private String billPayeeCityCode;

    private Long billerId;
    private String payInfoOrganization;
    private String payInfoBarcode;
    private String delimitedBarCode;
    private String ibankingMsgId;
    private String ibankingSSN;
    private String billerCity;
    private String billerType;
    private String blType;
    private String billerName;

    //additional columns
    private String fromAccountCode;
    private String toAccountCode;
    private Boolean isTransferDateHoliday;
    private String ccPaymentInd;

    //multiple bill payments
    //private List<SelectItem> fromAccountSelectItems;
    private Integer fromAccountSelectedIndex;
    //private boolean isRecurring;
    //private List<ProductVO> fromAccounts;
    //private List<BillTypeVO> billTypes;

    //EPSCO after validation/mapping bill acc and bill type
    private String epscoBillAccount;
    private String epscoBillType;

    private String highRiskInd;

    // IBFT Via Opal
    private String priority;
    private String brnCode;
    private String remitterSubBranchName;
    private String opalsessionKey;
    private String opalStatusCode;
    private String opalServerStatusCode;
    private String opalStatusDesc;
    private String opalPmtMethod;
    private Date opalEffDt;
    private String opalBORefId;
    private BigDecimal transferFee;
    private String paymentRefId;
    private String paymentStatus;
    private String paymentId;
    // Payment Gateway
    private String cupTraceNum;
    private String merchantName;
    private Date dateTimeCUP;
    private String acquirerBin;
    private String initTraceBin;
    private String merchantOrderNo;
    private String cardNum;
    private String reconDesc;
    private String reversalFlagStatus;
    private String sysTrxType;

    // International/Telegraphic transfer
    //private InternationalFundTransferVO internationalFundTransferVO;

    // Channel Code
    private String channelCode;
    private String countryCode;
    private boolean update;
    private ScheduledTransactionsSafeDto ssSafePaymentDto;

    //Added for AE
    private String fromIBAN;
    private String toIBAN;
    private String bankBicCode;
    private String fromAccountType;
    private String toAccountType;
    private String toAccountCurrencyCode;
    private String txnReference1;
    private String txnReference2;
    private String txnReference3;
    private String txnReference4;
    private String transactionMode;
    private String transTypeCD;
	private SSGlobalLinkTransferDetailsDto ssGLFTDetailsDto;
}
