package com.sc.rdc.csl.ss.common.helper;


public class MailConstant {

    public static final String serviceName = "mailBoxService";
    public static final String CONTACT_MAIL_STATUS_UNREAD = "N";
    public static final String CONTACT_MAIL_ADDRESS_TYPE_CARDS = "C";
    public static final String CONTACT_MAIL_ADDRESS_TYPE_STANDARD_CHARTERED_BANK = "STANDARD_CHARTERED_BANK";
    public static final String STATUS = "Success";
    public static final int SUCCESSFULLY_INSERTED = 0;
    public static final Integer STATUS_CODE = 200;
    public static final String PAD_EMPTY = " ";
    public static final String CONTACT_MAIL_ADDRESS_TYPE_GENERAL = "G";
    public static final String CONTACT_MAIL_ADDRESS_TYPE_ACCOUNTS = "A";

    public static final String EBID_ERROR = "failure";
    public static final Integer EBID_ERROR_CODE = 422 ;

}
