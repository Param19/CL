package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.IPaymentService;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.ss.common.dto.SsConstant.PAYMENT;
import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.COUNTRY_NOT_ALLOWED;

@Component()
@Slf4j
public class PaymentServiceFactory {

    @Autowired @Qualifier("paymentServiceCn")
    private IPaymentService paymentServiceCn;

    @Autowired @Qualifier("paymentServiceAe")
    private IPaymentService paymentServiceAe;
    
    @Autowired @Qualifier("paymentServiceAf")
    private IPaymentService paymentServiceAf;
    
    @Autowired @Qualifier("paymentServicePk")
    private IPaymentService paymentServicePk;

    Map<String, IPaymentService> map = new HashMap<>();

    public IPaymentService getPaymentService(String country)
    {
    	log.info("Started Payment service facctory......");
    	if(map.size()==0)
            initMap();
        IPaymentService paymentService = map.get(StringUtils.upperCase(country));
        if(paymentService != null)
            return paymentService;
        log.error("Country {} is not allowed to call Payment Service", country);
        throw new BusinessException(TemplateErrorCode.create(COUNTRY_NOT_ALLOWED,country,PAYMENT));
    }

    private void initMap() {
        map.put(Constants.CN, paymentServiceCn);
        map.put(Constants.AE, paymentServiceAe);
        map.put(Constants.KE, paymentServiceAf);
        map.put(Constants.ZM, paymentServiceAf);
        map.put(Constants.ZW, paymentServiceAf);
        map.put(Constants.GH, paymentServiceAf);
        map.put(Constants.NG, paymentServiceAf);
        map.put(Constants.BW, paymentServiceAf);
        map.put(Constants.CI, paymentServiceAf);
        map.put(Constants.UG, paymentServiceAf);
        map.put(Constants.TZ, paymentServiceAf);
        map.put(Constants.PK, paymentServicePk);
    }
}
