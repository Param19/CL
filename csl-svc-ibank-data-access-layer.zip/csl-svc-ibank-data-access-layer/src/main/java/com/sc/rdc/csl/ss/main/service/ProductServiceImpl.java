package com.sc.rdc.csl.ss.main.service;


import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.account.AccountSummary;
import com.sc.rdc.csl.ss.common.dto.account.BndAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.BndAccountSummary;
import com.sc.rdc.csl.ss.common.dto.account.CasaAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.CasaAccountSummary;
import com.sc.rdc.csl.ss.common.dto.account.WealthAccountDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.main.helper.ErrorCodeUtil;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productServiceImpl")
@Slf4j
public class ProductServiceImpl  {

    @Autowired
    ProductServiceFactory productServiceFactory;
    
    @Autowired
    private ErrorCodeUtil  errorCodeUtil;
            
    public SsBaseDto getIdaAccountSummary(SsCSLUser user)  {
        CasaAccountSummary accountSummary = null;
        List<CasaAccountDto> list = (List<CasaAccountDto>) productServiceFactory.getProductService(user.getCountry()).getIdaAccountSummary(user);
        if (list == null) {
            return errorCodeUtil.prepareResponseByCode(ErrorConstant.ACCOUNT_DETAILS_NOT_FOUND.name(), new SsBaseDto());
        }
        accountSummary = new CasaAccountSummary();
        accountSummary.setCode("0");
        accountSummary.setWealthAccountList(list);
        return accountSummary;
    }
    
    public SsBaseDto getBndAccountSummary(SsCSLUser user)  {
        BndAccountSummary accountSummary = null;
        List<BndAccountDto> list = (List<BndAccountDto>) productServiceFactory.getProductService(user.getCountry()).getBndAccountSummary(user);
        if (list == null) {
            return errorCodeUtil.prepareResponseByCode(ErrorConstant.ACCOUNT_DETAILS_NOT_FOUND.name(), new SsBaseDto());
        }
        accountSummary = new BndAccountSummary();
        accountSummary.setCode("0");
        accountSummary.setWealthAccountList(list);
        return accountSummary;
    }
   
    public SsBaseDto getInvAccountSummary(SsCSLUser user) {
        AccountSummary accountSummary = null;
        List<WealthAccountDto> list = (List<WealthAccountDto>) productServiceFactory.getProductService(user.getCountry()).getInvAccountSummary(user);
        if (list == null) {
            return errorCodeUtil.prepareResponseByCode(ErrorConstant.ACCOUNT_DETAILS_NOT_FOUND.name(), new SsBaseDto());
        }
        accountSummary = new AccountSummary();
        accountSummary.setCode("0");
        accountSummary.setWealthAccountList(list);
        return accountSummary;
    }

    
    
     
    

}
