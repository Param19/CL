package com.sc.rdc.csl.ss.dal.hk.service.card;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.card.CardDto;
import com.sc.rdc.csl.ss.common.dto.card.CreditCardTransactionDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICreditCardService;
import com.sc.rdc.csl.ss.dal.hk.dao.ProductServiceDao;
import com.sc.rdc.csl.ss.dal.hk.dao.card.CreditCardServiceDao;
import com.sc.rdc.csl.ss.dal.hk.dao.card.CreditCardTransactionDao;
import com.sc.rdc.csl.ss.dal.hk.entity.account.FilterProductEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CardTxnHistoryEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CreditCardEntity;
import com.sc.rdc.csl.ss.main.helper.CardUtil;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service("creditCardServiceHk")
public class CreditCardService extends ICreditCardService {

    @Autowired
    @Qualifier("creditCardServiceDaoHk")
    private CreditCardServiceDao creditCardServiceDao;

    @Autowired
    @Qualifier("creditCardTxnServiceDaoHk")
    private CreditCardTransactionDao creditCardTxnServiceDao;

    @Autowired
    @Qualifier("productServiceDaoHk")
    private ProductServiceDao productServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<CardDto> getCreditCardSummary(SsCSLUser user) {
        List<CardDto> cardDtoList = new ArrayList<>();
        try {
            log.info("CreditCardSummary :" + user);
            Optional<List<CreditCardEntity>> creditCardEntityList = Optional.ofNullable(creditCardServiceDao.getCreditCardSummary(user));
            creditCardEntityList =  buildCreditCardList(creditCardEntityList);
            log.info("CreditCardSummary :" + creditCardEntityList);

            if(creditCardEntityList.isPresent()) {
                creditCardEntityList.get().forEach(CreditCardEntity -> {
                    cardDtoList.add(orikaMapperFacade.map(CreditCardEntity, CardDto.class));
                });
            }
            log.info("Orika mapper result :" + cardDtoList);
        } catch (BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching CreditCard Summary for user {} , {} ", user.getCustomerId(), e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_CREDITCARD);
        }
        return cardDtoList;
    }

    public List<CardDto> getProvidedCreditCardSummary(List<String> cardNumbers) {
        List<CardDto> cardDtoList = new ArrayList<>();
        try {
            log.info("CreditCardSummary :" + requestContext.getCustomerId());
            Optional<List<CreditCardEntity>> creditCardEntityList = Optional.ofNullable(creditCardServiceDao.getProvidedCreditCardSummary(requestContext.getCustomerId(),cardNumbers));
            creditCardEntityList =  buildCreditCardList(creditCardEntityList);
            log.info("CreditCardSummary :" + creditCardEntityList);

            if(creditCardEntityList.isPresent()) {
                creditCardEntityList.get().forEach(CreditCardEntity -> {
                    cardDtoList.add(orikaMapperFacade.map(CreditCardEntity, CardDto.class));
                });
            }
            log.info("Orika mapper result :" + cardDtoList);
        } catch (BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching CreditCard Summary for user {} , {} ", requestContext.getCustomerId(), e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_CREDITCARD);
        }
        return cardDtoList;
    }

    private Optional<List<CreditCardEntity>> buildCreditCardList(Optional<List<CreditCardEntity>> creditCardEntityList){

        List<String> creditCardCodeList = new ArrayList<>();
        creditCardEntityList.get().forEach(creditCardEntity -> {
            if(StringUtils.isNotEmpty(creditCardEntity.getSubProd())){
                creditCardCodeList.add("CCA"+ "-" + creditCardEntity.getSubProd());
            }
        });
        Set<String> uniqueCreditCardCodeList = new HashSet<>(creditCardCodeList);
        List<FilterProductEntity> filterProductEntityList = productServiceDao.getFilterProduct(uniqueCreditCardCodeList, requestContext.getLanguage());
        log.info("filterProductEntityList after setting the filterProductEntityList ::{}", filterProductEntityList);
        log.info("creditCardCodeList :{}",creditCardCodeList);
        if(creditCardEntityList!= null && filterProductEntityList != null){
            creditCardEntityList.get().forEach(creditCardEntity -> {
                for(FilterProductEntity entity: filterProductEntityList){
                    if(entity != null && StringUtils.isNotEmpty(entity.getSubProductCode())){
                        if(creditCardEntity.getSubProd().equalsIgnoreCase(entity.getSubProductCode())){
                            creditCardEntity.setAccountDescription(entity.getAccountTypeAlias());
                        }
                    }
                }
            });
        }

        log.info("creditCardEntityList after setting the card description ::{}", creditCardEntityList);
        return creditCardEntityList;
    }

    public CardDto getCreditCardDetails(String cardNo, SsCSLUser user, boolean includeTransactions) {
        CardDto cardDto = new CardDto();
        CreditCardEntity creditCardEntity = null;
        try {
            log.info("Credit Card Details :" + user);
            creditCardEntity = creditCardServiceDao.getCreditCardDetails(cardNo, user);
            buildCreditCard(creditCardEntity);
            orikaMapperFacade.map(creditCardEntity, cardDto);
            if (includeTransactions) {
                cardDto.setCardtransactions(getTransactionHistory(cardNo));
            }
        } catch (BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            throw new BusinessException(ErrorConstant.ERR_FETCHING_CREDITCARD);
        }
        return cardDto;
    }

    private CreditCardEntity buildCreditCard(CreditCardEntity creditCardEntity){
        Set<String> uniqueCreditCardCodeList = new HashSet<>();
        if(StringUtils.isNotEmpty(creditCardEntity.getSubProd())){
            uniqueCreditCardCodeList.add("CCA"+ "-" + creditCardEntity.getSubProd());
        }

        List<FilterProductEntity> filterProductEntityList = productServiceDao.getFilterProduct(uniqueCreditCardCodeList, requestContext.getLanguage());
        log.info("filterProductEntityList after setting the filterProductEntityList ::{}", filterProductEntityList);
        log.info("creditCardCode :{}",creditCardEntity);
        for(FilterProductEntity entity: filterProductEntityList){
            if(entity != null && StringUtils.isNotEmpty(entity.getSubProductCode())){
                if(creditCardEntity.getSubProd().equalsIgnoreCase(entity.getSubProductCode())){
                    creditCardEntity.setAccountDescription(entity.getAccountTypeAlias());
                }
            }
        }
        log.info("creditCardEntityList after setting the card description ::{}", creditCardEntity);
        return creditCardEntity;
    }


    public List<CreditCardTransactionDto> getTransactionHistory(String cardNo) {
        List<CreditCardTransactionDto> creditCardTransactionDtoList = new ArrayList<>();
        log.info("CardNo :: {} , startDate : {}  ",cardNo, CardUtil.getTransactionStartDate());
        List<CardTxnHistoryEntity> txnHistoryEntityList = creditCardTxnServiceDao.getCardTransactionHistory(CardUtil.getTransactionStartDate(),cardNo);
        if(txnHistoryEntityList.isEmpty()) {
            return creditCardTransactionDtoList;
        }

        txnHistoryEntityList.forEach(txnHistoryEntity -> {
            creditCardTransactionDtoList.add(orikaMapperFacade.map(txnHistoryEntity, CreditCardTransactionDto.class));
        });

        log.info("Credit Card Transaction :: {} ",creditCardTransactionDtoList);
        return creditCardTransactionDtoList;
    }


}
