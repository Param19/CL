package com.sc.rdc.csl.ss.dal.in.dao;

import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.sc.rdc.csl.ss.dal.in.entity.CustomerEntity;

import lombok.extern.slf4j.Slf4j;

@Repository(value = "custDetailDaoIN")
@Slf4j
public class CustDetailDao extends BaseDao {

    public static String GET_CUSTOMER_DETAIL = "select  o from com.sc.rdc.csl.ss.dal.in.entity.CustomerEntity o WHERE o.customerId = :customerId ";

   
    public CustomerEntity  getCustomerDetail(String customerId) {
        log.info("getCustomerDetail CustomerId: ", customerId);
        Query query = entityManagerIn.createQuery(GET_CUSTOMER_DETAIL);
        query.setParameter("customerId", customerId);
        List<CustomerEntity> customerdetails = query.getResultList();
        if(!customerdetails.isEmpty()) {
            return customerdetails.get(0);
        }
        return null;
    }
}
