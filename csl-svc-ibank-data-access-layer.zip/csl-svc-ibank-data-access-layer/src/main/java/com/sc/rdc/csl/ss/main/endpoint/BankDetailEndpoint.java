package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.bank.BankDetailsDto;
import com.sc.rdc.csl.ss.common.service.BankDetailService;
import com.webmethods.jms.log.Log;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class BankDetailEndpoint extends ResourceRepositoryBase<BankDetailsDto, String> {

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    @Qualifier("bankDetailServiceImpl")
    private BankDetailService bankDetailService;

    public BankDetailEndpoint() {
        super(BankDetailsDto.class);
    }

    @Override
    public BankDetailsDto findOne(String id, QuerySpec querySpec) {

        return null;
    }

    @Override
    public ResourceList<BankDetailsDto> findAll(QuerySpec querySpec) {
        BankDetailsDto bankDto = null;

        Log.debug("[findAll Entry]");
        bankDto = new BankDetailsDto();
        bankDto.setCountryCode(cslRequestContext.getCountry());
        bankDto.setLanguage(cslRequestContext.getLanguage());
        List<BankDetailsDto> bankList = bankDetailService.getBankDetails(bankDto);
        return querySpec.apply(bankList);

    }
}
