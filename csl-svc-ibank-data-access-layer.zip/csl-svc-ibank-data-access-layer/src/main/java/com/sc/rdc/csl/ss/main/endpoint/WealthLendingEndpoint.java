package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.service.IWealthLendingService;
import com.sc.rdc.csl.ss.common.dto.wld.ApplicationDto;
import io.swagger.annotations.Api;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Api("/wld")
@Slf4j
@Path("/wld")
@Component
public class WealthLendingEndpoint  {

    @Autowired
    @Qualifier("wealthLendingServiceImpl")
    private IWealthLendingService wealthLendingService;
    
    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext; 

    @GET
    @Path("customers")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto findWldCustomerDetails() {
         log.info("findWldCustomerDetails {}",cslRequestContext);
         return  wealthLendingService.findWldCustomerDetails(prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }


    @POST
    @Path("/forms")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto submitApplication(ApplicationDto applicationDto) {
        return wealthLendingService.submitApplication(applicationDto, prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }
    
    
    @PUT
    @Path("/forms")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto updateApplication(ApplicationDto applicationDto)  {
         return wealthLendingService.updateApplication(applicationDto, prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }

    @GET
    @Path("/forms/{id}")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto getApplication(@PathParam("id") String id)  {
         return wealthLendingService.getApplication(id, prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }
    
    @GET
    @Path("/forms")
    @Consumes("application/json")
    @Produces("application/json")
    public SsBaseDto getAllApplication(@QueryParam("applicationStatus") String applicationStatus)  {
         return wealthLendingService.getAllApplication(applicationStatus,prepareRequestDto().addCSLRequestContext(cslRequestContext));
    }
    
    private SsCSLUser prepareRequestDto(){
		SsCSLUser user = new SsCSLUser();
		user.setChannel(cslRequestContext.getChannel());
		user.setCountry(cslRequestContext.getCountry());
		user.setRelId(cslRequestContext.getRelId());
		user.setLanguage(cslRequestContext.getLanguage());
		user.setUaas2id(cslRequestContext.getUaas2id());
		return user;
    }

}
