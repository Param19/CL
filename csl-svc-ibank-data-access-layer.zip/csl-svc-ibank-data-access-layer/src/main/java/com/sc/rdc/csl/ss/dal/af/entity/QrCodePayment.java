package com.sc.rdc.csl.ss.dal.af.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;

import com.sc.rdc.csl.ss.common.dto.BaseDto;


/**
 * The persistent class for the QR_CODE_PAYMENT database table.
 * 
 */
@Entity
@Table(name="QR_CODE_PAYMENT" , schema = "SCBTXN")
@NamedQuery(name="QrCodePayment.findAll", query="SELECT q FROM QrCodePayment q")
public class QrCodePayment extends BaseDto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private String paymentid;

	@Column(name="CARD_NAME")
	private String cardName;

	@Column(name="CARD_NUMBER")
	private String cardNumber;

	@Column(name="CARD_TYPE")
	private String cardType;

	@Column(name="CNTRY_CODE")
	private String cntryCode;

	@Column(name="CUSTOMER_EBID")
	private String customerEbid;

	@Column(name="CUSTOMER_ID")
	private String customerId;

	@Column(name="CUSTOMER_TYPE")
	private String customerType;

	@Column(name="DEVICE_ID")
	private String deviceId;

	@Column(name="DEVICE_TYPE")
	private String deviceType;

	@Column(name="MERCHANT_CATEGORY")
	private String merchantCategory;

	@Column(name="MERCHANT_CITY")
	private String merchantCity;

	@Column(name="MERCHANT_ID_1")
	private String merchantId1;

	@Column(name="MERCHANT_ID_2")
	private String merchantId2;

	@Column(name="MERCHANT_ID_3")
	private String merchantId3;

	@Column(name="MERCHANT_ID_4")
	private String merchantId4;

	@Column(name="MERCHANT_NAME")
	private String merchantName;

	private String message;

	@Column(name="PAYMENT_REQ_ORIGINATED")
	private String paymentReqOriginated;

	@Column(name="PAYMENT_STATUS_DESC")
	private String paymentStatusDesc;

	private Timestamp paymentdate;

	private String paymentstatus;

	private String paymentstatuscode;

	private Timestamp processedtimestamp;

	@Column(name="RPE_REF_NUM")
	private String rpeRefNum;

	@Column(name="SCANNED_QR_CODE")
	private String scannedQrCode;

	@Column(name="SETTLEMENT_AMOUNT")
	private BigDecimal settlementAmount;

	@Column(name="SETTLEMENT_CURRENCY")
	private String settlementCurrency;

	@Column(name="SOURCE_AMOUNT")
	private BigDecimal sourceAmount;

	@Column(name="SOURCE_CURRENCY")
	private String sourceCurrency;

	@Column(name="SOURCE_OF_FUND")
	private String sourceOfFund;

	@Column(name="TXN_AMOUNT")
	private BigDecimal txnAmount;

	@Column(name="TXN_CURRENCY")
	private String txnCurrency;

	public QrCodePayment() {
	}

	public String getPaymentid() {
		return this.paymentid;
	}

	public void setPaymentid(String paymentid) {
		this.paymentid = paymentid;
	}

	public String getCardName() {
		return this.cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public String getCardNumber() {
		return this.cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getCardType() {
		return this.cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCntryCode() {
		return this.cntryCode;
	}

	public void setCntryCode(String cntryCode) {
		this.cntryCode = cntryCode;
	}

	public String getCustomerEbid() {
		return this.customerEbid;
	}

	public void setCustomerEbid(String customerEbid) {
		this.customerEbid = customerEbid;
	}

	public String getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerType() {
		return this.customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getDeviceId() {
		return this.deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getDeviceType() {
		return this.deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getMerchantCategory() {
		return this.merchantCategory;
	}

	public void setMerchantCategory(String merchantCategory) {
		this.merchantCategory = merchantCategory;
	}

	public String getMerchantCity() {
		return this.merchantCity;
	}

	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}

	public String getMerchantId1() {
		return this.merchantId1;
	}

	public void setMerchantId1(String merchantId1) {
		this.merchantId1 = merchantId1;
	}

	public String getMerchantId2() {
		return this.merchantId2;
	}

	public void setMerchantId2(String merchantId2) {
		this.merchantId2 = merchantId2;
	}

	public String getMerchantId3() {
		return this.merchantId3;
	}

	public void setMerchantId3(String merchantId3) {
		this.merchantId3 = merchantId3;
	}

	public String getMerchantId4() {
		return this.merchantId4;
	}

	public void setMerchantId4(String merchantId4) {
		this.merchantId4 = merchantId4;
	}

	public String getMerchantName() {
		return this.merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getPaymentReqOriginated() {
		return this.paymentReqOriginated;
	}

	public void setPaymentReqOriginated(String paymentReqOriginated) {
		this.paymentReqOriginated = paymentReqOriginated;
	}

	public String getPaymentStatusDesc() {
		return this.paymentStatusDesc;
	}

	public void setPaymentStatusDesc(String paymentStatusDesc) {
		this.paymentStatusDesc = paymentStatusDesc;
	}

	public Timestamp getPaymentdate() {
		return this.paymentdate;
	}

	public void setPaymentdate(Timestamp paymentdate) {
		this.paymentdate = paymentdate;
	}

	public String getPaymentstatus() {
		return this.paymentstatus;
	}

	public void setPaymentstatus(String paymentstatus) {
		this.paymentstatus = paymentstatus;
	}

	public String getPaymentstatuscode() {
		return this.paymentstatuscode;
	}

	public void setPaymentstatuscode(String paymentstatuscode) {
		this.paymentstatuscode = paymentstatuscode;
	}

	public Timestamp getProcessedtimestamp() {
		return this.processedtimestamp;
	}

	public void setProcessedtimestamp(Timestamp processedtimestamp) {
		this.processedtimestamp = processedtimestamp;
	}

	public String getRpeRefNum() {
		return this.rpeRefNum;
	}

	public void setRpeRefNum(String rpeRefNum) {
		this.rpeRefNum = rpeRefNum;
	}

	public String getScannedQrCode() {
		return this.scannedQrCode;
	}

	public void setScannedQrCode(String scannedQrCode) {
		this.scannedQrCode = scannedQrCode;
	}

	public BigDecimal getSettlementAmount() {
		return this.settlementAmount;
	}

	public void setSettlementAmount(BigDecimal settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public String getSettlementCurrency() {
		return this.settlementCurrency;
	}

	public void setSettlementCurrency(String settlementCurrency) {
		this.settlementCurrency = settlementCurrency;
	}

	public BigDecimal getSourceAmount() {
		return this.sourceAmount;
	}

	public void setSourceAmount(BigDecimal sourceAmount) {
		this.sourceAmount = sourceAmount;
	}

	public String getSourceCurrency() {
		return this.sourceCurrency;
	}

	public void setSourceCurrency(String sourceCurrency) {
		this.sourceCurrency = sourceCurrency;
	}

	public String getSourceOfFund() {
		return this.sourceOfFund;
	}

	public void setSourceOfFund(String sourceOfFund) {
		this.sourceOfFund = sourceOfFund;
	}

	public BigDecimal getTxnAmount() {
		return this.txnAmount;
	}

	public void setTxnAmount(BigDecimal txnAmount) {
		this.txnAmount = txnAmount;
	}

	public String getTxnCurrency() {
		return this.txnCurrency;
	}

	public void setTxnCurrency(String txnCurrency) {
		this.txnCurrency = txnCurrency;
	}

}