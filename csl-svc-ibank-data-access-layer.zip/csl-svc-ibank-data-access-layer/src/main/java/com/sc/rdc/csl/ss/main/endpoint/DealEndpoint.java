package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.account.DealInfo;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.main.helper.CommonEnricher;
import com.sc.rdc.csl.ss.main.service.DealServiceImpl;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Created by 1347884 on 11/29/2017.
 */
@Slf4j
@Component
public class DealEndpoint extends ResourceRepositoryBase<DealInfo, String>{

    @Autowired
    private DealServiceImpl dealService;

    protected DealEndpoint() {
        super(DealInfo.class);
    }

    @Override
    public ResourceList<DealInfo> findAll(QuerySpec querySpec) {
        log.debug("[DealRepository findAll Entry]");

        Map<String, Object> filterMap = CommonEnricher.populateQuerySpec(querySpec);
        if(filterMap.get("country")!=null) {
            String filterValue = (String) filterMap.get("country");
            log.debug("Filter value: {}", filterValue);
        }
        List<DealInfo> dealInfoList =  dealService.getDealInfo(querySpec);
        log.debug("[DealRepository findAll dealInfoList"+dealInfoList+"]");
        log.debug("[DealRepository findAll apply"+querySpec.apply(dealInfoList)+"]");
        return querySpec.apply(dealInfoList);
    }

    @Override
    public DealInfo findOne(String id, QuerySpec querySpec) {
        try {
            log.debug("[DealRepository findOne Entry]");
            throw new BusinessException(ErrorConstant.SERVICE_UNAVAILABLE);
        } finally {
            log.debug("[DealRepository findAll Exit]");
        }
    }

    @Override
    public DealInfo save(DealInfo dealInfo) {
        try {
            log.debug("[DealRepository save Entry]");
            throw new BusinessException(ErrorConstant.SERVICE_UNAVAILABLE);
        } finally {
            log.debug("[DealRepository save Exit]");
        }
    }

}
