package com.sc.rdc.csl.ss.dal.ae.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import com.sc.rdc.csl.ss.common.service.IPaymentService;
import com.sc.rdc.csl.ss.dal.ae.dao.PaymentServiceDao;
import com.sc.rdc.csl.ss.dal.ae.entity.payment.InternationalTransferEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Date;

import static com.sc.rdc.csl.ss.common.helper.Constants.*;
import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_PAYMENT_EXISTS;

@Slf4j
@Service(value = "paymentServiceAe")
public class PaymentService extends IPaymentService {

    @Autowired
    private MapperFacade orikaMapperFacade;
            
    @Qualifier("paymentServiceDaoAe")
    @Autowired
    private PaymentServiceDao paymentServiceDao;

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    @Transactional("transactionManagerAe")
    @Override
    public  PaymentDto submitPayment(PaymentDto paymentDto){
        String origTxnId = paymentDto.getTransactionId();
        paymentDto.setTransactionId(origTxnId);
        if(StringUtils.isNotBlank(paymentDto.getBranchCode()) && StringUtils.isNotBlank(paymentDto.getBranchName())) {
            paymentDto.setBranchCode(paymentDto.getBranchCode() + "-" + paymentDto.getBranchName());
            paymentDto.setBranchCode(StringUtils.substring(paymentDto.getBranchCode(),0,45));
        }
        log.info("Submit Payment for Transaction Id {}", paymentDto.getTransactionId());
        InternationalTransferEntity entity = orikaMapperFacade.map(paymentDto, InternationalTransferEntity.class);

        entity.setTransTypeCD(transactionType.get(paymentDto.getTransTypeCD()));
        entity.setTransactionMode(transactionModeMap.get(paymentDto.getTransactionMode()));
        entity.setTransStatusCD(transactionStatusMap.get(paymentDto.getTransactionStatusCode()));
        entity.setCreatedDate(new Date());
        entity.setCreatedBy(cslRequestContext.getUaas2id());
        entity.setUpdatedDate(new Date());
        entity.setUpdatedBy(cslRequestContext.getUaas2id());
        entity.setProcessingMode(1);
        entity.setVersion(1L);
        log.info("Submit Payment for Transaction Id {}, PaymentDto {}", paymentDto.getTransactionId(), entity);
        if(getPayment(paymentDto.getTransactionId())!=null)
            throw new BusinessException(SS_PAYMENT_EXISTS);
        entity = paymentServiceDao.insertPayment(entity);
        return getPaymentDto(entity, origTxnId);
    }

    private PaymentDto getPaymentDto(InternationalTransferEntity entity, String origTxnId) {
        PaymentDto responseDto = orikaMapperFacade.map(entity, PaymentDto.class);
        if(responseDto!=null)
            responseDto.setTransactionId(origTxnId);
        return responseDto;
    }

}
