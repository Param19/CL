package com.sc.rdc.csl.ss.dal.cn.entity;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Data
@Entity
@RequiredArgsConstructor
@Table(name = "VW_DAILY_TXN", schema = "CFE")
public class DailyTxnEntity {

    @Id
    @Column(name = "CUST_ID")
    private String custId;

    @Column(name = "TXN_TYPE")
    private String txnType;

    @Column(name = "CURR")
    private String curr;

    @Column(name = "TOT_AMT")
    private BigDecimal totAmt;

    @Column(name = "TXN_DATE")
    private Date txnDate;

    public DailyTxnEntity(String curr, BigDecimal totAmt) {
        this.curr = curr;
        this.totAmt = totAmt;
    }
}
