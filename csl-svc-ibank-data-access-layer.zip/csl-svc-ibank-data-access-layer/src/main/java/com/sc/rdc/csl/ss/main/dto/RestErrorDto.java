package com.sc.rdc.csl.ss.main.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RestErrorDto extends SsBaseDto implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Iterable<ErrorDto> errors;

    public RestErrorDto(Iterable<ErrorDto> errors) {
        this.errors = errors;
    }
    
    public RestErrorDto(Integer statusCode,Iterable<ErrorDto> errors) {
        super.statusCode = statusCode;
        this.errors = errors;
        
    }
    
    public RestErrorDto() {
        
    }

}
