package com.sc.rdc.csl.ss.dal.hk.entity.card;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author 1382158
 * @since 2017
 */
@Entity
@Data
@Table(name = "CM_CARD_FACE_DTL", schema = "CFE")
public class CardFaceDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "CARD_FACE_ID")
    private Long cardFaceId;
    @Column(name = "ATM_CARD_TYPE_ID")
    private Long atmCardType;
    @Column(name = "CARD_FACE_SEQ")
    private Integer cardFaceSeq;
    @Column(name = "SUB_CARD_TYPE")
    private String subCardType;
    @Column(name = "LABEL_EN")
    private String labelEng;
    @Column(name = "LABEL_CN")
    private String labelChin;
    @Column(name = "LABEL_HK")
    private String labelHng;
    @Column(name = "CARD_FACE_CONTENT")
    private byte[] cardFaceContent;
    @Column(name = "STATUS")
    private String status;
    @Column(name = "STATUS_DESC")
    private String statusDesc;
    @Column(name = "START_DATE")
    private Timestamp startDate;
    @Column(name = "END_DATE")
    private Timestamp endDate;
    @Column(name = "DT_CREATED")
    private Timestamp dtCreated;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "DT_UPD")
    private Timestamp dtUpdated;
    @Column(name = "UPD_BY")
    private String updatedBy;
    @Column(name = "DT_CHECKER")
    private Timestamp dateChecker;
    @Column(name = "CHECKER_ID")
    private String checkerId;
    @Column(name = "DT_MAKER")
    private Timestamp dateMaker;
    @Column(name = "MAKER_ID")
    private String makerId;
    @Column(name = "MAKER_COMMENTS")
    private String makerCmts;
    @Column(name = "CHECKER_COMMENTS")
    private String checkerCmts;
    @Column(name = "IS_DELETED")
    private Character isDel;
    @Column(name = "IS_ADDED")
    private Character isAdd;
    @Column(name = "TEMP_ID")
    private String tempId;


}
