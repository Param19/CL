package com.sc.rdc.csl.ss.dal.pk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.dto.customer.ReferenceDto;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;

import com.sc.rdc.csl.ss.dal.pk.dao.ReferenceDao;
import com.sc.rdc.csl.ss.dal.pk.entity.customer.CustomerDetailEntity;
import com.sc.rdc.csl.ss.dal.pk.entity.customer.ReferenceEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service(value = "custDetailServicePK")
public class CustDetailService extends CustomerDetailService {

    @Qualifier("custDetailDaoPk")
    @Autowired
    private com.sc.rdc.csl.ss.dal.pk.dao.CustDetailDao CustDetailDao;

    @Qualifier("referenceDetailsDaoPk")
    @Autowired
    private ReferenceDao referenceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Transactional(value = "transactionManagerPk", readOnly = true)
    @LogTimeTaken
    public CustomerDetailDto getCustomerDetail(CustomerDetailDto custDetailDto) {

        CustomerDetailEntity customerDetailEntity = CustDetailDao.getCustomerDetails(custDetailDto.getRellId());
        custDetailDto = orikaMapperFacade.map(customerDetailEntity,CustomerDetailDto.class);

        ReferenceEntity referenceEntity = referenceDao.getReferenceDetails("SEGMENT_CD", custDetailDto.getSegmentcode());
        ReferenceDto referenceDto = orikaMapperFacade.map(referenceEntity,ReferenceDto.class);
        custDetailDto.setCountry(cslRequestContext.getCountry());

        if(referenceDto!=null && StringUtils.isNotEmpty(referenceDto.getValue())
                && "SME".equalsIgnoreCase(referenceDto.getValue())){

            custDetailDto.setSmeFlag("true");

        } else {
            custDetailDto.setSmeFlag("false");
        }

        return custDetailDto;
    }
}