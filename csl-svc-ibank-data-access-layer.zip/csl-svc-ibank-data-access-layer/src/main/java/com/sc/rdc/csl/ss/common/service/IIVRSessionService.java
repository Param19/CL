
package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.customer.IVRInfo;

public abstract class IIVRSessionService {
    public IVRInfo getIVRInfo(String mobileNo, String country) {
        return null;
    }
}
