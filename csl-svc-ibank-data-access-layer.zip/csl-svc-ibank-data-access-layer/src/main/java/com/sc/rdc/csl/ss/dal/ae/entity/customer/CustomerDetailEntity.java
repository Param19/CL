package com.sc.rdc.csl.ss.dal.ae.entity.customer;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CustomerDetailEntity extends BaseDto {

   private static final long serialVersionUID = -1L;

   private Long      id;
   private String   customerId;
   private String   ebid;
   private String   customerIdType;
   private String   segmentCode;

   private String uuid;
   private String ctryCd;
   private String userId;
   private String userPswd;
   private String name;
   private String systemType;
   private String statusCd;
   private Date dtFirstLogin;
   private Date dtLastLogin;
   private int loginInvalidCount;
   private int loginSuccessCount;
   private String isLoggedIn;
   private String custGroupId;
   private String custName1;
   private String custName2;
   private String nickname;
   private String armCd;
   private String email;
   private String mobilePhone;
   private String notifType;
   private String address1;
   private String address2;
   private String address3;
   private String address4;
   private String district;
   private String state;
   private String placeBirth;
   private String custAccessKey;
   private Date dtServStart;
   private Date dtServEnd;
   private Date dtSuspendStart;
   private Date dtSuspendEnd;
   private String ftlBrowserId;
   private Date ftlTermsAcceptDate;
   private String isRereg;
   private String isLetterGen;
   private String isEmailGen;
   private String isAct;
   private Date dtAct;
   private String migrateFlag;
   private Date dtReg;
   private String regBy;
   private String regMode;
   private String actvType;
   private String pinMailerSerNo;
   private int pinMailerCounter;
   private Date dtPinMailerExp;
   private long reregCount;
   private String twoFaTypCd;
   private String remark;
   private Date dtCreated;
   private String createdBy;
   private Date dtUpd;
   private String updBy;
   private long version;

}
