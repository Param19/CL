package com.sc.rdc.csl.ss.dal.my.dao;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.dal.my.entity.customer.IVRInfoEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

/**
 * Created by 1347884 on 11/7/2017.
 */
@Repository(value ="ivrSessionServiceDaoMy")
@Slf4j
public class IVRSessionServiceDao extends BaseDao {

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    public static String GET_IVR_INFO = "select a from com.sc.rdc.csl.ss.dal.my.entity.customer.IVRInfoEntity a WHERE a.mobile = :mobile AND a.country = :country order by id desc";

    public IVRInfoEntity getIVRInfo(String mobileNo, String country) {
        log.info("IVRSessionServiceDao:getIVRInfo");

        Query query = entityManagerMY.createQuery(GET_IVR_INFO).setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        log.info("IVRSessionServiceDao: Query1: "+query);
        query.setParameter("mobile", mobileNo);
        query.setParameter("country", country);
        log.info("IVRSessionServiceDao: Query2: "+query);
        log.info("IVRSessionServiceDao: Query3: "+query.toString());
        List<IVRInfoEntity> ivrInfoEntityList = query.getResultList();
        IVRInfoEntity ivrInfoEntityRS = null;

        if((ivrInfoEntityList!=null) && (ivrInfoEntityList.size()>0)){
            ivrInfoEntityRS = ivrInfoEntityList.get(0);
        }

        log.info("Received IVRInfo from DB ", ivrInfoEntityRS);
        return ivrInfoEntityRS;
    }

}
