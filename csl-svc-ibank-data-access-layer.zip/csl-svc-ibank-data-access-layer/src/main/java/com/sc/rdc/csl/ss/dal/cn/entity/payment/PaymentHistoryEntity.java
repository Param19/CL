package com.sc.rdc.csl.ss.dal.cn.entity.payment;

import lombok.Data;

import java.math.BigDecimal;

/**
 * CFE.VW_PYMT_HIST = CFE.SCHEDULEDTRANSACTIONS LEFT JOIN CFE.PAYEE_TABLE
 * @author 1546088
 *
 */
@Data
public class PaymentHistoryEntity extends InternationalTransferPaymentEntity {
	private static final long serialVersionUID = 1L;

	private String drAccount;		// bill account number (equivalent to PayeeVO.drAccount)

	private boolean isToBeEdited;
	private boolean isToBeApproved;
	private boolean isToBeCopied;

	private int index;
	private String payeeName;
	private String payeeStatus;
	private String language;
	
	// for sorting purposes in payment history (until a better solution) 
	private BigDecimal displayAmount;
	private String displayCurrencyCode;
	private String displayFromAccount;
	private String displayToAccount;
}