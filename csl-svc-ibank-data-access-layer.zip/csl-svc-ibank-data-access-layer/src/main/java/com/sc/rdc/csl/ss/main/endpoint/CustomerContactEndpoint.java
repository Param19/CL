package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerContact;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CustomerContactEndpoint extends ResourceRepositoryBase<CustomerContact, String> {

    public CustomerContactEndpoint() {

        super(CustomerContact.class);
    }

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    @Qualifier("customerDetailServiceImpl")
    private CustomerDetailService customerDetailService;

    @Override
    public ResourceList<CustomerContact> findAll(QuerySpec querySpec) {
        log.info("CustomerContactEndpoint findAll()");
        ResourceList<CustomerContact> customerContacts = new DefaultResourceList<>();
        CustomerContact customerContact = customerDetailService.getCustomerContact(cslRequestContext.getCountry(),cslRequestContext.getCustomerId());
        if(customerContact!=null) {
            customerContacts.add(customerContact);
        }
        return customerContacts;
    }
}
