package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.customer.AccountPersonalized;
import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsV3Summary;
import com.sc.rdc.csl.ss.common.service.PersonalizedSettingV3Service;
import com.sc.rdc.csl.ss.dal.hk.dao.PersonalizedSettingsV3Dao;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.PersonalizedSettingsEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service(value = "personalizedSettingV3ServiceHK")
public class PersonalizedV3Service extends PersonalizedSettingV3Service {

    @Qualifier("personalizedSettingsV3DaoHk")
    @Autowired
    private PersonalizedSettingsV3Dao personalizedSettingsV3DaoHk;

    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public PersonalizedSettingsV3Summary getPersonalizedAccountSummary(PersonalizedSettingsV3Summary personalizedSettingsV3Summary)
    {
        PersonalizedSettingsV3Summary personalizedSettingsV3SummaryVO = null;
        List<AccountPersonalized> accountPersonalizedSummary = new ArrayList<AccountPersonalized>();
        AccountPersonalized accountPersonalized = null;
        List<PersonalizedSettingsEntity> personalizedList = personalizedSettingsV3DaoHk.getPersonalizedAccountSummary(personalizedSettingsV3Summary.getUaas2id(), personalizedSettingsV3Summary.getLanguage());
        for(PersonalizedSettingsEntity personalizedData:personalizedList)
        {
            accountPersonalized = new AccountPersonalized();
            accountPersonalized.setAccountNickName(personalizedData.getName());
            accountPersonalized.setPrdCode(personalizedData.getProCode());
            accountPersonalized.setAccountNumber(personalizedData.getAccountNumber());
            accountPersonalized.setCountryCode(personalizedData.getCountryCode());
            accountPersonalizedSummary.add(accountPersonalized);


        }
        personalizedSettingsV3SummaryVO = new PersonalizedSettingsV3Summary();
        personalizedSettingsV3SummaryVO.setAccountPersonalizedSummary(accountPersonalizedSummary);
        return personalizedSettingsV3SummaryVO;
    }
}
