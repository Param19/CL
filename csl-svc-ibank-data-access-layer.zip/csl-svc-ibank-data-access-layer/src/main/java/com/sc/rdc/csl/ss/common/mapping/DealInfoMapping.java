package com.sc.rdc.csl.ss.common.mapping;

import com.sc.rdc.csl.ss.common.dto.account.DealInfo;
import com.sc.rdc.csl.ss.dal.cn.entity.account.DealInfoEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;

/**
 * Created by 1347884 on 11/29/2017.
 */
public class DealInfoMapping implements OrikaMapperFactoryConfigurer{
    @Override
    public void configure(MapperFactory orikaMapperFactory) {

        orikaMapperFactory
                .classMap(DealInfo.class, DealInfoEntity.class)
                .field("id","id")
                .field("depositType","depositType")
                .field("currencyCode", "currencyCode")
                .field("dealType", "dealType")
                .field("tenureUnit", "tenureUnit")
                .field("depositTenureValue", "depositTenureValue")
                .field("interestProduct", "interestProduct")
                .field("interestCode", "interestCode")
                .field("statusCD", "statusCD")
                .mapNulls(false).byDefault().register();
    }
}
