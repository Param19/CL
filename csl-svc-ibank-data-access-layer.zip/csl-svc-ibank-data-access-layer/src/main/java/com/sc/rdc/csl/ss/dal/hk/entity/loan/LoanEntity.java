package com.sc.rdc.csl.ss.dal.hk.entity.loan;

import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountConstant;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class LoanEntity implements Serializable {
    private static final long serialVersionUID = -1L;
    private String customerNumber;      //CUSTOMERNUMBER
    private String borrowerName;        //BORROWERNAME
	private String loanProductCode;     //LOANPRODUCTCODE
	private BigDecimal applicationAmount;   //APPLICATIONAMOUNT
    private BigDecimal installmentAmount;   //INSTALLMENT
    private BigDecimal dueAmount;           //TOTALAMTDUE
    private BigDecimal interestRate;        //INTERESTRATE
    private BigDecimal overDueBalance;      //OVERDUEBALANCE
    private String repaymentFrequency;  //REPAYFREQUENCY
    private BigDecimal profitRate;          //PROFITRATE
    private BigDecimal ceilingRate;         //CEILINGRATE

    private Date applicationDate;       //APPLICATIONDATE
    private Date approvalDate;          //APPROVALDATE
    private Date maturityDate;          //MATURITYDATE
    private Date nextDueDate;           //NEXTDUEDATE

    private Date lastDrawndownDate;     //LASTDDATE
    private String accountType;         //ACCOUNTTYPE = ???
    private String originalTenor;       //ORIGINALAPPTENOR = ???
    private String remainingTenor;      //RMGLOANTENOR = ???
    private String debitSource;         //DEBITSOURCE = ???
    private String debitAccount;        //DEBITACC

    private String origGPPP;            //ORIGGPPP

    private String totalAmountDueSign;    //TOTALAMTDUESIGN - CR-780
    private String loanBalanceSign;           //LOANBALANCESIGN
    private Integer index;
    private String customerId;
    private String customerIdType;
    private String productCode;
    private String subProductCode;
    private String accountNumber;
    private String accountName;
    private String accountDescription;
    private String consolidatedCode;

    private String accountStatus;
    private String blockCode;
    private String relationshipCode;

    private String currencyCode;
    private BigDecimal currentBalance;
    private BigDecimal availableBalance;

    private Integer customOrder = AccountConstant.DEFAULT_ORDER;
    private Integer productOrder = AccountConstant.DEFAULT_ORDER;
}
