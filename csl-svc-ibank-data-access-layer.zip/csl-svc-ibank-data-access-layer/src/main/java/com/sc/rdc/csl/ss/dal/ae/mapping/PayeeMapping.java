package com.sc.rdc.csl.ss.dal.ae.mapping;

import com.sc.rdc.csl.ss.common.dto.payee.PayeeDto;
import com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class PayeeMapping  implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        orikaMapperFactory
                .classMap(PayeeDto.class, PayeeEntity.class)
                .byDefault()
                .register();
    }
}
