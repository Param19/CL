package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.IVRInfo;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author Sivaprakasam, Balaji (1347884)
 */
@Slf4j
@Service
@Validated
public class IVRSessionServiceImpl {

    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    @Autowired
    private IVRSessionServiceFactory ivrSessionServiceFactory;

    public IVRInfo getInfo(String id, QuerySpec querySpec) {
        //RequestValidator.validateHeader(cslRequestContext);
        log.info("getInfo Operation : id - " + id + " querySpec : " + querySpec);
        IVRInfo ivrInfo = populateQuerySpec(querySpec);
        log.info("getInfo ivrInfo tOString: " + ivrInfo.toString());
        log.info("getInfo ivrInfo : " + ivrInfo);
        log.info("getInfo mobileNo : " + ivrInfo.getMobile()+"; country : "+ivrInfo.getCountry());

        ivrInfo = ivrSessionServiceFactory.getIVRSessionService(ivrInfo.getCountry()).getIVRInfo(ivrInfo.getMobile(), ivrInfo.getCountry());

        return ivrInfo;
    }

    public IVRInfo populateQuerySpec(QuerySpec querySpec) {
        List<FilterSpec> filterSpecs = querySpec.getFilters();
        Map<Object, Object> filterMap = filterSpecs.stream()
                .collect(Collectors.toMap(x -> x.getAttributePath().get(0), FilterSpec::getValue));
        return CSLJsonUtils.convertValue(filterMap, IVRInfo.class);
    }
}
