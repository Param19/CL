package com.sc.rdc.csl.ss.dal.cn.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.helper.CommonHelper;
import com.sc.rdc.csl.ss.common.helper.MailConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import com.sc.rdc.csl.ss.dal.cn.dao.CustDetailDao;
import com.sc.rdc.csl.ss.dal.cn.dao.MailServiceDao;
import com.sc.rdc.csl.ss.dal.cn.entity.mail.MailServiceEntity;
import com.webmethods.jms.log.Log;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Slf4j
@Service(value = "mailBoxServiceCN")
public class MailBoxService extends MailService {

    @Qualifier("mailServiceDaoCn")
    @Autowired
    private MailServiceDao mailServiceDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Qualifier("custDetailDaoCn")
    @Autowired
    private CustDetailDao cardCustDao;


    @Transactional("transactionManagerCn")
    @Override
    @LogTimeTaken
    public SsBaseDto submitMailData(MailServiceEntityDto mailServiceEntityDto, SsCSLUser user) {

        Integer mailId = mailServiceDao.getNextSequence();
        String messageSenderId = cardCustDao.getCustomerEBID(user.getCustomerId());

        Log.info("messageSenderId:"+messageSenderId);
        MailServiceEntity mailServiceEntityVO = orikaMapperFacade.map(mailServiceEntityDto, MailServiceEntity.class);

        if(messageSenderId !=null) {
        mailServiceEntityVO.setMessageReceiverId(messageSenderId);
        mailServiceEntityVO.setMessageSenderId(messageSenderId);
        }

        mailServiceEntityVO.setMessageBody(CommonHelper.decodeBase64Value(mailServiceEntityVO.getMessageBody()));
        mailServiceEntityVO.setMessageSubject(CommonHelper.decodeBase64Value(mailServiceEntityVO.getMessageSubject()));
        mailServiceEntityVO.setMessageId(mailId.longValue());
        mailServiceEntityVO.setMessageMasterId(mailId.longValue());
        mailServiceEntityVO.setuUid(String.valueOf(mailId));

        Date currentDateTime = new Date();

        mailServiceEntityVO.setMessageStatusDate(currentDateTime);
        mailServiceEntityVO.setDateCreated(currentDateTime);
        mailServiceEntityVO.setDateRepliedByBO(currentDateTime);
        mailServiceEntityVO.setDateDeletedByBO(currentDateTime);
        mailServiceEntityVO.setMessageStatusDateByBO(currentDateTime);


        mailServiceEntityVO.setMessageReceiverAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_GENERAL);
        if (StringUtils.isBlank(mailServiceEntityVO.getMessageReceiverAddressType())) {
        mailServiceEntityVO.setMessageReceiverAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_ACCOUNTS);
        }

        mailServiceEntityVO.setIsDeletedByCustomer(Boolean.FALSE);
        mailServiceEntityVO.setIsRepliedByBO(Boolean.FALSE);
        mailServiceEntityVO.setIsDeletedByBO(Boolean.FALSE);
        mailServiceEntityVO.setMessageCategory("N");
        mailServiceEntityVO.setMessageSenderAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_STANDARD_CHARTERED_BANK);
        mailServiceEntityVO.setMessageStatusByBO(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailServiceEntityVO.setMessageStatus(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailServiceDao.insertMailData(mailServiceEntityVO);
        mailServiceEntityDto.setStatusDescription(MailConstant.STATUS);
        mailServiceEntityDto.setStatusCode(MailConstant.STATUS_CODE);
        return mailServiceEntityDto;

        }
        }
