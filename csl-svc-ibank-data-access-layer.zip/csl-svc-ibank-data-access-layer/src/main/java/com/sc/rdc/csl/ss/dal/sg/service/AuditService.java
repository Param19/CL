package com.sc.rdc.csl.ss.dal.sg.service;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

import com.sc.csl.retail.core.log.LogTimeTaken;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.audit.Audit;
import com.sc.rdc.csl.ss.common.helper.AuditConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IAuditService;
import com.sc.rdc.csl.ss.dal.sg.dao.AuditServiceDao;
import com.sc.rdc.csl.ss.dal.sg.entity.AuditEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("auditServiceSg")
public class AuditService extends IAuditService {
	

    @Autowired
    @Qualifier("auditServiceDaoSg")
    private AuditServiceDao auditServiceDao;

    @Autowired
    CSLRequestContext cslRequestContext;
    
	@Override
	@Transactional("transactionManagerSg")
	@LogTimeTaken
	public Audit auditTransaction(Audit audit,SsCSLUser user) {
		log.debug("auditTransaction :"+audit);
		try{
			AuditEntity auditEntity= preparePinChangeAuditEntity(audit);
			
			auditServiceDao.auditTransaction(auditEntity);
			audit.setStatusCd(AuditConstant.SUCCESS);
		}catch (Exception e) {
			log.info("Exceotion message "+e.getLocalizedMessage());
            log.error("Exception while Inserting Audit {} , {} ", user.getCustomerId(), e.getMessage());
            throw new TechnicalException(ErrorConstant.ERR_INSERTING_AUDIT);
        }
	    return audit;
  } 
	
	public AuditEntity preparePinChangeAuditEntity(Audit audit){
		
		AuditEntity auditEntity = new AuditEntity();
		String card = null;
		String embossedName = null;
		String cardType = null;
		String receiptNumber = null;
		String errorcode = null;
		String reasonForFailure = null;
		String channelFlag = null;
		String dateTime = null;
		String cardActivationStatus = null;
		String txnType = null;
		String auditInfo = audit.getAuditInfo();

		StringTokenizer auditDataToken = new StringTokenizer(auditInfo,
				AuditConstant.SEMICOLON);

		/* "Card=************5556;EmbossedName=Testing;CardType=DEBIT;ReceiptNumber=MY1611280124I80010;ErrorCode=;ErrorMessage=;ChannelFlag=IBK;DateTime=2017-03-01 10:20:41.956" */
		while (auditDataToken.hasMoreElements()) {
			String element = auditDataToken.nextToken();
			String key = StringUtils.substringBefore(element,
					AuditConstant.EQUALS);
			String value = StringUtils.substringAfter(element,
					AuditConstant.EQUALS);

			if (key.equalsIgnoreCase(AuditConstant.CARD)) {
				card = value;
			} else if (key
					.equalsIgnoreCase(AuditConstant.EMBOSSEDNAME)) {
				embossedName = value;
			} else if (key
					.equalsIgnoreCase(AuditConstant.RECEIPTNUMBER)) {
				receiptNumber = value;
			} else if (key.equalsIgnoreCase(AuditConstant.CARDTYPE)) {
				cardType = value;
			} else if (key
					.equalsIgnoreCase(AuditConstant.ERRORCODE)) {
				errorcode = value;
			} else if (key
					.equalsIgnoreCase(AuditConstant.ERRORMESSAGE)) {
				reasonForFailure = value;
			} else if (key
					.equalsIgnoreCase(AuditConstant.CHANNELFLAG)) {
				channelFlag = value;
			} else if (key.equalsIgnoreCase(AuditConstant.DATETIME)) {
				dateTime = value;
			}else if(key.equalsIgnoreCase(AuditConstant.CARD_ACTIVATION_STATUS)){
				cardActivationStatus=value;
			}else if(key.equalsIgnoreCase(AuditConstant.TXN_TYPE)){
				txnType=value;
			}
		}

		// Added to differentiate between Card activation and pin reset transactions for BO report
				if (txnType.equals(AuditConstant.DEBIT_TXN_TYPE_CA)) {
					auditEntity.setUseCase(AuditConstant.DEBIT_USE_CASE_CA);
					auditEntity.setLogEvent(AuditConstant.DEBIT_LOG_EVENT_CA);
				} else if (txnType.equals(AuditConstant.DEBIT_TXN_TYPE_PC) || txnType.equals(AuditConstant.DEBIT_TXN_TYPE_BOTH)) {
					auditEntity.setUseCase(AuditConstant.DEBIT_USE_CASE_PC);
					auditEntity.setLogEvent(AuditConstant.DEBIT_LOG_EVENT_PC);
				}
		if(cardType!=null && cardType.length() >= 1)
			auditEntity.setCardType(cardType.substring(0, 1));
		else
			auditEntity.setCardType("");
		
		//Added to determine card type field based on the transaction for Debit card it should be 01 and credit card it should be 00
				if (AuditConstant.DEBITCARD_TYPE_CHAR.equalsIgnoreCase(auditEntity.getCardType())) {
					auditEntity.setCardType(AuditConstant.DEBITCARD_TYPE);
				} else if (AuditConstant.CREDITCARD_TYPE_CHAR.equalsIgnoreCase(auditEntity.getCardType())) {
					auditEntity.setCardType(AuditConstant.CREDITCARD_TYPE);
				} else {
					//For Default values set as Debit 
					auditEntity.setCardType(AuditConstant.DEBITCARD_TYPE);
				}
		
		
		if(cslRequestContext.getSessionId()!=null)
			auditEntity.setSessionId(cslRequestContext.getSessionId());
		else
			auditEntity.setSessionId(cslRequestContext.getRequestId());
		auditEntity.setTxnId(cslRequestContext.getRequestId());
		auditEntity.setPinchangeStaus(audit.getAction());
		auditEntity.setCardNumber(card);
		auditEntity.setCardEmbossedName(embossedName);
		auditEntity.setChannel(channelFlag);
		auditEntity.setBackendTxnId(receiptNumber);
		auditEntity.setCustomerId(cslRequestContext.getCustomerId());
		auditEntity.setCustomerType(cslRequestContext.getCustomerType());
		auditEntity.setEbid(cslRequestContext.getUaas2id());
		auditEntity.setErrorCode(errorcode);
		auditEntity.setTxnType(txnType);
		auditEntity.setReasonForFailure(reasonForFailure);
		try {
			DateFormat df = new SimpleDateFormat(AuditConstant.AUDI_TIME_FORMAT);
			Date transactionDate = df.parse(dateTime);
			Timestamp timestamp = new Timestamp(transactionDate.getTime());
			auditEntity.setLogTimestamp(timestamp);
		} catch (Exception ex) {
			log.info("Exception occured while formatting dateTime "+ ex);
			auditEntity
					.setLogTimestamp(new Timestamp(new Date().getTime()));
		}
		
		auditEntity.setCardActivationStatus(cardActivationStatus);
		
		return auditEntity;
	}

}
