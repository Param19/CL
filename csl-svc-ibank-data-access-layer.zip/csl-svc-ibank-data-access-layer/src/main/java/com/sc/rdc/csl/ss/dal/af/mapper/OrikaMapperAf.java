package com.sc.rdc.csl.ss.dal.af.mapper;

import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import com.sc.rdc.csl.ss.dal.af.entity.MailVO;
import com.sc.rdc.csl.ss.dal.af.entity.QrCodePayment;

import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;

import org.springframework.stereotype.Component;

@Component
public class OrikaMapperAf implements OrikaMapperFactoryConfigurer {


    @Override
    public void configure(MapperFactory mapperFactory) {

        mapperFactory.classMap(MailServiceEntityDto.class, MailVO.class)
                .field("reference", "mailReferenceNumber")
                .field("reference", "messageMasterId")
                .field("messageCategory", "messageCategory")
                .field("messageSubject", "messageSubject")
                .field("messageBody", "messageBody")
                .register();

        //QRPayment
        mapperFactory
        .classMap(QrCodePayment.class, PaymentDto.class)
        .field("paymentid", "paymentId")
        .field("cntryCode", "countryCode")
        .register();
        
    }
}
