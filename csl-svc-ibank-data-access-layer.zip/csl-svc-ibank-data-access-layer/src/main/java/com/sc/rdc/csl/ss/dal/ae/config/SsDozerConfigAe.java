package com.sc.rdc.csl.ss.dal.ae.config;

import lombok.Getter;
import lombok.Setter;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class SsDozerConfigAe {

    @Bean("dozerMappingFilesAe")
    public DozerMappingFilesAe dozerMappingFiles() {
        return new DozerMappingFilesAe();
    }

    @Bean("dozerBeanMapperAe")
    public DozerBeanMapper dozerBeanMapper(DozerMappingFilesAe dozerMappingFiles) {
        dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/ae/dozer/customer-profile-mappings.xml");
        return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
    }

    @Setter
    @Getter
    private class DozerMappingFilesAe {
        private List<String> mappingFiles = new ArrayList<>();
    }

}

