
package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.account.FilterProductEntity;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;
import java.util.Set;

@Repository(value = "productServiceDaoHk")
@Slf4j
public class ProductServiceDao extends BaseDao {

    private static final String ACCOUNT_QUERY= "select o from com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity o where o.customerId = :customerId and o.customerIdType = :customerIdType";
    private static final String FILTER_PRODUCT_QUERY = "select f from com.sc.rdc.csl.ss.dal.hk.entity.account.FilterProductEntity f where f.accountCode IN (:accountCode) and f.lang = :lang";

    public List<AccountEntity> getWealthAccountList(SsCSLUser user, List<String> paramList){
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(ACCOUNT_QUERY);
        strQuery.append(" and o.productCode in :productCode");
        Query query = entityManagerHk.createQuery(strQuery.toString());
        query.setParameter("customerId", user.getCustomerId());
        query.setParameter("customerIdType", user.getCustomerTypeId());
        query.setParameter("productCode", paramList);
        log.info("productCode values {}",query.getParameterValue("productCode"));
        log.info("query {}",query);
        return query.getResultList();
    }

    public List<FilterProductEntity> getFilterProduct(Set<String> accountCodeList, String lang) {
        Query query = entityManagerHk.createQuery(FILTER_PRODUCT_QUERY);
        query.setParameter("accountCode", accountCodeList);
        query.setParameter("lang", lang);
        log.info("query {}", query);
        try {
            return (List<FilterProductEntity>) query.getResultList();
        } catch (javax.persistence.NoResultException e) {
            log.warn("No record found in FilterProductEntity for Account Code:{} & lang:{}", accountCodeList, lang);
            return null;
        }
    }
}

