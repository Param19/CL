package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.audit.LoginAudit;

public class AbstractLoginAuditService {

	public LoginAudit insertLoginAudit(LoginAudit loginAudit) {
		return null;
	}
}
