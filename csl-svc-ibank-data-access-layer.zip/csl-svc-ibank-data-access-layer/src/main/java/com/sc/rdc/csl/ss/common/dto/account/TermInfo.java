package com.sc.rdc.csl.ss.common.dto.account;

import com.fasterxml.jackson.annotation.JsonInclude;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.util.Date;
import lombok.Data;

@Data
@XmlType(name = "termInfo")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TermInfo {
   private Date currIssueData;
   private Date currMaturityDate;
   private Date finalMaturityDate;
   private String timesToRenew;
   private String timesrenewed;
   private String termCode;
   private String term;
   private String negotiableRate;
   private String interestRate;
   private String totMaintenanceInt;
   private String trancheID;
   
}
                      