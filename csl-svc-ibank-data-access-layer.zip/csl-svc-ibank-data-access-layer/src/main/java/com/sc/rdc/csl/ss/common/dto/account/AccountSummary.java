package com.sc.rdc.csl.ss.common.dto.account;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import java.util.List;
import lombok.Data;

@Data
public class AccountSummary extends SsBaseDto {
   private List<WealthAccountDto> wealthAccountList ;
    private List<AccountDto> accounts ;
}
