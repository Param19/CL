package com.sc.rdc.csl.ss.dal.vn.entity;

import javax.persistence.Entity;

import lombok.Data;

@Data
@Entity
//@Table(name = "DB2INST1", schema = "USERINFO")
public class UserInfoEntity {
	
	/*@Id
	@Column(name = "RELNO")*/
	private String relNo;
	
	//@Column(name = "ACTIVESTATUS")
	private char activeStatus;
	
	//@Column(name = "MOBILENO")
	private Long mobileNo;
	
	//@Column(name = "NAME")
	private String name;
	
	//@Column(name = "SHORTNAME")
	private String shortName;
	
	//@Column(name = "EMAILID")
	private String emailid;

}
