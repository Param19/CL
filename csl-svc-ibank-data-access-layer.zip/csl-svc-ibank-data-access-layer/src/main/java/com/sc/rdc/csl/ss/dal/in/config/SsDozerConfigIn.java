package com.sc.rdc.csl.ss.dal.in.config;

import lombok.Getter;
import lombok.Setter;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class SsDozerConfigIn {

	@Bean("dozerMappingFilesIn")
	public DozerMappingFilesIn dozerMappingFiles() {
		return new DozerMappingFilesIn();
	}



	@Bean("dozerBeanMapperIn")
	public DozerBeanMapper dozerBeanMapper( DozerMappingFilesIn dozerMappingFiles) {
		 dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/in/dozer/customer-profile-mappings.xml");
		 dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/in/dozer/mail-service-mappings.xml");
		return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
	}

	@Setter
	@Getter
	private class DozerMappingFilesIn {
 		private List<String> mappingFiles = new ArrayList<>();
	}
        
        
}
