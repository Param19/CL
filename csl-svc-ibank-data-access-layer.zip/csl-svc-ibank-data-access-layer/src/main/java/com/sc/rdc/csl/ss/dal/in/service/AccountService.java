package com.sc.rdc.csl.ss.dal.in.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.AccountDto;
import com.sc.rdc.csl.ss.common.dto.account.Transaction;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IAccountService;
import com.sc.rdc.csl.ss.dal.in.dao.AccountServiceDao;
import com.sc.rdc.csl.ss.dal.in.dao.ProductServiceDao;
import com.sc.rdc.csl.ss.dal.in.entity.AccountEntity;
import com.sc.rdc.csl.ss.dal.in.entity.FilterProductEntity;

import com.sc.rdc.csl.ss.dal.in.dao.AccountTransactionDao;
import com.sc.rdc.csl.ss.dal.in.entity.AccountTransactionEntity;

import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.IncludeRelationSpec;
import io.katharsis.queryspec.QuerySpec;

import lombok.extern.slf4j.Slf4j;

import ma.glasnost.orika.MapperFacade;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.*;

@Slf4j
@Service("accountServiceIn")
public class AccountService extends IAccountService {

    @Autowired
    @Qualifier("accountServiceDaoIn")
    private AccountServiceDao accountServiceDao;

    @Autowired
    @Qualifier("productServiceDaoIn")
    private ProductServiceDao productServiceDao;

    @Autowired
    @Qualifier("accountTransactionDaoIn")
    private AccountTransactionDao accountTransactionDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Transactional(value = "transactionManagerIn" , readOnly = true)
    @LogTimeTaken
    public List<AccountDto> getAccountSummary() {
        List<AccountDto> accountDtoList = new ArrayList<AccountDto>();

        try {
            Optional<List<AccountEntity>> accountEntityList = Optional.ofNullable(accountServiceDao.getAccountSummary());
            accountEntityList =  buildAccountList(accountEntityList);
            log.info("accountEntityList after setting the account description ::{}", accountEntityList);
            accountEntityList.get().forEach(accountEntity -> {
                accountDtoList.add(orikaMapperFacade.map(accountEntity, AccountDto.class));
            });

            log.info("Orika mapper result :{}", accountDtoList);
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Account Summary for user  , {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return accountDtoList;
    }

    @Transactional(value = "transactionManagerIn" , readOnly = true)
    @LogTimeTaken
    public AccountDto findAccount(String accountNo, QuerySpec querySpec) {
        AccountDto accountDto = null;
        try {
            log.info("Retrieving account details for account no: " + accountNo);
            Optional<AccountEntity> accountEntityOpt = Optional.ofNullable(accountServiceDao.getAccountDetails(accountNo));
            AccountEntity accountEntity = buildAccount(accountEntityOpt);
            accountDto = orikaMapperFacade.map(accountEntity, AccountDto.class);
            log.info(accountDto.toString());
            if (containsRelation(querySpec, "transactions")) {
                FilterSpec filterSpec = querySpec.getFilters().get(0);
                String fromDate = filterSpec.getValue().toString();
                List<AccountTransactionEntity> accountTransactionEntities = accountTransactionDao.getAccountTransactions(accountNo, fromDate);
                for (AccountTransactionEntity accountTransactionEntity : accountTransactionEntities) {
                    accountDto.getTransactions().add(orikaMapperFacade.map(accountTransactionEntity, Transaction.class));
                }
            }
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Account for account no, {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return accountDto;
    }

    @Transactional(value = "transactionManagerIn" , readOnly = true)
    @LogTimeTaken
    public List<AccountDto> findAllAccount(List<String> accountNoList, QuerySpec querySpec) {
        List<AccountDto> accountDtoList = new ArrayList<>();
        try {
            log.info("Retrieving All account details for account no: " + accountNoList);
            List<AccountEntity> accountEntityOpt = accountServiceDao.getAllAccountDetails(accountNoList);
            Optional<List<AccountEntity>> accountEntityOptList = Optional.ofNullable(accountEntityOpt);
            Optional<List<AccountEntity>> accountEntityList = buildAccountList(accountEntityOptList);
            if(accountEntityList.isPresent()) {
                List<AccountEntity> accountEntitylis = accountEntityList.get();

                accountEntitylis.forEach(accountEntity -> {
                    AccountDto accountDto = orikaMapperFacade.map(accountEntityList, AccountDto.class);
                    log.info(accountDto.toString());
                    if (containsRelation(querySpec, "transactions")) {
                        FilterSpec filterSpec = querySpec.getFilters().get(0);
                        String fromDate = filterSpec.getValue().toString();
                        try {
                            List<AccountTransactionEntity> accountTransactionEntities = accountTransactionDao.getAccountTransactions(accountEntity.getAccountNumber(), fromDate);
                            for (AccountTransactionEntity accountTransactionEntity : accountTransactionEntities) {
                                accountDto.getTransactions().add(orikaMapperFacade.map(accountTransactionEntity, Transaction.class));
                            }
                        } catch (ParseException ex) {
                            log.error("Error while getting the transaction information for the account :: {} , Error : {}",accountEntity.getAccountNumber() , ex.getMessage());
                        }
                    }
                    accountDtoList.add(accountDto);
                });

            }
        } catch(BusinessException businessException) {
            throw businessException;
        } catch(Exception e) {
            log.error("Exception while fetching Account for account no, {} ", e.getMessage());
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        }
        return accountDtoList;
    }

    private AccountEntity buildAccount(Optional<AccountEntity> accountEntity) {
        List<AccountEntity> accountEntityList = new ArrayList<>();
        if(accountEntity.isPresent()) {
            accountEntityList.add(accountEntity.get());
        } else {
            throw new BusinessException(ErrorConstant.CASA_ACCOUNT_NOT_FOUND);
        }
        Optional<List<AccountEntity>> accountEntityListOptional = Optional.ofNullable(accountEntityList);
        return  buildAccountList(accountEntityListOptional).get().get(0);
    }

    private Optional<List<AccountEntity>> buildAccountList(Optional<List<AccountEntity>> accountEntityList){

        ArrayList<String> accountCodeList = new ArrayList<String>();
        accountEntityList.get().forEach(accountEntity -> {
            if(StringUtils.isNotEmpty(accountEntity.getProductCode()) && StringUtils.isNotEmpty(accountEntity.getSubProductCode())){
                accountCodeList.add(accountEntity.getProductCode()+"-"+accountEntity.getSubProductCode());
            }
        });
        Set<String> uniqueAccountCodeList = new HashSet<String>(accountCodeList);
        List<FilterProductEntity> filterProductEntityList =  productServiceDao.getFilterProduct(uniqueAccountCodeList, requestContext.getLanguage());

        log.info("filterProductEntityList after setting the filterProductEntityList ::{}", filterProductEntityList);
        log.info("accountCodeList :{}",accountCodeList);
        if(accountEntityList!= null && filterProductEntityList != null){
            accountEntityList.get().forEach(accountEntity -> {
                for(FilterProductEntity entity: filterProductEntityList){
                    if(entity!=null && StringUtils.isNotEmpty(entity.getProductCode()) && StringUtils.isNotEmpty(entity.getSubProductCode())){
                        if(accountEntity.getProductCode().equalsIgnoreCase(entity.getProductCode()) && accountEntity.getSubProductCode().equalsIgnoreCase(entity.getSubProductCode())){
                            accountEntity.setAccountDescription(entity.getAccountTypeAlias());
                        }
                    }
                }
            });
        }

        log.info("accountEntityList after setting the account description ::{}", accountEntityList);
        return accountEntityList;
    }

    private List<IncludeRelationSpec> getIncludedRelations(QuerySpec querySpec) {
        return querySpec.getIncludedRelations();
    }

    private boolean containsRelation(QuerySpec querySpec, String relationName) {
        return getIncludedRelations(querySpec).stream()
                .anyMatch(relation  -> relation.toString().equalsIgnoreCase(relationName));
    }
}

