
package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.util.CSLAssert;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.AccountDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import io.katharsis.queryspec.QuerySpec;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImpl {
    

    @Autowired
    private AccountServiceFactory accountServiceFactory;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;


    public List<AccountDto> getAccountSummary()  {
        validateHeaders();
        List<AccountDto> accountDtoList = accountServiceFactory.getAccountService(requestContext.getCountry()).getAccountSummary();
        return accountDtoList;
    }

    public List<AccountDto> getAccountDescription(){
    	validateHeaders();
    	List<AccountDto> accountDescription = accountServiceFactory.getAccountService(requestContext.getCountry()).getAccountDescription();
        return accountDescription;
    }

    public AccountDto findAccount(String accountNo, QuerySpec querySpec) {
        validateHeaders();
        return  accountServiceFactory.getAccountService(requestContext.getCountry()).findAccount(accountNo, querySpec);
    }

    public List<AccountDto> findAllAccount(List<String> accountNoList,QuerySpec querySpec) {
        return accountServiceFactory.getAccountService(requestContext.getCountry()).findAllAccount(accountNoList,querySpec);
    }

    private void validateHeaders() {
        CSLAssert.hasLength(requestContext.getCountry(), ErrorConstant.CASA_NO_COUNTRY);
        CSLAssert.hasLength(requestContext.getRelId(), ErrorConstant.CASA_NO_RELID);
    } 
}
