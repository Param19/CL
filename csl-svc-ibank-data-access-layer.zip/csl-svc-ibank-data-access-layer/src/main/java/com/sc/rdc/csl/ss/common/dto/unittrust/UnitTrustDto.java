package com.sc.rdc.csl.ss.common.dto.unittrust;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
@JsonApiResource(type = "unit-trusts")
public class UnitTrustDto extends SsBaseDto implements Serializable {

    @JsonApiId
    private String id;
    @JsonProperty("account-number")
    private String accountNumber;
    @JsonProperty("currency-code")
    private String currencyCode;
    @JsonProperty("rel-Id")
    private String relId;
    @JsonProperty("available-balance")
    private BigDecimal availableBalance;
    @JsonProperty("fund-short-name")
    private String fundShortName;
    @JsonProperty("product-description")
    private String productdescription;
}
