package com.sc.rdc.csl.ss.common.helper;

public class AuditConstant {
	
	public static final String  DATETIME="DateTime";
	public static final String  PIN_SERVICE="PINCHANGE";
	public static final String  CARD_ACTIVATE_SERVICE="CARDACTIVATION";
	
	public static final String CARD = "Card";
	public static final String EMBOSSEDNAME = "EmbossedName";
	public static final String RECEIPTNUMBER = "ReceiptNumber";
	public static final String ERRORCODE = "Errorcode";
	public static final String ERRORMESSAGE = "ErrorMessage";
	public static final String CHANNELFLAG = "ChannelFlag";
	public static final String CARD_ACTIVATION_STATUS = "CardActivationStatus";
	public static final String TXN_TYPE = "txnType";
	public static final String COUNTRY_CODE = "countryCode";

	public static final String CARDTYPE = "CardType";
	public static final String EQUALS = "=";
	public static final String SEMICOLON = ";";
	
	public static final String DEBITCARD_TYPE = "01";
	public static final String CREDITCARD_TYPE = "00";
	
	public static final String DEBITCARD_TYPE_CHAR = "D";
	public static final String CREDITCARD_TYPE_CHAR = "C";
	
	
	public static final String DEBIT_LOG_EVENT_PC = "SCBLogAfterDebitPinChange";
	public static final String DEBIT_LOG_EVENT_CA = "SCBLogAfterDebitActivation";
	
	public static final String DEBIT_USE_CASE_PC = "DebitCardPinChange";
	public static final String DEBIT_USE_CASE_CA = "DebitCardActivation";
	
	public static final String DEBIT_TXN_TYPE_PC = "PC";
	public static final String DEBIT_TXN_TYPE_CA = "CA";
	public static final String DEBIT_TXN_TYPE_BOTH = "BOTH";
	
	public static final String HYPEN = "-";
	public static final String SUCCESS = "0000";
	public static final String AUDI_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String SECTION = "ResetPin";
	
	public static final String S_SUCCESS = "success";
	public static final String S_FAILURE = "failure";
	
	public static final String CREDIT_CARD_USE_CASE_PC = "CreditCardPinChange";
	public static final String CREDIT_LOG_EVENT_PC = "SCBLogAfterPinChange";
	public static final String CREDIT_CARD_USE_CASE_CA = "CreditCardCardActivation";
	public static final String CREDIT_LOG_EVENT_CA = "SCBLogAfterCardActivation";
	public static final String CREDIT_CARD_USE_CASE_BOTH = "CreditCardCardActivation";
	public static final String CREDIT_LOG_EVENT_BOTH = "SCBLogAfterCardActivation";
	
    public static final String OPERATION_CC_PINSET = "CCPINSET";
 	public static final String OPERATION_CC_ACTIVATION = "CCACTV";
 	public static final String OPERATION_CC_PINACTIV = "CCPINACTV";
 	public static final String OPERATION_CC_SMSACTV = "CCSMSACTV";
	
	
	
}
