package com.sc.rdc.csl.ss.dal.sg.config;


import com.sc.rdc.csl.ss.common.dto.limit.TransactionLimit;
import com.sc.rdc.csl.ss.dal.sg.entity.TransactionLimitEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class TransactionLimitDtoToEntityMapperConfig implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory mapperFactory) {

        mapperFactory.classMap(TransactionLimit.class, com.sc.rdc.csl.ss.dal.sg.entity.TransactionLimitEntity.class)
                .constructorA()
                .constructorB()
                .mapNulls(false)
                .mapNullsInReverse(false)
                .byDefault()
                .register();

        mapperFactory.classMap(TransactionLimitEntity.class, TransactionLimit.class)
                .constructorA()
                .constructorB()
                .mapNulls(false)
                .mapNullsInReverse(false)
                .byDefault()
                .register();
    }

}
