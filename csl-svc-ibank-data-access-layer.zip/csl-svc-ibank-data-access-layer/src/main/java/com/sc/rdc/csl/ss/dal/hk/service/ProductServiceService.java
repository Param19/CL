package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.account.BndAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.CasaAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.WealthAccountDto;
import com.sc.rdc.csl.ss.common.service.IProductService;
import com.sc.rdc.csl.ss.dal.hk.config.DozerUtilsHk;
import com.sc.rdc.csl.ss.dal.hk.dao.ProductServiceDao;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity;
import java.util.Arrays;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service(value="productServiceServiceHk")
@Slf4j
public class ProductServiceService extends IProductService {
    
    @Qualifier("dozerUtilsHk")
    @Autowired  
    private DozerUtilsHk dozerUtilsHk;
               
    @Qualifier("productServiceDaoHk")        
    @Autowired
    private ProductServiceDao accountServiceDao;

    @Override
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public List<CasaAccountDto> getIdaAccountSummary(SsCSLUser user){
        List<AccountEntity> entityList =  accountServiceDao.getWealthAccountList(user, Arrays.asList("CDA","DDA"));
        List<CasaAccountDto> casaList = dozerUtilsHk.convertCasaAccount(entityList);
        return casaList;
    }
    
    
    @Override
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public List<BndAccountDto> getBndAccountSummary(SsCSLUser user){
       List<AccountEntity> entityList =   accountServiceDao.getWealthAccountList(user, Arrays.asList("BND"));
       List<BndAccountDto> bndList = dozerUtilsHk.convertBndAccount(entityList);
       return bndList;  
    }
    
    
    @Override
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public List<WealthAccountDto> getInvAccountSummary(SsCSLUser user){
        List<AccountEntity> entityList =  accountServiceDao.getWealthAccountList(user, Arrays.asList("ISA"));
        List<WealthAccountDto> invList = dozerUtilsHk.convertAccount(entityList);
        return invList; 
    }
    
  
    
}
