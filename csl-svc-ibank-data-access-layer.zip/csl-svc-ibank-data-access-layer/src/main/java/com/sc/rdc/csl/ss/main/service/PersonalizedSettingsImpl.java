package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsSummary;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.main.helper.ErrorCodeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service("personalizedSettingsImpl")
public class PersonalizedSettingsImpl {

    @Autowired
    private PersonalizedSettingsFactory personalizedSettingsFactory;

    @Autowired
    private ErrorCodeUtil errorCodeUtil;

    public SsBaseDto getPersonalizedSettingsSummary(SsCSLUser user) {
        PersonalizedSettingsSummary personalizedSettingsSummary = null;
        personalizedSettingsSummary = personalizedSettingsFactory.getPersinalizedSettingsService(
                user.getCountry()).getPersonalizedSummary(user);
        if (personalizedSettingsSummary == null) {
            return errorCodeUtil.prepareResponseByCode(ErrorConstant.PERSONALIZED_SETTINGS_NOT_FOUND.name(), new SsBaseDto());
        }
        personalizedSettingsSummary.setCode("0");
        return personalizedSettingsSummary;
    }
}
