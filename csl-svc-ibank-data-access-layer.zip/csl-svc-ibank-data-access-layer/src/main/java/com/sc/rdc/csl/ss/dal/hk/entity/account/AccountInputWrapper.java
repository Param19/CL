package com.sc.rdc.csl.ss.dal.hk.entity.account;

import java.util.List;
import lombok.Data;

@Data
public class AccountInputWrapper {
   private List<AccountEntity> accountEntityList;
}
