/**
 * C/F *** Date 29/12/2010 *** Project : NFS-CN ** QC Log: NA ** CR No: NA ** Design Doc: FSD_FOA_Payments_CN_v0.4_SignedOff.doc ** Revision No XXX    ** Modified by 1378167  ** Start
 **/
package com.sc.rdc.csl.ss.dal.cn.entity.payment;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author 1546088
 */
@Data
public class PaymentEntity extends BaseDto {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String transactionId;
    private Long notificationId;
    private String fromAccountNumber;
    private String toAccountNumber;
    private String currencyCode;
    private BigDecimal amount;
    private String message;
    private String reference;
    private Date transferDate;
    private Date processedTimestamp;
    private String destinationAccountName;
    private String transactionStatus;
    private String transactionType;
    private String recurInterval;
    private Date recurEndDate;
    private String bankCode;
    private String bankName;
    private String sourceAccountName;
    private String customerId;
    private String customerIdType;
    private String customerEBID;
    private String transactionStatusCode;
    private String authorizationCode;
    private String macValue;
    private String paymentMode;
    private String repaymentType;
    private String merchantId;
    private String merchantCategory;
    private String merchantCode;
    private Long payeeId;
    private Date settlementDate;
    private String billType;
    private String sourceAccountRelCode;
    private String sourceCurrencyCode;
    private String rdsLogNumber;
    private BigDecimal conversionRate;
    private BigDecimal sourceAmount;
    private String transactionCurrencyCode;
    private Boolean isCrossCurrency;

    // extra fields
    //private TransferFXRateVO transferFXRateVO;
    //private ProductVO fromAccountVO;
    //private ProductVO toAccountVO;
    //private PayeeVO payeeVO;

    private String branchCode;
    private String hostReasonCode;

    // sourceAmount might be in foreign currency (this is for RAE OTPL limit checking)
    private BigDecimal localCurrencyAmount;

    //private TransactionStatusVO transactionStatusVO;
    private String ackMessageCode;
    private String ackErrorCode;        // business error code

    // Bill Payment
    //private MerchantVO merchantVO;
    //private BillerVO billerVO;

    private String bvTransactionId;
    private String secondBillAccountNumber;
    private Date billDate;
    private String policyNo;
    private String textBoxOne;
    private String textBoxTwo;
    private String textBoxThree;
    private String textBoxFour;
    private String textBoxFive;
    private String textBoxSix;
    private String textBoxSeven;
    private String mobilePhoneNumber;
    private String currentTime;
    private String billPayeeCityCode;

    private Long billerId;
    private String payInfoOrganization;
    private String payInfoBarcode;
    private String delimitedBarCode;
    private String ibankingMsgId;
    private String ibankingSSN;
    private String billerCity;
    private String billerType;
    private String blType;
    private String billerName;

    //additional columns
    private String fromAccountCode;
    private String toAccountCode;
    private Boolean isTransferDateHoliday;
    private String ccPaymentInd;

    //multiple bill payments
    //private List<SelectItem> fromAccountSelectItems;
    private Integer fromAccountSelectedIndex;
    //private boolean isRecurring;
    //private List<ProductVO> fromAccounts;
    //private List<BillTypeVO> billTypes;

    //EPSCO after validation/mapping bill acc and bill type
    private String epscoBillAccount;
    private String epscoBillType;

    private String highRiskInd;

    // IBFT Via Opal
    private String priority;
    private String brnCode;
    private String remitterSubBranchName;
    private String opalsessionKey;
    private String opalStatusCode;
    private String opalServerStatusCode;
    private String opalStatusDesc;
    private String opalPmtMethod;
    private Date opalEffDt;
    private String opalBORefId;
    private BigDecimal transferFee;
    private String paymentRefId;

    // Payment Gateway
    private String cupTraceNum;
    private String merchantName;
    private Date dateTimeCUP;
    private String acquirerBin;
    private String initTraceBin;
    private String merchantOrderNo;
    private String cardNum;
    private String reconDesc;
    private String reversalFlagStatus;
    private String sysTrxType;

    // International/Telegraphic transfer
    //private InternationalFundTransferVO internationalFundTransferVO;

    // Channel Code
    private String channelCode;
    private boolean update;

}

/*
 TABLE NAME: CFE.SCHEDULEDTRANSACTIONS

 COLUMN_NAME               DATA_TYPE  DATA_LENGTH  DATA_PRECISION  DATA_SCALE  NULLABLE  DATA_DEFAULT  GENERATED  IDENTITY
 ------------------------  ---------  -----------  --------------  ----------  --------  ------------  ---------  --------
 TRANSACTIONID             VARCHAR    36                                       NO                                                
 NOTIFICATIONID            BIGINT                                              YES                                               
 FROMACCOUNTNUMBER         VARCHAR    50                                       YES                                               
 TOACCOUNTNUMBER           VARCHAR    50                                       YES                                               
 CURRENCYCODE              VARCHAR    3                                        YES                                               
 AMOUNT                    DECIMAL                 25              2           YES                                               
 MESSAGE                   VARCHAR    255                                      YES                                               
 REFERENCE                 VARCHAR    50                                       YES                                               
 TRANSFERDATE              TIMESTAMP                                           YES                                               
 PROCESSEDTIMESTAMP        TIMESTAMP                                           YES                                               
 DESTINATIONACCOUNTNAME    VARCHAR    50                                       YES                                               
 TRANSACTIONSTATUS         VARCHAR    10                                       YES                                               
 TRANSACTIONTYPE           VARCHAR    10                                       YES                                               
 RECURRENCEINTERVAL        VARCHAR    50                                       YES                                               
 RECURRENCEENDDATE         DATE                                                YES                                               
 BANKNAME                  VARCHAR    50                                       YES                                               
 SOURCEACCOUNTNAME         VARCHAR    50                                       YES                                               
 CUSTOMER_ID               VARCHAR    20                                       YES                                               
 CUST_TYPE                 VARCHAR    4                                        YES                                               
 EBID                      VARCHAR    20                                       YES                                               
 TRANSACTIONSTATUSCODE     VARCHAR    10                     `                  YES                                               
 AUTH_CODE                 VARCHAR    30                                       YES                                               
 MAC_VALUE                 VARCHAR    50                                       YES                                               
 PAYMENT_MODE              VARCHAR    2                                        YES                                               
 REPAYMENT_TYPE            VARCHAR    1                                        YES                                               
 MERCHANT_ID               CHARACTER  16                                       YES                                               
 MERCHANT_CATEGORY         VARCHAR    10                                       YES                                               
 PAYEE_ID                  BIGINT                                              YES                                               
 SETTLEMENT_DATE           TIMESTAMP                                           YES                                               
 LAST_UPDATED_BY           VARCHAR    20                                       YES                                               
 SOURCE_ACCOUNT_RELCODE    VARCHAR    3                                        YES                                               
 SOURCE_CURRENCYCODE       CHARACTER  3                                        YES                                               
 RDS_LOG_NUMBER            VARCHAR    50                                       YES                                               
 CONVERSION_RATE           DECIMAL                 19              6           YES                                               
 SOURCE_AMOUNT             DECIMAL                 25              2           YES                                               
 DT_CREATED                TIMESTAMP                                           YES                                               
 DT_UPD                    TIMESTAMP                                           YES                                               
 TRANSACTION_CURRENCYCODE  CHARACTER  3                                        YES                                               
 ISCROSSCURRENCY           VARCHAR    1                                        YES                                               
 BV_TRANSACTIONID          VARCHAR    36                                       YES                                               
 BILL_TYPE                 VARCHAR    2                                        YES                                               

 CONSTRAINTS: 
 */
