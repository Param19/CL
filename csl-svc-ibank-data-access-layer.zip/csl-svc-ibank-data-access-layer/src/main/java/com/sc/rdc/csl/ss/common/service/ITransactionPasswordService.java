
package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.dal.hk.dto.TransactionPasswordDto;

public abstract class ITransactionPasswordService {
    public TransactionPasswordDto getTransactionPassword(String ebid) {
        return null;
    }
    
    public void save(TransactionPasswordDto transactionPasswordDto) {
    }
}
