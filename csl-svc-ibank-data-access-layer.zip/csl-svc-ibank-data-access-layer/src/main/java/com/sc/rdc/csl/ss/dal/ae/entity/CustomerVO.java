package com.sc.rdc.csl.ss.dal.ae.entity;

import lombok.Data;

import java.util.Date;

@Data
public class CustomerVO extends UserVO {

    private static final long serialVersionUID = 1L;

    private String customerEBID;

    private String customerPBID;

    private String customerGroupId;

    private String customerIdType;

    private String customerId;

    private String customerFullName;

    private String customerName1;

    private String customerName2;

    private String nickName;

    private String emailAddress;

    private String mobileNumber;

    private String accessKey;

    private String notificationType;

    private String isActivated;

    private String pinMailerSerialNo;

    private Date pinMailerExpiredDate;

    private Integer pinMailerCounter;

    private String segmentCode;

    private Date activationTime;

    private Date serviceStartTime;

    private Date serviceEndTime;

    private Date suspensionDateStart;

    private Date suspensionDateEnd;

    private String ftlBrowserId;

    private Date ftlTermAcceptDate;

    private Date regDate;

    private String regBy;

    private String regMode;

    private String activationType;

    private String twoFAType;

    private String remark;

    private String masterNumber;

    private String loggedIn;

    private String isEmailGen;

    private String migrateFlag;

    private String isStaff;

    private long reRegCount;

    private String twoFAFlag;

    private String address1;

    private String address2;

    private String address3;

    private String address4;

    private String district;
}
