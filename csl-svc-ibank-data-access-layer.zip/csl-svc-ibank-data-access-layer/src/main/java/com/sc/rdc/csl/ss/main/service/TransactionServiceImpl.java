package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.account.Transaction;
import io.katharsis.queryspec.QuerySpec;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransactionServiceImpl {

    @Autowired
    private TransactionServiceFactory txnServiceFactory;

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;


    public List<Transaction> fetchTransaction(List<String> accountNo, QuerySpec querySpec) {

        List<Transaction> transactionList = txnServiceFactory.getAccountService(requestContext.getCountry()).getTransactions(accountNo,querySpec);
        return transactionList;
    }
}
