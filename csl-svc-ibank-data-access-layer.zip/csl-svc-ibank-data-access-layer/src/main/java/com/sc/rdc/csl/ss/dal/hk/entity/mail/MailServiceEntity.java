package com.sc.rdc.csl.ss.dal.hk.entity.mail;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.Date;

/**
 * Created by 1569433 on 7/29/2017.
 */
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MailServiceEntity {

    private static final long serialVersionUID = 1L;
    private Long messageId;
    private Long messageMasterId;
    private String messageSenderId;
    private String messageSenderAddressType;
    private String messageCategory;
    private String messageReceiverId;
    private String messageReceiverAddressType;
    private String messageSubject;
    private String messageBody;
    private String messageStatus;

    private Boolean isDeletedByCustomer;
    private Boolean isRepliedByBO;
    private Boolean isDeletedByBO;

    private String messageStatusByBO;

    private String reference;
    private String uUid;

    private Date messageStatusDate;

    private Date dateCreated;

    private Date dateRepliedByBO;
    private Date dateDeletedByBO;
    private Date messageStatusDateByBO;


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public Long getMessageMasterId() {
        return messageMasterId;
    }

    public void setMessageMasterId(Long messageMasterId) {
        this.messageMasterId = messageMasterId;
    }

    public String getMessageSenderId() {
        return messageSenderId;
    }

    public void setMessageSenderId(String messageSenderId) {
        this.messageSenderId = messageSenderId;
    }

    public String getMessageSenderAddressType() {
        return messageSenderAddressType;
    }

    public void setMessageSenderAddressType(String messageSenderAddressType) {
        this.messageSenderAddressType = messageSenderAddressType;
    }

    public String getMessageCategory() {
        return messageCategory;
    }

    public void setMessageCategory(String messageCategory) {
        this.messageCategory = messageCategory;
    }

    public String getMessageReceiverId() {
        return messageReceiverId;
    }

    public void setMessageReceiverId(String messageReceiverId) {
        this.messageReceiverId = messageReceiverId;
    }

    public String getMessageReceiverAddressType() {
        return messageReceiverAddressType;
    }

    public void setMessageReceiverAddressType(String messageReceiverAddressType) {
        this.messageReceiverAddressType = messageReceiverAddressType;
    }

    public String getMessageSubject() {
        return messageSubject;
    }

    public void setMessageSubject(String messageSubject) {
        this.messageSubject = messageSubject;
    }

    public String getMessageBody() {
        return messageBody;
    }

    public void setMessageBody(String messageBody) {
        this.messageBody = messageBody;
    }

    public String getMessageStatus() {
        return messageStatus;
    }

    public void setMessageStatus(String messageStatus) {
        this.messageStatus = messageStatus;
    }

    public Boolean getDeletedByCustomer() {
        return isDeletedByCustomer;
    }

    public void setDeletedByCustomer(Boolean deletedByCustomer) {
        isDeletedByCustomer = deletedByCustomer;
    }

    public Boolean getRepliedByBO() {
        return isRepliedByBO;
    }

    public void setRepliedByBO(Boolean repliedByBO) {
        isRepliedByBO = repliedByBO;
    }

    public Boolean getDeletedByBO() {
        return isDeletedByBO;
    }

    public void setDeletedByBO(Boolean deletedByBO) {
        isDeletedByBO = deletedByBO;
    }

    public String getMessageStatusByBO() {
        return messageStatusByBO;
    }

    public void setMessageStatusByBO(String messageStatusByBO) {
        this.messageStatusByBO = messageStatusByBO;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getuUid() {
        return uUid;
    }

    public void setuUid(String uUid) {
        this.uUid = uUid;
    }

    public Date getMessageStatusDate() {
        return messageStatusDate;
    }

    public void setMessageStatusDate(Date messageStatusDate) {
        this.messageStatusDate = messageStatusDate;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    public Date getDateRepliedByBO() {
        return dateRepliedByBO;
    }

    public void setDateRepliedByBO(Date dateRepliedByBO) {
        this.dateRepliedByBO = dateRepliedByBO;
    }

    public Date getDateDeletedByBO() {
        return dateDeletedByBO;
    }

    public void setDateDeletedByBO(Date dateDeletedByBO) {
        this.dateDeletedByBO = dateDeletedByBO;
    }

    public Date getMessageStatusDateByBO() {
        return messageStatusDateByBO;
    }

    public void setMessageStatusDateByBO(Date messageStatusDateByBO) {
        this.messageStatusDateByBO = messageStatusDateByBO;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
