package com.sc.rdc.csl.ss.dal.in.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * Created by 1569433 on 7/29/2017.
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MailServiceEntity {
	
	private static final long serialVersionUID = 1L;
	
	private Long messageId;
	private Long messageMasterId;
	private String messageSenderId;
	private String messageSenderAddressType;
	private String messageCategory;
	private String messageReceiverId;
	private String messageReceiverAddressType;
	
	private String messageSubject;
	private String messageBody;
	private String messageStatus;
	private Boolean isDeletedByCustomer;
	private Date messageStatusDate;
	private Date dateCreated;
	private Date dateRepliedByBO;
	private Boolean isRepliedByBO;
	private Date dateDeletedByBO;
	private Boolean isDeletedByBO;
	private String messageStatusByBO;
	private Date messageStatusDateByBO;
	
	private String uUid;
	private String referenceNumber;
	
	//#### for handle the checkbox list
	private boolean isSelected;

	public String getuUid() {
		return uUid;
	}

	public void setuUid(String uUid) {
		this.uUid = uUid;
	}
	
}
