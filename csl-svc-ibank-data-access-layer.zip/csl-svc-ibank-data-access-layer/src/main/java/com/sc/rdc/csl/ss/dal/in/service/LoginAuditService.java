package com.sc.rdc.csl.ss.dal.in.service;


import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.audit.LoginAudit;
import com.sc.rdc.csl.ss.common.helper.AuditConstant;
import com.sc.rdc.csl.ss.common.service.AbstractLoginAuditService;
import com.sc.rdc.csl.ss.dal.in.dao.LoginAuditDao;
import com.sc.rdc.csl.ss.dal.in.entity.LoginAuditEntity;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Service("loginAuditServiceIn")
@Slf4j
public class LoginAuditService extends AbstractLoginAuditService {

	@Autowired
	@Qualifier("loginAuditDaoIn")
	private LoginAuditDao loginAuditDao;
	
    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;
    
    @Autowired
    private MapperFacade orikaMapperFacade;
    
    @Override
	@Transactional("transactionManagerIn")
    public LoginAudit insertLoginAudit(LoginAudit loginAudit){
    	log.info("LoginAuditService:insertLoginAudit - START");
    	try{
    		LoginAuditEntity loginAuditEntity = orikaMapperFacade.map(loginAudit, LoginAuditEntity.class);
    		loginAuditEntity.setLogTimestamp(new Date());
    		loginAuditDao.insertLoginAudit(loginAuditEntity);
    		loginAudit.setStatus(AuditConstant.S_SUCCESS);
    	}
    	catch(Exception e){
    		log.error("Exception while inserting login audit", requestContext.getCustomerId(), e.getMessage());
    		loginAudit.setStatus(AuditConstant.S_SUCCESS);
    	}
    	log.info("LoginAuditService:insertLoginAudit - END");
    	return loginAudit;
    }
}
