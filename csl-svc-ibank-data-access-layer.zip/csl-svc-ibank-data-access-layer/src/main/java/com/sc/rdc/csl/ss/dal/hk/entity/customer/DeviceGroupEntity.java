package com.sc.rdc.csl.ss.dal.hk.entity.customer;

import com.sc.rdc.csl.ss.common.dto.BaseDto;

public class DeviceGroupEntity extends BaseDto {

    private static final long serialVersionUID = -5411545018519626805L;

    private String deviceChannel;
    private String settingId;
    private Boolean isVisible;

    public DeviceGroupEntity() {
    }

    public String getDeviceChannel() {
        return deviceChannel;
    }

    public void setDeviceChannel(String deviceChannel) {
        this.deviceChannel = deviceChannel;
    }

    public Boolean getIsVisible() {
        return isVisible;
    }

    public void setIsVisible(Boolean isVisible) {
        this.isVisible = isVisible;
    }

    public String getSettingId() {
        return settingId;
    }

    public void setSettingId(String settingId) {
        this.settingId = settingId;
    }

}
