package com.sc.rdc.csl.ss.dal.sg.service;


import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.service.IWealthLendingService;
import com.sc.rdc.csl.ss.dal.sg.config.DozerUtilsSg;
import com.sc.rdc.csl.ss.dal.sg.dao.WealthLendingServiceDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Slf4j
@Service(value = "wealthLendingServiceSg")
public class WealthLendingService extends IWealthLendingService{

    @Qualifier("dozerUtilsSg")
    @Autowired  
    private DozerUtilsSg dozerUtilsSg;
    
    @Qualifier("wealthLendingServiceDaoSg")
    @Autowired
    private WealthLendingServiceDao wealthLendingServiceDao;

    @Transactional(value = "transactionManagerSg", readOnly = true)
    @LogTimeTaken
    public SsBaseDto findWldCustomerDetails(SsCSLUser user)  {
        return  dozerUtilsSg.convertCustomer(wealthLendingServiceDao.findWldCustomerDetails(user));
    }


    

}
