package com.sc.rdc.csl.ss.dal.ae.entity;

import lombok.Data;

import java.util.Date;

@Data
public class UserVO extends BaseVO {

    private static final long serialVersionUID = -1L;

    private String countryCode;

    private String userId;

    private String hashedUserId;

    private String userPassword;

    private String name;

    private String systemType;

    private String statusCode;

    private String isLoggedIn;

    private Date firstLoginDate;

    private Date lastLoginDate;

    private Date lastPasswordChangeDate;

    private Integer loginInvalidCount;

    private Integer loginSuccessCount;
}
