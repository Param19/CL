
package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;

public abstract class IPaymentService {
    public PaymentDto submitPayment(PaymentDto paymentDto) {
        return null;
    }

    public PaymentDto updatePayment(PaymentDto paymentDto) {
        return null;
    }

    public PaymentDto getPayment(String transactionId) {
        return null;
    }
}
