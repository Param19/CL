package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.ICreditCardService;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.COUNTRY_NOT_ALLOWED;

@Component()
@Slf4j
public class CrediCardServiceFactory {

    @Qualifier("creditCardServiceHk")
    @Autowired
    private ICreditCardService creditCardServiceHk;

    @Qualifier("creditCardServiceSg")
    @Autowired
    private ICreditCardService creditCardServiceSg;

    @Qualifier("creditCardServiceIn")
    @Autowired
    private ICreditCardService creditCardServiceIn;

    Map<String, ICreditCardService> map = new HashMap<>();

    public ICreditCardService getCreditCardService(String country)
    {
        if (map.size() == 0)
            initMap();
        ICreditCardService cCardService = map.get(StringUtils.upperCase(country));
        if (cCardService != null)
            return cCardService;
        log.error("Country {} is not allowed to call Credit Card Service", country);
        throw new BusinessException(TemplateErrorCode.create(COUNTRY_NOT_ALLOWED, country, "CUSTOMER"));
    }
    private void initMap() {
        map.put(Constants.HK, creditCardServiceHk);
        map.put(Constants.SG, creditCardServiceSg);
        map.put(Constants.IN, creditCardServiceIn);

    }
}
