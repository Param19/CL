package com.sc.rdc.csl.ss.main.helper;

import java.time.LocalDate;
import java.util.Date;

public class CardUtil {

    private static final String DATE_TIME_FORMAT = "yyyy-MM-dd";

    private static long noOfDaysToFetchTransactions = 30L;

    public static final Date getTransactionStartDate() {
        LocalDate now = LocalDate.now();
        return java.sql.Date.valueOf(now.minusDays(noOfDaysToFetchTransactions));
    }
}
