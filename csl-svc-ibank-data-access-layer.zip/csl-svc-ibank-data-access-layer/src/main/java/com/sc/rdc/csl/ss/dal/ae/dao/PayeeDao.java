package com.sc.rdc.csl.ss.dal.ae.dao;

import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.List;

import javax.persistence.Query;

@Repository(value = "payeeDaoAe")
@Slf4j
public class PayeeDao extends BaseDao {

    public static String GET_ALL_PAYEE = "SELECT o FROM com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity o";
    public static String GET_PAYEE = "SELECT o FROM com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity o WHERE o.payeeId = :payeeId";
    public static String ADD_PAYEE = "INSERT INTO com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity(payee_id, payee_name, nick_name, payee_type, acct_number, acct_type_code, acct_currency, acct_country, institution_name, address1, address2, address3, city, postcode, payee_country, email) VALUES(:payee_id, :payee_name, :nick_name, :payee_type, :acct_number, :acct_type_code, :acct_currency, :acct_country, :institution_name, :address1, :address2, :address3, :city, :postcode, :payee_country, :email)";
    public static String DELETE_PAYEE = "UPDATE com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity SET status_cd=:statuscd WHERE ref_no = :refNo";
    public static String UPDATE_PAYEE = "UPDATE com.sc.rdc.csl.ss.dal.ae.entity.payee.PayeeEntity SET address1=:address1, address2=:address2, address3=:address3, city=:city, postcode=:postcode, email=:email, ref_no=:refNo2 WHERE ref_no = :refNo";

    public PayeeEntity getPayeeDetails(String payeeId) {
        log.info("PayeeId:{}", payeeId);
        log.debug("{}", GET_PAYEE);
        Query query = entityManagerAe.createQuery(GET_PAYEE);
        query.setParameter("payeeId", payeeId);
        PayeeEntity payeeEntity = (PayeeEntity) query.getSingleResult();
        log.info("Payee Record", payeeEntity);

        return payeeEntity;
    }

    public List<PayeeEntity> getAllPayee() {
        Query query = entityManagerAe.createQuery(GET_ALL_PAYEE)
                        .setMaxResults(100)
                        .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        List<PayeeEntity> payeeEntities = query.getResultList();

        return payeeEntities;
    }

    public void addPayee(PayeeEntity payeeEntity) {
        entityManagerAe.persist(payeeEntity);
    }

    public void deletePayee(String payeeId) {
        log.info("PayeeId:{}", payeeId);
        Query query = entityManagerAe.createQuery(DELETE_PAYEE);
        query.setParameter("refNo", payeeId);
        query.setParameter("statuscd", "D");
        query.executeUpdate();
    }

    public void updatePayee(PayeeEntity payeeEntity, String oldPayeeId) {
        //Query query = entityManagerAe.createQuery(UPDATE_PAYEE);
        //query.setParameter("refNo", oldPayeeId);
        //query.setParameter("refNo2",payeeEntity.getRefNo());
        //query.executeUpdate();
        //Cannot insert....TBH monday
       /* payeeEntity.setCreatedDate(new Date());
        payeeEntity.setUpdatedDate(new Date());
        payeeEntity.setUpdatedBy("SYSTEM");
        payeeEntity.setCreatedBy("SYSTEM");
        payeeEntity.setStatusCd("A");
        log.info("Mapped Payee entity:{} ", payeeEntity);
        this.addPayee(payeeEntity);*/
        log.info("PayeeId:{}", payeeEntity.getPayeeId());
        log.info("PayeeEntity update:{}", payeeEntity);
        Query query = entityManagerAe.createQuery(UPDATE_PAYEE);
        query.setParameter("address1", payeeEntity.getAddress1());
        query.setParameter("address2", payeeEntity.getAddress2());
        query.setParameter("address3", payeeEntity.getAddress3());
        query.setParameter("city", payeeEntity.getCity());
        query.setParameter("postcode", payeeEntity.getPostcode());
        query.setParameter("email", payeeEntity.getEmail());
        query.setParameter("refNo2", payeeEntity.getRefNo());
        query.setParameter("refNo", oldPayeeId);
        query.executeUpdate();
    }
}
