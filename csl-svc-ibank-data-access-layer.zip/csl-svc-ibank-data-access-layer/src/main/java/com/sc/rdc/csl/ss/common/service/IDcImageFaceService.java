package com.sc.rdc.csl.ss.common.service;


import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.rdc.csl.ss.common.dto.card.CardFaceDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;

import java.util.List;

public abstract class IDcImageFaceService {

    public List<CardFaceDto> getDcImageFaces(String segmentCd, String ctry) {
        throw new TechnicalException(ErrorConstant.UNSUPPORTED_OPERATION);
    }

}