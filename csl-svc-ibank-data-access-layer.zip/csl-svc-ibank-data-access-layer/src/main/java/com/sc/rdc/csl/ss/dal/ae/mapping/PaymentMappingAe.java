package com.sc.rdc.csl.ss.dal.ae.mapping;

import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import com.sc.rdc.csl.ss.dal.ae.entity.payment.InternationalTransferEntity;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

@Component
public class PaymentMappingAe implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        // Payment
        orikaMapperFactory
                .classMap(InternationalTransferEntity.class, PaymentDto.class)
                .field("transactionId", "transactionId")
                .field("fromAccountCurrencyCode","sourceCurrencyCode")
                .field("toAccountCurrencyCode","transactionCurrencyCode")
                .field("actualTransAmt","amount")
                .field("transactionAmount","sourceAmount")
                .field("debitAmount","sourceAmount")
                .field("exchangeRate","conversionRate")
                .field("transStatusCD","transactionStatus")
                .field("responseCode","hostReasonCode")
                .field("transStatusCD","transactionStatusCode")
                .field("transactionMode","paymentMode")
                .field("transTypeCD","transactionType")
                .byDefault()
                .register();


    }
}

