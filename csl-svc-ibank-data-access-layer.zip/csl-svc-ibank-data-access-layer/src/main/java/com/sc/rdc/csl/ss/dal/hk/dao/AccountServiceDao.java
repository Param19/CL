package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

@Repository(value ="accountServiceDaoHk")
@Slf4j
public class AccountServiceDao extends BaseDao{
    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;
    public List<AccountEntity> getAccountSummary() {
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity a WHERE a.customerId = :customerId")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);

        query.setParameter("customerId", requestContext.getCustomerId());
        List<AccountEntity> accountEntityList = query.getResultList();
        log.info("Received {} AccountSummary record(s) from DB for User Id {}",
                (accountEntityList != null ? accountEntityList.size() : 0), requestContext.getCustomerId());
        if(!(accountEntityList!=null && accountEntityList.size()>0))
            throw new BusinessException(ErrorConstant.CASA_NO_RECORD_EXCEPTION);
        return accountEntityList;
    }

    public AccountEntity getAccountDetails(String accountNo) {
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity a WHERE a.accountNumber = :accountNumber")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);

        query.setParameter("accountNumber", accountNo);
        List<AccountEntity> accountEntityList = query.getResultList();
        if(!(accountEntityList!=null && accountEntityList.size() > 0))
            throw new BusinessException(ErrorConstant.CASA_ACCOUNT_NOT_FOUND);
        return accountEntityList.get(0);
    }

    public List<AccountEntity> getAllAccountDetails(List<String> accountNo) {
        Query query = entityManagerHk.createQuery("select a from com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity a WHERE a.accountNumber in (:accountNumber)")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);

        query.setParameter("accountNumber", accountNo);
        List<AccountEntity> accountEntityList = query.getResultList();
        if(!(accountEntityList!=null && accountEntityList.size() > 0))
            throw new BusinessException(ErrorConstant.CASA_ACCOUNT_NOT_FOUND);
        return accountEntityList;
    }
}
