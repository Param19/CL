package com.sc.rdc.csl.ss.dal.cn.entity.payment;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class InternationalTransferPaymentEntity extends PaymentEntity {

	private static final long serialVersionUID = 1L;
	private String applicationId;
	private String transactionId;
	private Date transferDate;
	private String fromAccountNumber;
	private String toAccountNumber;
	private String transactionStatus;
	private String transactionType;
	private String currencyCode;
	private String countryCode;
	private BigDecimal  amount;
	private String chargedAccount;
	private String customerId;
	private String customerIdType;
	private String customerEBID;
	private String payeeName;

}
