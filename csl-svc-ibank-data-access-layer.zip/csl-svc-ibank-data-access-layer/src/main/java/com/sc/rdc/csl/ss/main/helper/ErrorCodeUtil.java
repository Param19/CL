package com.sc.rdc.csl.ss.main.helper;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.main.dto.ErrorDto;
import com.sc.rdc.csl.ss.main.dto.RestErrorDto;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import io.katharsis.repository.response.HttpStatus;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class ErrorCodeUtil {
    
    private final static String config = "business-errormap.properties";
    
    @Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;

    public  SsBaseDto prepareRecUpdResponse(String extendedCode,SsBaseDto ssBaseDto, int noOfRecord) {
      ErrorDto errorDto = new ErrorDto();
      errorDto.setId(cslRequestContext.getRequestId());
      errorDto.setStatus(String.valueOf(HttpStatus.OK_200));
      String value = ConfigurationManager.getProperty(config, extendedCode);
      String[] errorArray = StringUtils.split(value, SsConstant.PAD_COMMA);
      errorDto.setTitle(errorArray[0]);
      errorDto.setCode(errorArray[1]);
      errorDto.setDetail(String.valueOf(noOfRecord)+" "+errorArray[2]);
      List<ErrorDto> list = new ArrayList<>(1);
      list.add(errorDto);
      return new RestErrorDto(list);
    }
    
    public  SsBaseDto prepareResponseByCode(String extendedCode,SsBaseDto ssBaseDto) {
      ErrorDto errorDto = new ErrorDto();
      errorDto.setId(cslRequestContext.getRequestId());
      errorDto.setStatus(String.valueOf(HttpStatus.OK_200));
      String value = ConfigurationManager.getProperty(config, extendedCode);
      String[] errorArray = StringUtils.split(value, SsConstant.PAD_COMMA);
      errorDto.setTitle(errorArray[0]);
      errorDto.setCode(errorArray[1]);
      errorDto.setDetail(errorArray[2]);
      List<ErrorDto> list = new ArrayList<>(1);
      list.add(errorDto);
      return new RestErrorDto(list);
    }
}
