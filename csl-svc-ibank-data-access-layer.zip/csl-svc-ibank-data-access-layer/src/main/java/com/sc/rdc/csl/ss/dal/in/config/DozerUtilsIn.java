package com.sc.rdc.csl.ss.dal.in.config;


import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.dal.in.entity.CustomerEntity;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class DozerUtilsIn {
    	
    
    @Qualifier("dozerBeanMapperIn")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    public Profile convertCustomer(Profile profile, CustomerEntity customerEntity,String mapId)  {
        if (customerEntity== null || profile==null) {
            return null;
        }
        
        dozerBeanMapper.map(customerEntity, profile,mapId);
        return profile;
    }
    
    
       
    
}
