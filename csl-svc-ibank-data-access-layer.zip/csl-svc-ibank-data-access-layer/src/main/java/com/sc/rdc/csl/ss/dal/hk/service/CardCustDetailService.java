package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.card.CardCustDto;
import com.sc.rdc.csl.ss.common.service.CardCustService;
import com.sc.rdc.csl.ss.dal.hk.dao.CardCustDao;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service(value = "cardCustServiceHK")
public class CardCustDetailService extends CardCustService {


    @Qualifier("cardCustServiceDaoHk")
    @Autowired
    private CardCustDao cardCustDao;

    @Autowired
    private MapperFacade orikaMapperFacade;

    @Override
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public CardCustDto getCardCust(CardCustDto cardCustDto) {
        CardCustDto customerIdDto_data = cardCustDao.getCardDetails(cardCustDto);
        return customerIdDto_data;
    }
    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public List<CardCustDto> getCardList(CardCustDto cardCustDto) {
        return orikaMapperFacade.mapAsList(cardCustDao.getCardList(cardCustDto), CardCustDto.class);
    }
}
