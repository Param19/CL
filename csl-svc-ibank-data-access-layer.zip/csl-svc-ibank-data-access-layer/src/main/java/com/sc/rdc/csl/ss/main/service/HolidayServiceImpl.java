
package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.dto.holiday.HolidayDto;
import com.sc.rdc.csl.ss.common.service.IHolidayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("holidayServiceImpl")
public class HolidayServiceImpl extends IHolidayService{
    
    //private static final String SERVICE="HolidayService";

    @Autowired
    private HolidayServiceFactory holidayServiceFactory;

    @Override
    public List<HolidayDto> getHolidaySummary()  {
        return holidayServiceFactory.getHolidayService().getHolidaySummary();
    }
}
