package com.sc.rdc.csl.ss.common.mapping;

import com.sc.rdc.csl.ss.common.dto.customer.IVRInfo;
import ma.glasnost.orika.MapperFactory;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

/**
 * @author Sivaprakasam, Balaji (1347884)
 */
@Component
public class IVRInfoMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {

        orikaMapperFactory
                .classMap(IVRInfo.class, com.sc.rdc.csl.ss.dal.hk.entity.customer.IVRInfoEntity.class)
                .field("mobile","mobile")
                .field("country", "country")
                .field("name", "name")
                .field("segment", "segment")
                .field("gender", "gender")
                .field("armcode", "armcode")
                .field("lang", "lang")
                .field("customerId", "customerId")
                .field("customerIdType","customerIdType")
                .field("datetime","datetime")
                .mapNulls(false).byDefault().register();

        orikaMapperFactory
                .classMap(IVRInfo.class, com.sc.rdc.csl.ss.dal.ae.entity.customer.IVRInfoEntity.class)
                .field("mobile","mobile")
                .field("country", "country")
                .field("name", "name")
                .field("segment", "segment")
                .field("gender", "gender")
                .field("armcode", "armcode")
                .field("lang", "lang")
                .field("customerId", "customerId")
                .field("customerIdType","customerIdType")
                .field("datetime","datetime")
                .mapNulls(false).byDefault().register();

        orikaMapperFactory
                .classMap(IVRInfo.class, com.sc.rdc.csl.ss.dal.in.entity.customer.IVRInfoEntity.class)
                .field("mobile","mobile")
                .field("country", "country")
                .field("name", "name")
                .field("segment", "segment")
                .field("gender", "gender")
                .field("armcode", "armcode")
                .field("lang", "lang")
                .field("customerId", "customerId")
                .field("customerIdType","customerIdType")
                .field("datetime","datetime")
                .mapNulls(false).byDefault().register();

        orikaMapperFactory
                .classMap(IVRInfo.class, com.sc.rdc.csl.ss.dal.sg.entity.customer.IVRInfoEntity.class)
                .field("mobile","mobile")
                .field("country", "country")
                .field("name", "name")
                .field("segment", "segment")
                .field("gender", "gender")
                .field("armcode", "armcode")
                .field("lang", "lang")
                .field("customerId", "customerId")
                .field("customerIdType","customerIdType")
                .field("datetime","datetime")
                .mapNulls(false).byDefault().register();

        orikaMapperFactory
                .classMap(IVRInfo.class, com.sc.rdc.csl.ss.dal.my.entity.customer.IVRInfoEntity.class)
                .field("mobile","mobile")
                .field("country", "country")
                .field("name", "name")
                .field("segment", "segment")
                .field("gender", "gender")
                .field("armcode", "armcode")
                .field("lang", "lang")
                .field("customerId", "customerId")
                .field("customerIdType","customerIdType")
                .field("datetime","datetime")
                .mapNulls(false).byDefault().register();
    }


}
