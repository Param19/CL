package com.sc.rdc.csl.ss.dal.pk.service;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.SS_NO_PAYMENT;

import java.util.Date;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import com.sc.rdc.csl.ss.common.service.IPaymentService;
import com.sc.rdc.csl.ss.dal.af.entity.QrCodePayment;
import com.sc.rdc.csl.ss.dal.pk.dao.PaymentServiceDao;

@Slf4j
@Service("paymentServicePk")
public class PaymentService extends IPaymentService {
	
	@Autowired
    @Qualifier("paymentServiceDaoPk")
    private PaymentServiceDao paymentServiceDao;
	
	@Autowired
    @Qualifier("cslRequestContext")
    private CSLRequestContext cslRequestContext;
	
	@Autowired
    private MapperFacade orikaMapperFacade;
    
    @Transactional("transactionManagerPk")
    @Override
    @LogTimeTaken
    public  PaymentDto updatePayment(PaymentDto paymentDto){
        
        log.info("Update Payment for Payment Id {}, PaymentDto {}", paymentDto.getPaymentId(), paymentDto);
        QrCodePayment entity = paymentServiceDao.getPayment(paymentDto.getPaymentId());
        if(entity!=null) {
            entity.setPaymentstatus(paymentDto.getPaymentStatus());
            entity.setUpdatedDate(new Date());
            entity = paymentServiceDao.updatePayment(entity);
            log.info("Service - Update Payment completed ");
            return getPaymentDto(entity);
        } else
            throw new BusinessException(SS_NO_PAYMENT);
    }
    
    
    private PaymentDto getPaymentDto(QrCodePayment entity) {
        PaymentDto responseDto = orikaMapperFacade.map(entity, PaymentDto.class);
        return responseDto;
    }
    
	
	
}
