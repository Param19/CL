package com.sc.rdc.csl.ss.dal.hk.dao.card;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.dal.hk.dao.BaseDao;
import com.sc.rdc.csl.ss.dal.hk.entity.card.CardTxnHistoryEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.TypedQuery;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Repository(value = "creditCardTxnServiceDaoHk")
@Slf4j
public class CreditCardTransactionDao extends BaseDao  {
    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<CardTxnHistoryEntity> getCardTransactionHistory(Date fromDate, String cardNo) {
        TypedQuery<CardTxnHistoryEntity> query = null;
        query = entityManagerHk.createQuery("select a from CardTxnHistoryEntity a where cardNum= :cardNum and txnPostDate > :txnPostDate order by txnPostDate desc",CardTxnHistoryEntity.class);
        query.setParameter("txnPostDate", fromDate);
        query.setParameter("cardNum", cardNo);
        List<CardTxnHistoryEntity> transactionHistoryList = query.getResultList();
        return transactionHistoryList;
    }

    public List<CardTxnHistoryEntity> getCardTransactionHistory(List<String> cardNos , String fromDate,String toDate) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = format.parse(fromDate);
        Date endDate  = format.parse(toDate);
        TypedQuery<CardTxnHistoryEntity> query = null;
        query = entityManagerHk.createQuery("select a from CardTxnHistoryEntity a where cardNum in ( :cardNum ) and txnPostDate between :startDate and :endDate order by txnPostDate desc",CardTxnHistoryEntity.class);
        query.setParameter("startDate", startDate);
        query.setParameter("endDate", endDate);
        query.setParameter("cardNum", cardNos);
        List<CardTxnHistoryEntity> transactionHistoryList = query.getResultList();
        return transactionHistoryList;
    }
}
