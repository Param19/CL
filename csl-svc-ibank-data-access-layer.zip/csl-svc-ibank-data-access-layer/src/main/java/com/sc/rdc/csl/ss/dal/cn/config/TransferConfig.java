package com.sc.rdc.csl.ss.dal.cn.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * @author Sankar, Vinnakota (1546088)
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "transfer")
public class TransferConfig {
    private Map<String, String> prefixTxnId;

}
