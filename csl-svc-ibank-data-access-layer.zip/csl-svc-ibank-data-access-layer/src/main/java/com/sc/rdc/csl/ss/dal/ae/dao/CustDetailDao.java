package com.sc.rdc.csl.ss.dal.ae.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO;
import com.sc.rdc.csl.ss.dal.ae.entity.customer.CustomerDetailEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.CUSTOMER_NO_RECORD_EXCEPTION;

@Repository(value = "custDetailDaoAe")
@Slf4j
public class CustDetailDao extends BaseDao {

    public static String GET_CUSTOMER_DETAIL = "select o from com.sc.rdc.csl.ss.dal.ae.entity.CustomerVO o WHERE o.customerId = :customerId";
    public static String GET_ALL_CUSTOMERS = "SELECT o FROM com.sc.rdc.csl.ss.dal.ae.entity.customer.CustomerDetailEntity o";
    public static String GET_ONE_CUSTOMER = "select o from com.sc.rdc.csl.ss.dal.ae.entity.customer.CustomerDetailEntity o WHERE o.customerId = :customerId";
    public CustomerVO getCustomerDetails(String customerId) {

        log.info("CustomerId:{}", customerId);
        Query query = entityManagerAe.createQuery(GET_CUSTOMER_DETAIL);
        query.setParameter("customerId", customerId);
        CustomerVO custDetailEntity = (CustomerVO)query.getSingleResult();
        log.info("customerdetails Record", custDetailEntity);
       if(custDetailEntity == null)
        {
            throw new BusinessException(CUSTOMER_NO_RECORD_EXCEPTION);
        }

        return custDetailEntity;
    }

    public List<CustomerDetailEntity> getAllCustomers() {
        Query query = entityManagerAe.createQuery(GET_ALL_CUSTOMERS)
                .setMaxResults(100)
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        List<CustomerDetailEntity> customerDetailEntities = query.getResultList();

        return customerDetailEntities;
    }

    public CustomerDetailEntity getOneCustomer(String customerId) {
        log.info("CustomerId:{}", customerId);
        Query query = entityManagerAe.createQuery(GET_ONE_CUSTOMER);

        query.setParameter("customerId", customerId);
        CustomerDetailEntity custDetailEntity = (CustomerDetailEntity)query.getSingleResult();
        log.info("customerdetails Record", custDetailEntity);
        if(custDetailEntity == null)
        {
            throw new BusinessException(CUSTOMER_NO_RECORD_EXCEPTION);
        }

        return custDetailEntity;
    }
}
