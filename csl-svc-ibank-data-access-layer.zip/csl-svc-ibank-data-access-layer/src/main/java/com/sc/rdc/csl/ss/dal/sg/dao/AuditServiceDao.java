package com.sc.rdc.csl.ss.dal.sg.dao;

import org.springframework.stereotype.Repository;

import com.sc.rdc.csl.ss.dal.sg.entity.AuditEntity;

import lombok.extern.slf4j.Slf4j;

@Repository(value = "auditServiceDaoSg")
@Slf4j
public class AuditServiceDao extends BaseDao {

	public AuditEntity auditTransaction(AuditEntity auditEntity){
		log.info("call AuditServiceDao : auditTransaction SG");
		entityManagerSg.merge(auditEntity);
		log.info("call AuditServiceDao : auditTransaction done");
		return auditEntity;
	}
}
