
package com.sc.rdc.csl.ss.dal.ae.dao;

import com.sc.rdc.csl.ss.dal.ae.entity.FilterProductEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;
import java.util.Set;

@Repository(value = "productServiceDaoAe")
@Slf4j
public class ProductServiceDao extends BaseDao {

    private static final String FILTER_PRODUCT_QUERY = "select f from com.sc.rdc.csl.ss.dal.ae.entity.FilterProductEntity f where f.productKey IN (:productKey) and f.countryCode = :countryCode";

    public List<FilterProductEntity> getFilterProduct(Set<String> accountCodeList, String countryCode) {
        Query query = entityManagerAe.createQuery(FILTER_PRODUCT_QUERY);
        query.setParameter("productKey", accountCodeList);
        query.setParameter("countryCode", countryCode);
        log.info("query {}", query);
        try {
            return (List<FilterProductEntity>) query.getResultList();
        } catch (javax.persistence.NoResultException e) {
            log.warn("No record found in FilterProductEntity for AccountCode:{} & lang:{}", accountCodeList, countryCode);
            return null;
        }
    }

}
