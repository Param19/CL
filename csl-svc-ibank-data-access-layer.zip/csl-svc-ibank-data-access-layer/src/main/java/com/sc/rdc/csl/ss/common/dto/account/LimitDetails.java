package com.sc.rdc.csl.ss.common.dto.account;

import com.fasterxml.jackson.annotation.JsonInclude;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;
import lombok.Data;

@Data
@XmlType(name = "limitDetails")
@XmlAccessorType(XmlAccessType.FIELD)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LimitDetails {
    private BigDecimal limitAmount;
    private String odClass;
}

