package com.sc.rdc.csl.ss.dal.hk.config;

import lombok.Getter;
import lombok.Setter;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Qualifier;

@Configuration
public class SsDozerConfigHk {

        
	@Bean("dozerMappingFilesHk")
	public DozerMappingFilesHk dozerMappingFiles() {
		return new DozerMappingFilesHk();
	}


        @Qualifier("dozerBeanMapperHk")
	@Bean("dozerBeanMapperHk")
	public DozerBeanMapper dozerBeanMapperHk( DozerMappingFilesHk dozerMappingFiles) {
		dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/hk/dozer/wealth-lending-mappings.xml");
		dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/hk/dozer/data-product-mapping.xml");
	        dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/hk/dozer/data-personalization-mapping.xml");
			dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/hk/dozer/mail-service-mappings.xml");
			dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/hk/dozer/customer-profile-mappings.xml");
                return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
	}

	@Setter
	@Getter
	private class DozerMappingFilesHk {
 		private List<String> mappingFiles = new ArrayList<>();
	}
        
        
}
