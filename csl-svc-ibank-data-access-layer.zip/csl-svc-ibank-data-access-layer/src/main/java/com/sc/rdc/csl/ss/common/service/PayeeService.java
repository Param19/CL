package com.sc.rdc.csl.ss.common.service;

import com.sc.rdc.csl.ss.common.dto.payee.PayeeDto;

import java.util.List;

public abstract class PayeeService {
    public void addPayee(PayeeDto payeeDto) { return; }

    public void updatePayee(PayeeDto payeeDto) {  }

    public void deletePayee(String id) {  }

    public PayeeDto getPayee(String payeeId) { return null; }

    public List<PayeeDto> getAllPayees() { return null; }


}
