package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.CardCustService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.COUNTRY_NOT_ALLOWED;

@Component()
@Slf4j
public class CardCustServiceFactory {

    @Qualifier("cardCustServiceHK")
    @Autowired
    private CardCustService cardCustServiceHK;

    Map<String, CardCustService> map = new HashMap<>();


    public CardCustService getCardCust(String country) {
        if (map.size() == 0)
            initMap();
        CardCustService cardCustService = map.get(StringUtils.upperCase(country));
        if (cardCustService != null)
            return cardCustService;
        log.error("Country {} is not allowed to call Card Customer Service", country);
        throw new BusinessException(TemplateErrorCode.create(COUNTRY_NOT_ALLOWED, country, "CUSTOMER"));

    }

    private void initMap() {
        map.put(Constants.HK, cardCustServiceHK);

    }
}
