package com.sc.rdc.csl.ss.dal.cn.entity;


import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Data
@Entity
@Table(name = "TBL_CUST", schema = "SCBCIF")
public class ProfileEntity {

    @Id
    @Column(name = "CUST_ID")
    private String customerId;

    @Column(name = "CUST_EBID")
    private String customerEBID;

    @Column(name = "CUST_PBID")
    private String customerPBID;

    @Column(name = "CUST_ID_TYP_CD")
    private String customerIdType;

    @Column(name = "CUST_NM_1")
    private String custName1;

    @Column(name = "CUST_NM_2")
    private String custName2;

    @Column(name = "CUST_NICKNAME")
    private String custNickName;

    @Column(name = "CUST_ADDR_1")
    private String mailAddr1;

    @Column(name = "CUST_ADDR_2")
    private String mailAddr2;

    @Column(name = "CUST_ADDR_3")
    private String mailAddr3;

    @Column(name = "CUST_ADDR_4")
    private String mailAddr4;

    @Column(name = "CUST_DISTRICT")
    private String mailDistrict;

    @Column(name = "CUST_AREA")
    private String area;

    @Column(name = "CUST_POSTAL_CODE")
    private String postalCode;

    @Column(name = "CUST_CTRY_CD")
    private String country;

    @Column(name = "CUST_RESIDENCE_CD")
    private String residenceCode;

    @Column(name = "CUST_NATIONALITY_CD")
    private String nationalityCode;

    @Column(name = "CUST_NATION_ID")
    private String nationId;

    @Column(name = "CUST_STATUS_CD")
    private String statusCode;

    @Column(name = "DT_CUST_OPEN")
    private String openDate;

    @Column(name = "CUST_BR_CD")
    private String branchCode;

    @Column(name = "CUST_ARM")
    private String armCode;

    @Column(name = "CUST_PBO")
    private String pbo;

    @Column(name = "CUST_OPB_MRKSEG")
    private String opbMarketingSegment;

    @Column(name = "CUST_SEX")
    private String gender;

    @Column(name = "DT_DATE_OF_BIRTH")
    private Date dob;

    @Column(name = "CUST_MARITAL_STS_CD")
    private String maritalStatusCode;

    @Column(name = "CUST_ETHNIC")
    private String ethnic;

    @Column(name = "CUST_STAFF_RANK")
    private String staffRank;

    @Column(name = "CUST_PERSONAL_PHONE")
    private String personalPhone;

    @Column(name = "CUST_PERSONAL_PH_EXT")
    private String personalPhoneExt;

    @Column(name = "CUST_BUS_PHONE")
    private String businessPhone;

    @Column(name = "CUST_BUS_PH_EXT")
    private String businessPhoneExt;

    @Column(name = "CUST_MOBILE_CO")
    private String mobileCompany;

    @Column(name = "CUST_MOBILE_PHONE")
    private String mobilePhone;

    @Column(name = "CUST_MOBILE_PH_BOA")
    private String mobilePhoneBOA;

    @Column(name = "CUST_DAILY_LMT")
    private Double dailyLimit;

    @Column(name = "CUST_EMPLOYER")
    private String employerFlag;

    @Column(name = "CUST_SCB_IND")
    private String scbIndicator;

    @Column(name = "CUST_PAY_IND")
    private String payIndicator;

    @Column(name = "CUST_EMAIL_ADDR")
    private String emailAddress;

    @Column(name = "IS_COPP")
    private Boolean isCOPP;

    @Column(name = "DT_LAST_COPP")
    private String dateLastCOPP;

    @Column(name = "REMARK")
    private String remark;

    @Column(name = "REL_TYP")
    private String segmentCode;

    @Column(name = "REL_SUB_TYP")
    private String subSegmentCode;

    @Column(name = "CUST_MM_STATUS")
    private String mmStatus;

    @Column(name = "CUST_MM_MAIL_CODE")
    private String mmMailCode;

    @Column(name = "CUST_PB_HM")
    private String pbHoldMailFlag;

    @Column(name = "DT_CREATED")
    private Date createdDate;
}
