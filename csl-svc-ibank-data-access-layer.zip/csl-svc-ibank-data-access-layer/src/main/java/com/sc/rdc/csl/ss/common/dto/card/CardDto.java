package com.sc.rdc.csl.ss.common.dto.card;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Setter
@Getter

@EqualsAndHashCode(callSuper = true)
@JsonApiResource(type = "credit-cards-info")
public class CardDto extends ProductDto implements Serializable{

    @JsonApiId
    private String uuid = UUID.randomUUID().toString();
    @JsonProperty("id")
    private Long id;
    @JsonProperty("customer-number")
    private String customerNumber;
    @JsonProperty("org-code")
    private String orgCode;
    @JsonProperty("card-type")
    private String cardType;
    @JsonProperty("exp-dt")
    private String expDt;
    @JsonProperty("source-code")
    private String sourceCode;
    @JsonProperty("statement-flag")
    private String statementFlag;
    @JsonProperty("past-due-flag")
    private String pastDueFlag;					//paymentDueDateStatus
    @JsonProperty("opened-date")
    private Date openedDate;
    @JsonProperty("bill-due-date")
    private Date billDueDate;
    @JsonProperty("last-bill-date")
    private Date lastBillDate;
    //lastStmtBalAmount
    @JsonProperty("last-payment-date")
    private Date lastPaymentDate;
    @JsonProperty("credit-limit")
    private BigDecimal creditLimit;
    @JsonProperty("local-credit-limit")
    private BigDecimal localCreditLimit;
    @JsonProperty("available-limit")
    private BigDecimal availableLimit;
    @JsonProperty("current-min-due")
    private BigDecimal currentMinDue;
    @JsonProperty("minimum-payment")
    private BigDecimal minimumPayment;
    @JsonProperty("local-minimum-payment")
    private BigDecimal localMinimumPayment;
    @JsonProperty("last-bill-amount")
    private BigDecimal lastBillAmount;
    @JsonProperty("local-last-bill-amount")
    private BigDecimal localLastBillAmount;
    @JsonProperty("last-payment-amount")
    private BigDecimal lastPaymentAmount;
    @JsonProperty("total-amount-due")
    private BigDecimal totalAmountDue;
    @JsonProperty("last-stmt-bal-amount")
    private BigDecimal lastStmtBalAmount;
    @JsonProperty("outstanding-amount")
    private BigDecimal outstandingAmount;

    @JsonProperty("combined-limit-indicator")
    private Boolean combinedLimitIndicator;
    @JsonProperty("local-current-balance")
    private BigDecimal localCurrentBalance;
    @JsonProperty("conversion-rate")
    private BigDecimal conversionRate;    //    private CardLimitDto cardLimitDto;
    @JsonProperty("is-ATM-combo-card")
    private Boolean isATMComboCard = false;

    @JsonProperty("customer-id")
    private String customerId;
    @JsonProperty("updated-date")
    private Date updatedDate;
    @JsonProperty("updated-by")
    private String updatedBy;

    @JsonProperty("cardtransactions")
    @JsonApiRelation(lookUp = LookupIncludeBehavior.AUTOMATICALLY_WHEN_NULL,opposite = "creditCardDto")
    private List<CreditCardTransactionDto> cardtransactions;

}
