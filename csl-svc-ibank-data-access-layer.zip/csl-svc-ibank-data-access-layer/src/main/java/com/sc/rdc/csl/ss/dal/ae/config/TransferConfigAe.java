package com.sc.rdc.csl.ss.dal.ae.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Data
@Configuration
@ConfigurationProperties(prefix = "transfers")
public class TransferConfigAe {
    private Map<String, String> prefixTxnId;

}
