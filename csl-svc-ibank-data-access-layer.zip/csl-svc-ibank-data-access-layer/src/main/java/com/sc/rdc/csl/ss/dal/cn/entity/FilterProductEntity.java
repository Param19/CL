package com.sc.rdc.csl.ss.dal.cn.entity;


import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.util.Date;

@Data
public class FilterProductEntity extends BaseDto {
    private static final long serialVersionUID = -1L;

    private String accountCode;
    private String productCode;
    private String productDescription;
    private String subProductCode;
    private String accountGroup;
    private String accountType;
    private String accountTypeAlias;
    private Date createdDate;
    private Date updatedDate;
    private String updatedBy;
    private Boolean isAccountDisplayable;
    private Boolean isFTCR;
    private Boolean isFTDR;
    private String lang;

}
