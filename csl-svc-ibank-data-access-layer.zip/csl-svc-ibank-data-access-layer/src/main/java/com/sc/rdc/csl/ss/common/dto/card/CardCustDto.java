package com.sc.rdc.csl.ss.common.dto.card;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

import java.io.Serializable;

@Data

@JsonApiResource(type = "card-customer")
public class CardCustDto extends SsBaseDto implements Serializable {

    @JsonApiId
    private String cardNo;

    @JsonProperty("credit-card-no")
    private String creditCardNo;

    @JsonProperty("customer-id")
    private String customerId;

    @JsonProperty("customer-id-type")
    private String customerIdType;

    @JsonProperty("customer-id-no")
    private String customerIdNo;


}
