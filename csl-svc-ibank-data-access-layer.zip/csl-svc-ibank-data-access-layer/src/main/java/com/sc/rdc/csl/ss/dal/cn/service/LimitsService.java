package com.sc.rdc.csl.ss.dal.cn.service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.limit.TransactionLimit;
import com.sc.rdc.csl.ss.common.service.TransactionLimitBaseService;
import com.sc.rdc.csl.ss.dal.cn.dao.CustomerServiceDao;
import com.sc.rdc.csl.ss.dal.cn.dao.DailyTxnDao;
import com.sc.rdc.csl.ss.dal.cn.dao.LimitsDao;
import com.sc.rdc.csl.ss.dal.cn.entity.DailyTxnEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.LimitsEntity;
import com.sc.rdc.csl.ss.dal.cn.entity.customer.CustomerProfileEntity;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.sc.rdc.csl.ss.common.helper.Constants.transactionCodes;
import static com.sc.rdc.csl.ss.dal.cn.config.LimitsConstant.*;
/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Slf4j
@Service("transactionLimitServiceCN")
public class LimitsService extends TransactionLimitBaseService {

    @Autowired
    @Qualifier("dailyTxnDaoCN")
    private DailyTxnDao dailyTxnDao;

    @Autowired
    @Qualifier("fxRateServiceCN")
    private FXRateService fxRateService;

    @Autowired
    @Qualifier("limitsDaoCN")
    private LimitsDao limitsDao;

    @Autowired
    @Qualifier("customerServiceDaoCn")
    private CustomerServiceDao customerServiceDao;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    private MapperFacade orikaMapper;

    public List<TransactionLimit> getTransactionLimits(String txnType) {
        CustomerProfileEntity profileEntity = customerServiceDao.getCustomerProfile(cslRequestContext.getRelId());
        List<String> dailyTxnList = dailyTxnDao.getTransactionAmountByDate(cslRequestContext.getRelId(), OVERALL_INTRDAY_LIMIT,
                transactionCodes.get(txnType), new Date());
        List<TransactionLimit> transactionLimits = new ArrayList<>();
        List<LimitsEntity> limitsEntityList = limitsDao.getAllLimits(LIMIT_TYPES, profileEntity.getRelTyp(), cslRequestContext.getCountry());
        Map<String, BigDecimal> limitMap = limitsEntityList.stream()
                .filter(isValidCategory(transactionCodes.get(txnType)))
                .collect(Collectors.toMap(LimitsEntity::getCategory, LimitsEntity::getDefLimit));

        calculateTotalTxnAmount(dailyTxnList, OVERALL_INTRDAY_LIMIT, transactionLimits, limitMap);

        List<String> dailyTxnCDILList = dailyTxnDao.getTransactionAmountByDate(cslRequestContext.getRelId(), CUSTOMER_DAILY_LIMIT,
                transactionCodes.get(txnType), new Date());
        BigDecimal defAmount = limitsDao.getCustomerDefaultLimit(profileEntity.getCustomerEBID(), transactionCodes.get(txnType), profileEntity.getRelTyp());

        limitMap.put(CUSTOMER_DAILY_LIMIT, defAmount);
        calculateTotalTxnAmount(dailyTxnCDILList, CUSTOMER_DAILY_LIMIT, transactionLimits, limitMap);
        transactionLimits.forEach(transactionLimit -> transactionLimit.setTransactionType(txnType));
        return transactionLimits;
    }

    public void calculateTotalTxnAmount(List<String> dailyTxnList, String limitType, List<TransactionLimit> limitsList, Map<String, BigDecimal> limitMap) {
        BigDecimal totalFCYTxnAmount;
        BigDecimal totalTxnAmount;
        List<DailyTxnEntity> dailyTxnEntityList = dailyTxnList.stream()
                .map(s -> s.split(HYPHEN))
                .map(a -> new DailyTxnEntity(a[0], new BigDecimal(a[1])))
                .collect(Collectors.toList());
        dailyTxnEntityList.stream().forEach(x -> calculateTransAmount(x));

        totalFCYTxnAmount = dailyTxnEntityList.stream()
                .filter(x -> !(LOCAL_CURRENCY.equalsIgnoreCase(x.getCurr())))
                .map(DailyTxnEntity::getTotAmt)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        totalTxnAmount = dailyTxnEntityList.stream()
                .map(DailyTxnEntity::getTotAmt)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        if (CUSTOMER_DAILY_LIMIT.equals(limitType)) {
            limitsList.add(populateLimits(CUSTOMER_DAILY_LIMIT, limitMap.get(CUSTOMER_DAILY_LIMIT), totalTxnAmount));
            limitsList.add(populateLimits(DAILY_TRANS_LIMIT, limitMap.get(DAILY_TRANS_LIMIT), totalTxnAmount));
        } else {
            limitsList.add(populateLimits(PER_TRANS_LIMIT, limitMap.get(PER_TRANS_LIMIT), new BigDecimal(0)));
            limitsList.add(populateLimits(OVERALL_INTRDAY_LIMIT, limitMap.get(OVERALL_INTRDAY_LIMIT), totalTxnAmount));
            limitsList.add(populateLimits(INTRADAY_DAILY_LIMIT, limitMap.get(INTRADAY_DAILY_LIMIT), totalFCYTxnAmount));
        }
    }

    public static Predicate<LimitsEntity> isValidCategory(String txnType) {
        return (p -> txnType.equals(p.getTransactionType())
                || p.getCategory().equals(INTRADAY_DAILY_LIMIT) || p.getCategory().equals(OVERALL_INTRDAY_LIMIT));
    }

    public TransactionLimit populateLimits(String limitType, BigDecimal limitAmount, BigDecimal usedAmount) {
        TransactionLimit limits = new TransactionLimit();
        limits.setLimitType(limitType);
        limits.setLimitAmount(limitAmount);
        limits.setUsedAmount(usedAmount);
        return limits;
    }

    public void calculateTransAmount(DailyTxnEntity dailyTxnEntity) {
        BigDecimal lcyAmount = fxRateService.getLCYAmount(dailyTxnEntity.getCurr(), dailyTxnEntity.getTotAmt());
        dailyTxnEntity.setTotAmt(lcyAmount);
    }

}
