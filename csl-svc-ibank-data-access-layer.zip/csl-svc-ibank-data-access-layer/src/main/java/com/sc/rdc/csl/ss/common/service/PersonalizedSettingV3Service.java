package com.sc.rdc.csl.ss.common.service;


import com.sc.rdc.csl.ss.common.dto.customer.PersonalizedSettingsV3Summary;

public abstract class PersonalizedSettingV3Service {

    public PersonalizedSettingsV3Summary getPersonalizedAccountSummary(PersonalizedSettingsV3Summary personalizedSettingsV3Summary) {
        return null;
    }

}
