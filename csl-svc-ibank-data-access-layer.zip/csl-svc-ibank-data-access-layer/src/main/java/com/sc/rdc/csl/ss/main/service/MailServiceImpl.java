package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import com.sc.rdc.csl.ss.main.helper.ErrorCodeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("mailServiceImpl")
@Slf4j
public class MailServiceImpl extends MailService {

    @Autowired
    private ErrorCodeUtil errorCodeUtil;

    @Autowired
    private MailServiceFactory mailServiceFactory;

    @Override
    public SsBaseDto submitMailData(MailServiceEntityDto mailServiceEntityDto, SsCSLUser user) {

        SsBaseDto mailDto = mailServiceFactory.getMailService().submitMailData(mailServiceEntityDto, user);
        if (mailDto == null) {
            return errorCodeUtil.prepareResponseByCode(ErrorConstant.CUSTOMER_DETAILS_NOT_FOUND.name(), new SsBaseDto());
        }
        return mailDto;
    }

}
