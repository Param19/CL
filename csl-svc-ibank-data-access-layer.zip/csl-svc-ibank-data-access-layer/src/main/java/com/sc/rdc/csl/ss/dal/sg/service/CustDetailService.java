package com.sc.rdc.csl.ss.dal.sg.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerContact;
import com.sc.rdc.csl.ss.common.service.CustomerDetailService;
import com.sc.rdc.csl.ss.dal.sg.dao.CustDetailDao;
import com.sc.rdc.csl.ss.dal.sg.entity.ProfileEntity;

import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service(value = "custDetailServiceSG")
public class CustDetailService extends CustomerDetailService {


    @Qualifier("custDetailDaoSG")
    @Autowired
    private CustDetailDao custDetailDao;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Transactional(value = "transactionManagerSg", readOnly = true)
    @LogTimeTaken
    public CustomerContact getCustomerContact(String countryCode,String customerId) {
        log.info("CustDetailService getCustomerContact() ");
        ProfileEntity cusrDetailEntity = custDetailDao.getCustomerDetail(customerId);
        log.info("CustomerDetailEntity :: {} ",cusrDetailEntity);
        if(cusrDetailEntity!=null) {
            CustomerContact custContact = new CustomerContact();
            custContact.setContactDetails(cusrDetailEntity.getMobilePhone());
            custContact.setContactTypeCode("MF1");
            custContact.setRelId(cslRequestContext.getRelId());
            return custContact;
        }
        return null;
    }
}