package com.sc.rdc.csl.ss.common.dto.wld;

import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by 1569433 on 7/28/2017.
 */
@Data
@Getter
@Setter
public class MailDto extends SsBaseDto {


        private String id;
        private String details;
        private String status;


}
