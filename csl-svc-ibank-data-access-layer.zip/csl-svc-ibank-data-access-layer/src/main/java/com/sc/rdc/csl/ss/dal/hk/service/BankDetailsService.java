package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.bank.BankDetailsDto;
import com.sc.rdc.csl.ss.dal.hk.dao.BankDetailDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service(value = "bankDetailServiceHK")
public class BankDetailsService extends com.sc.rdc.csl.ss.common.service.BankDetailService {

    @Qualifier("bankDetailServiceDaoHk")
    @Autowired
    private BankDetailDao bankDetailDao;

    @Transactional(value = "transactionManagerHk", readOnly = true)
    @LogTimeTaken
    public List<BankDetailsDto> getBankDetails(BankDetailsDto bankDetailsDto){
        List<BankDetailsDto> bankDataDetailList =bankDetailDao.getBankDetails(bankDetailsDto);
        return bankDataDetailList;
    }


}
