package com.sc.rdc.csl.ss.dal.sg.entity;

import com.sc.rdc.csl.ss.common.dto.BaseDto;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Set;

@Data
public class PersonalizedSettingsEntity extends BaseDto {
    private static final long serialVersionUID = -1L;

    private String settingId;
    private String name;
    private Boolean isNameDisplayable;
    private Boolean isNameReadOnly;
    private String accountNumber;
    private Boolean isNumberDisplayable;
    private Boolean isNumberReadOnly;
    private Boolean isRemoved;
    private String settingType;
    private String customerId;
    private Integer orderNumber;
    private String preferredLanguage;
    private BigDecimal limitDecreasingAmount;
    private BigDecimal transferLimitAmount;
    private String limitDecreasingCurrency;
    private String customerEBID;
    private String proCode;
    private String productName;
    private Set deviceGroupList;

    //private DeviceGroupVO deviceGroupVO;

    // for account sorting product display purpose
    private String productDisplayName;
    //private ProductVO productVO;

}
