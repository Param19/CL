package com.sc.rdc.csl.ss.main.service;


import com.sc.csl.retail.core.util.CSLAssert;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.customer.CustomerDetailDto;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.ICustomerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("customerServiceImpl")
@Slf4j
public class CustomerServiceImpl extends ICustomerService {

    @Autowired
    private CustomerServiceFactory customerServiceFactory;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Override
    public CustomerDetailDto getCustomerProfile() {

        CSLAssert.hasLength(cslRequestContext.getCountry(), ErrorConstant.CASA_NO_COUNTRY);
        CSLAssert.hasLength(cslRequestContext.getRelId(), ErrorConstant.CASA_NO_RELID);

        CustomerDetailDto customer = customerServiceFactory.getCustomerService(cslRequestContext.getCountry()).getCustomerProfile();
        return customer;
    }

    @Override
    public SsBaseDto getCustomerProfile(SsCSLUser user) {
        validateHeaders(user);
        SsBaseDto customer = customerServiceFactory.getCustomerService(user.getCountry()).getCustomerProfile(user);
        return customer;
    }

    @Override
    public Profile getProfile(SsCSLUser user) {
        validateHeaders(user);
        return customerServiceFactory.getCustomerService(user.getCountry()).getProfile(user);
    }

    @Override
    public void updateProfile(SsCSLUser user, Profile profile) {
        validateHeaders(user);
        customerServiceFactory.getCustomerService(user.getCountry()).updateProfile(user, profile);
    }


    private void validateHeaders(SsCSLUser cslUser) {
        CSLAssert.notNull(cslUser, ErrorConstant.CUSTOMER_NO_HEADER);
        CSLAssert.hasLength(cslUser.getCountry(), ErrorConstant.CUSTOMER_NO_COUNTRY);
        CSLAssert.hasLength(cslUser.getRelId(), ErrorConstant.CUSTOMER_NO_RELID);
    }
}