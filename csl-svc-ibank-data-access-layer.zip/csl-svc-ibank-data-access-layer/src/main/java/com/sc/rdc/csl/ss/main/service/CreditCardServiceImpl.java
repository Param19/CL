package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.util.CSLAssert;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.card.CardDto;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CreditCardServiceImpl {


    @Autowired
    private CrediCardServiceFactory creditCardServiceFactory;

    public List<CardDto> getCreditCardSummary(SsCSLUser cslUser)  {
        validateHeaders(cslUser);
        List<CardDto> crediCardSummary = creditCardServiceFactory.getCreditCardService(cslUser.getCountry()).getCreditCardSummary(cslUser);
        return crediCardSummary;
    }

    public List<CardDto> getProvidedCreditCardsSummary(SsCSLUser cslUser,List<String> cardNumbers)  {
        validateHeaders(cslUser);
        List<CardDto> crediCardSummary = creditCardServiceFactory.getCreditCardService(cslUser.getCountry()).getProvidedCreditCardSummary(cardNumbers);
        return crediCardSummary;
    }

    public CardDto getCreditCardDetails(String cardNo, SsCSLUser cslUser,boolean includeTransactions){
        CardDto cCardDetails = creditCardServiceFactory.getCreditCardService(cslUser.getCountry()).getCreditCardDetails(cardNo, cslUser,includeTransactions);
        return cCardDetails;
    }

    private void validateHeaders(SsCSLUser cslUser) {
        CSLAssert.notNull(cslUser, ErrorConstant.CREDITCARD_NO_HEADER);
        CSLAssert.hasLength(cslUser.getCountry(), ErrorConstant.CREDITCARD_NO_COUNTRY);
        CSLAssert.hasLength(cslUser.getRelId(), ErrorConstant.CREDITCARD_NO_RELID);
    }
}
