
package com.sc.rdc.csl.ss.common.dto.limit;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@JsonApiResource(type = "transaction-limits")
public class TransactionLimit implements Serializable {

    @JsonApiId
    private Long id;
    private String ebid;
    @JsonProperty("customer-id")
    private String customerId;
    @JsonProperty("customer-id-type")
    private String customerIdType;
    private String category;
    @JsonProperty("transaction-type")
    private String transactionType;
    @JsonProperty("maximum-limit")
    private BigDecimal maximumLimit;
    @JsonProperty("limit-type")
    private String limitType;
    @JsonProperty("used-amount")
    private BigDecimal usedAmount;
    @JsonProperty("limit-amount")
    private BigDecimal limitAmount;

}
