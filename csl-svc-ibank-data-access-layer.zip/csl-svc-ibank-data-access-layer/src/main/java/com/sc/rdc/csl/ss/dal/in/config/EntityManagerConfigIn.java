package com.sc.rdc.csl.ss.dal.in.config;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import javax.sql.DataSource;

import com.sc.rdc.csl.ss.common.helper.Constants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
public class EntityManagerConfigIn {

    @Qualifier("entityManagerFactoryIn")
    @Bean("entityManagerFactoryIn")
    public LocalContainerEntityManagerFactoryBean entityManagerFactoryIn(@Qualifier("db2DataSourceIn") DataSource db2DataSourceIn) {
        LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactory.setDataSource(db2DataSourceIn);
        entityManagerFactory.setPersistenceXmlLocation("classpath*:com/sc/rdc/csl/ss/resource/in/persistence/persistence-in.xml");
        entityManagerFactory.setPersistenceUnitName(Constants.PERSISTENCE_UNIT_IN);
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setShowSql(false);
        vendorAdapter.setDatabase(Database.DB2);
        entityManagerFactory.setJpaVendorAdapter(vendorAdapter);
        return entityManagerFactory;
    }

    @Qualifier("transactionManagerIn")
    @Bean("transactionManagerIn")
    public JpaTransactionManager transactionManagerIn(@Qualifier("entityManagerFactoryIn") LocalContainerEntityManagerFactoryBean entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory.getObject());
        return transactionManager;
    }

    @Qualifier("exceptionTranslationIn")
    @Bean("exceptionTranslationIn")
    public PersistenceExceptionTranslationPostProcessor exceptionTranslationIn() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    @Qualifier("db2DataSourceIn")
    @Bean("db2DataSourceIn")
    @ConfigurationProperties(prefix = "in.db2.datasource")
    public DataSource db2DataSourceIn() {
        return new ComboPooledDataSource();
    }
    
        
    

}
