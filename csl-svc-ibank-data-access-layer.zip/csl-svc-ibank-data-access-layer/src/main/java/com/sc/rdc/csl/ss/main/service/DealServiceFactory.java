package com.sc.rdc.csl.ss.main.service;

import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.IDealService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Created by 1347884 on 11/29/2017.
 */
@Component()
@Slf4j
public class DealServiceFactory {

    @Qualifier("dealServiceCn")
    @Autowired
    private IDealService iDealServiceCn;

    public IDealService getDealService(String country)
    {
        if(country==null){
            country="CN";
        }

        switch (StringUtils.upperCase(country)) {
            case Constants.CN:
                return iDealServiceCn;
            default:
                log.error("############ Country not supported ###########");
                return null;
        }
    }
}
