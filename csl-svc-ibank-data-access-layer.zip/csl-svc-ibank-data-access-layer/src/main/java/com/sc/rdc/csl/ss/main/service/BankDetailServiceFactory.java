package com.sc.rdc.csl.ss.main.service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.rdc.csl.ss.common.helper.Constants;
import com.sc.rdc.csl.ss.common.service.BankDetailService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.ss.common.helper.ErrorConstant.COUNTRY_NOT_ALLOWED;


@Component()
@Slf4j
public class BankDetailServiceFactory {

    @Qualifier("bankDetailServiceHK")
    @Autowired
    private BankDetailService bankDetailServiceHK;

    Map<String, BankDetailService> map = new HashMap<>();


    public BankDetailService getBankDetails(String country) {
        if (map.size() == 0)
            initMap();
        BankDetailService bankDetailService = map.get(StringUtils.upperCase(country));
        if (bankDetailService != null)
            return bankDetailService;
        log.error("Country {} is not allowed to call Bank Service", country);
        throw new BusinessException(TemplateErrorCode.create(COUNTRY_NOT_ALLOWED, country, "Bank"));
    }

    private void initMap() {
        map.put(Constants.HK, bankDetailServiceHK);

    }
}
