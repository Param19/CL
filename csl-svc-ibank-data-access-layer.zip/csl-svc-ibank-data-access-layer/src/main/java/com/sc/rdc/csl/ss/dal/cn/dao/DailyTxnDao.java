package com.sc.rdc.csl.ss.dal.cn.dao;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.Date;
import java.util.List;

import static com.sc.rdc.csl.ss.dal.cn.config.LimitsConstant.CUSTOMER_DAILY_LIMIT;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Repository(value = "dailyTxnDaoCN")
public class DailyTxnDao extends BaseDao {

    public List<String> getTransactionAmountByDate(String custId, String limitType, String txnType, Date txnDate) {
        Query query = null;
        if (StringUtils.equals(CUSTOMER_DAILY_LIMIT, limitType)) {
            query = entityManagerCn.createNativeQuery("select (curr || '-' || tot_amt) as trx_amt from cfe.vw_daily_txn where cust_id = :customerId"
                    + " and txn_type = :transType"
                    + " and date(txn_date) = :transactionDate");
            query.setParameter("customerId", custId);
            query.setParameter("transType", txnType);
            query.setParameter("transactionDate", txnDate);
        } else {
            query = entityManagerCn.createNativeQuery("select (curr || '-' || tot_amt) as trx_amt from cfe.vw_daily_txn where cust_id = :customerId"
                    + " and date(txn_date) = :transactionDate");
            query.setParameter("customerId", custId);
            query.setParameter("transactionDate", txnDate);
        }
        List<String> dailyTxnEntities = query.getResultList();
        return dailyTxnEntities;
    }

}
