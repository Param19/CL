
package com.sc.rdc.csl.ss.dal.hk.dao;

import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingApplicationEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingCustEntity;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import javax.persistence.Query;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;



@Repository(value = "wealthLendingServiceDaoHk")
@Slf4j
public class WealthLendingServiceDao extends BaseDao {

    public static String WEALTH_PRO_CUST_STATUS_ACCEPTED = "Accepted";
    public static String WEALTH_PRO_CUST_STATUS_OPEN = "open";
    
    public static String FIND_CUSTOMER = "select o from com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingCustEntity o WHERE o.customerId = :customerId AND o.customerIdType = :customerIdType";
    public static String FIND_APPL = "select o from com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingApplicationEntity o WHERE o.receiptRefNo = :receiptRefNo";
    public static String FIND_ALL_APPL = "select o from com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingApplicationEntity o where submissionDate >= :submissionDate ";
    public static String SEQ = "SELECT (NEXTVAL FOR SCBCIF.WEALTH_PRO_APPL_DTL_SEQ) FROM SYSIBM.SYSDUMMY1";
    public static String UPDATE_APPL_STATUS="update com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingCustEntity set status = :customerStatus, updatedDate= :updatedDate where  customerId = :customerId AND customerIdType = :customerIdType and lower(status) = :currentstatus and expiryDate >= :expiryDate";

    public WealthLendingCustEntity findWldCustomerDetails(SsCSLUser user) {
        log.info("WealthLendingServiceDao:findWldCustomerDetails,{}", user);
        Query query = entityManagerHk.createQuery(FIND_CUSTOMER);
        query.setParameter("customerId", user.getCustomerId());
        query.setParameter("customerIdType", user.getCustomerTypeId());
        List<WealthLendingCustEntity> custVoList = query.getResultList();
        WealthLendingCustEntity wealthLendingCustVO = null;
        if (!custVoList.isEmpty()) {
            wealthLendingCustVO = custVoList.get(0);
        }
        return wealthLendingCustVO;
    }

    public WealthLendingApplicationEntity insertApplication(WealthLendingApplicationEntity wealthLendingApplicationVO) {
        log.info("WealthLendingServiceDao:insertApplication,{}", wealthLendingApplicationVO);
        wealthLendingApplicationVO.setId(getNextSequence().longValue());
        wealthLendingApplicationVO = entityManagerHk.merge(wealthLendingApplicationVO);
        return wealthLendingApplicationVO;
    }
    
    public WealthLendingApplicationEntity updateApplication(WealthLendingApplicationEntity wealthLendingApplicationVO) {
        log.info("WealthLendingServiceDao:updateApplication,{}", wealthLendingApplicationVO);
        wealthLendingApplicationVO = entityManagerHk.merge(wealthLendingApplicationVO);
        return wealthLendingApplicationVO;
    }

    public WealthLendingApplicationEntity getApplication(String refId) {
        WealthLendingApplicationEntity wealthLendingApplicationVO = null;
        log.info("getApplication::getApplication,{}", refId);
        Query query = entityManagerHk.createQuery(FIND_APPL);
        query.setParameter("receiptRefNo", refId);
        List<WealthLendingApplicationEntity> applicationVoList = query.getResultList();
        if (!applicationVoList.isEmpty()) {
            wealthLendingApplicationVO = applicationVoList.get(0);
        }
        return wealthLendingApplicationVO;
    }

    public List<WealthLendingApplicationEntity> getAllApplication(String applicationStatus) {
        log.info("WealthLendingServiceDao:getAllApplication,{},{}", applicationStatus);
        StringBuilder jpaQuery = new StringBuilder();
        jpaQuery.append(FIND_ALL_APPL);
        if (StringUtils.isNotBlank(applicationStatus)) {
            jpaQuery.append(" and lower(o.applicationStatus) = ").append("'").append(applicationStatus.toLowerCase()).append("' ");
        }
        log.info("WealthLendingCustVO:getAllApplication Query,{}", jpaQuery);
        Query query = entityManagerHk.createQuery(jpaQuery.toString());
        query.setParameter("submissionDate", new Date(System.currentTimeMillis() - 10 * 60 * 60 * 1000));
        List<WealthLendingApplicationEntity> applicationVoList = query.getResultList();
        return applicationVoList;
    }

    public int updateWealthProCustStatus(WealthLendingApplicationEntity wealthLendingApplicationVO) {
        log.info("WealthLendingServiceDao:updateWealthProCustStatus,{}", wealthLendingApplicationVO);
        Query query = entityManagerHk.createQuery(UPDATE_APPL_STATUS);
        query.setParameter("customerId", wealthLendingApplicationVO.getCustomerId());
        query.setParameter("customerIdType", wealthLendingApplicationVO.getCustomerIdType());
        query.setParameter("customerStatus", WEALTH_PRO_CUST_STATUS_ACCEPTED);
        query.setParameter("currentstatus", WEALTH_PRO_CUST_STATUS_OPEN);
        query.setParameter("expiryDate", new Date());
        query.setParameter("updatedDate", new Date());
        return query.executeUpdate();
    }

    public BigInteger getNextSequence() {
        Query query = entityManagerHk.createNativeQuery(SEQ);
        return (BigInteger) query.getSingleResult();

    }

}
