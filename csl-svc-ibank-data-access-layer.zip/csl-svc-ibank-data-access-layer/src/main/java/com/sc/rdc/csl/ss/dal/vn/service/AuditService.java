package com.sc.rdc.csl.ss.dal.vn.service;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sc.csl.retail.core.log.LogTimeTaken;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.audit.Audit;
import com.sc.rdc.csl.ss.common.helper.AuditConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.common.service.IAuditService;
import com.sc.rdc.csl.ss.dal.vn.config.DozerUtilsVN;
import com.sc.rdc.csl.ss.dal.vn.dao.AuditServiceDao;
import com.sc.rdc.csl.ss.dal.vn.entity.AuditEntity;
import com.sc.rdc.csl.ss.main.helper.APRSKeyGenerationUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("auditServiceVN")
public class AuditService extends IAuditService {
	

    @Autowired
    @Qualifier("auditServiceDaoVN")
    private AuditServiceDao auditServiceDao;


    @Qualifier("dozerUtilsVN")
    @Autowired  
    private DozerUtilsVN dozerUtilsVN;
    
	@Override
	@Transactional("transactionManagerVN")
	@LogTimeTaken
	public Audit auditTransaction(Audit audit,SsCSLUser user) {
		log.debug("auditTransaction :"+audit);
		try{
			AuditEntity auditEntity= new AuditEntity();
		    dozerUtilsVN.convertCustomer(audit,auditEntity , "audit-txn");
		    auditEntity.setCoutnry(user.getCountry());
		    auditEntity.setPrimaryRelId(user.getRelId());
		    log.debug("audit transaction :"+auditEntity);
		    auditEntity.setSection(AuditConstant.SECTION);
		    auditEntity.setAuditKey(new Long(APRSKeyGenerationUtil.getInstance()
					.getUUID()));
		    log.info("audit key :"+auditEntity.getAuditKey());
		    log.info("audit Info :"+auditEntity.getAuditInfo());
			String dateTime = StringUtils.substringAfter(auditEntity.getAuditInfo(),AuditConstant.DATETIME+"=");
			log.info("audit key dateTime :"+dateTime);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			Date transactionDate = df.parse(dateTime);
			Timestamp timestamp = new Timestamp(transactionDate.getTime());
			 log.debug("audit transaction timestamp:"+timestamp);
			auditEntity.setEntryTime(timestamp);
			
			auditServiceDao.auditTransaction(auditEntity);
			audit.setStatusCd("0000");
		}catch (Exception e) {
			log.info("Exceotion message "+e.getLocalizedMessage());
            log.error("Exception while Inserting Audit {} , {} ", user.getCustomerId(), e.getMessage());
            throw new TechnicalException(ErrorConstant.ERR_INSERTING_AUDIT);
        }
	    return audit;
  } 

}
