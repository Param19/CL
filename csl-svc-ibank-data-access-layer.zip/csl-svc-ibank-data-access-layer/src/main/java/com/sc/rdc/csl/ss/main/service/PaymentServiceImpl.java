package com.sc.rdc.csl.ss.main.service;


import com.sc.rdc.csl.ss.common.dto.payment.PaymentDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("paymentServiceImpl")
@Slf4j
public class PaymentServiceImpl {
    
    @Autowired
    private PaymentServiceFactory paymentServiceFactory;

    public  PaymentDto submitPayment(PaymentDto paymentDto, String countryCode){
        PaymentDto paymentVO =  paymentServiceFactory.getPaymentService(countryCode).submitPayment(paymentDto);
       return paymentVO;
    }
    
    public  PaymentDto updatePayment(PaymentDto paymentDto, String countryCode){
        PaymentDto paymentVO =  paymentServiceFactory.getPaymentService(countryCode).updatePayment(paymentDto);
       return paymentVO;
    }

    public  PaymentDto getPayment(String transactionId, String countryCode){
        PaymentDto paymentVO =  paymentServiceFactory.getPaymentService(countryCode).getPayment(transactionId);
        return paymentVO;
    }

}
