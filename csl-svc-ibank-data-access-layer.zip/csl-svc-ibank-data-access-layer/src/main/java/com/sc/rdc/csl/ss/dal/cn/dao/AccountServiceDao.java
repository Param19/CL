package com.sc.rdc.csl.ss.dal.cn.dao;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsConstant;
import com.sc.rdc.csl.ss.common.helper.ErrorConstant;
import com.sc.rdc.csl.ss.dal.cn.entity.AccountEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import java.util.List;

@Repository(value ="accountServiceDaoCn")
@Slf4j
public class AccountServiceDao extends BaseDao{

    @Autowired
    @Qualifier("cslRequestContext")
    CSLRequestContext requestContext;

    public List<AccountEntity> getAccountSummary() {
        log.info("AccountServiceDao:getAccountSummary");
        Query query = entityManagerCn.createQuery("select a from com.sc.rdc.csl.ss.dal.cn.entity.AccountEntity a WHERE a.customerId = :customerId")
                .setHint("javax.persistence.query.timeout", SsConstant.DB2_CONNECTION_TIMEOUT_MINS);
        query.setParameter("customerId", requestContext.getCompositeRelId());
        List<AccountEntity> accountEntityList = query.getResultList();
        log.info("Received {} AccountSummary record(s) from DB for User Id {}",
                (accountEntityList != null ? accountEntityList.size() : 0), requestContext.getCompositeRelId());
        if(!(accountEntityList!=null && accountEntityList.size()>0))
            throw new BusinessException(ErrorConstant.CASA_NO_RECORD_EXCEPTION);
        return accountEntityList;
    }
}
