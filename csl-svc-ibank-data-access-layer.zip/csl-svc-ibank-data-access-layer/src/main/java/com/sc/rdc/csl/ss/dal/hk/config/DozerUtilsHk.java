package com.sc.rdc.csl.ss.dal.hk.config;

import com.sc.rdc.csl.ss.common.dto.wld.ApplicationDto;
import com.sc.rdc.csl.ss.common.dto.wld.CustomerDto;
import com.sc.rdc.csl.ss.common.dto.account.BndAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.CasaAccountDto;
import com.sc.rdc.csl.ss.common.dto.account.WealthAccountDto;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingApplicationEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.WealthLendingCustEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountEntity;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountInputWrapper;
import com.sc.rdc.csl.ss.dal.hk.entity.account.AccountOutputWrapper;
import com.sc.rdc.csl.ss.dal.hk.entity.customer.CustomerEntity;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("dozerUtilsHk")
@Slf4j
public class DozerUtilsHk {

    @Qualifier("dozerBeanMapperHk")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    public List<ApplicationDto> convertApplicationDto(final List<WealthLendingApplicationEntity> sourceList) {
        if (sourceList == null) {
            return null;
        }
        List<ApplicationDto> dest = new ArrayList<>();
        for (WealthLendingApplicationEntity source : sourceList) {
            dest.add(dozerBeanMapper.map(source, ApplicationDto.class, "WealthLendingApplicationVO"));
        }
        return dest;
    }

    public CustomerDto convertCustomer(WealthLendingCustEntity wealthLendingCustEntity) {
        if (wealthLendingCustEntity == null) {
            return null;
        }
        CustomerDto cust = new CustomerDto();
        dozerBeanMapper.map(wealthLendingCustEntity, cust);
        return cust;
    }

    public List<WealthAccountDto> convertAccount(final List<AccountEntity> sourceList) {
        if (sourceList == null) {
            return null;
        }
        AccountInputWrapper inputList = new AccountInputWrapper();
        inputList.setAccountEntityList(sourceList);
        AccountOutputWrapper out = new AccountOutputWrapper();
        dozerBeanMapper.map(inputList, out, "InvestmentAccountList");
        return out.getWealthAccountList();
    }

    public List<CasaAccountDto> convertCasaAccount(final List<AccountEntity> sourceList) {
        if (sourceList == null) {
            return null;
        }
        AccountInputWrapper inputList = new AccountInputWrapper();
        inputList.setAccountEntityList(sourceList);
        AccountOutputWrapper out = new AccountOutputWrapper();
        dozerBeanMapper.map(inputList,out, "CasaAccountList");
        return out.getCasaAccountList();
    }

    public List<BndAccountDto> convertBndAccount(final List<AccountEntity> sourceList) {
        if (sourceList == null) {
            return null;
        }
        AccountInputWrapper inputList = new AccountInputWrapper();
        inputList.setAccountEntityList(sourceList);
        AccountOutputWrapper out = new AccountOutputWrapper();
        dozerBeanMapper.map(inputList, out, "BndAccountList");
        return out.getBndAccountDtoList();
    }

    public Profile convertCustomer(Profile profile,CustomerEntity customerEntity,String mapId) {
        if (customerEntity == null || profile == null) {
            return null;
        }
        dozerBeanMapper.map(customerEntity, profile,mapId);
        return profile;
    }
}
