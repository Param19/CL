package com.sc.rdc.csl.ss.common.dto;

public class SsConstant {
    
    
    public static final String METHOD_NAME = "methodName";
    public static final String SERVICE_NAME = "serviceName";
    public static final String CSL_USER = "csl_user";

    public static final String HEADER_REQUEST_ID = "requestId";
    public static final String PAD_COMMA = "|";
    public static final String SESSION_ID = "sessionId";
    public static final String USER_AGENT = "User-Agent";
    public static final String CHANNEL = "channel";
    public static final String CHANNEL_CONSTANT = "IBNK";
    
    public static final String HTTP_METHOD_NAME = "method_name";
 
    public static final String INTLog = "INTLog";
    
    public static final String WLD_GET_CUSTOMER_ENDPOINT = "customers";
    public static final String WLD_GET_FORMS_ENDPOINT = "forms";
    
    public static final String EVNT_SUB_TYPE_GET_CUST = "SS.WLD.GET.CUST";
    public static final String EVNT_SUB_TYPE_POST_FORM = "SS.WLD.POST.FORMS";
    public static final String EVNT_SUB_TYPE_PUT_FORM = "SS.WLD.PUT.FORMS";
    public static final String EVNT_SUB_TYPE_GET_FORM = "SS.WLD.GET.FORMS";
    
    public static final Integer SS_SUCCESS_STATUS = 0;
     
    public static final Integer DEFAULT_ORDER = 1000;
    public static final Integer DB2_CONNECTION_TIMEOUT_MINS = 15000;

    public static final String PAYMENT = "PAYMENT";


}
