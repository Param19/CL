package com.sc.rdc.csl.ss.common.helper;

import com.sc.csl.retail.core.exception.ErrorCode;
import lombok.Getter;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

@Getter
public enum ErrorConstant implements ErrorCode {

    ERR_GENERIC_EXCEPTION(null,null,null),

    ERR_UPDATING_APP_STATUS(null,null,null),

    ERR_RETRIEVING_APP_DETAILS(null,null,null),
    ERR_RETRIEVING_CUST_DETAILS(null,null,null),

    ERR_INSERTING_APP(null,null,null),
    ERR_RETRIEVING_ACCOUNT_DEATILS(null,null,null),
    ERR_RETRIEVING_PERSONALIZED_SETTINGS(null,null,null),

    MULTIPLE_RECORDS_FOUND(null,null,null),

    DATA_UPDATE_STATUS(null,null,null),
    APPLICATION_DETAILS_NOT_FOUND(null,null,null),
    APPLICATIONS_DETAILS_NOT_FOUND(null,null,null),
    CUSTOMER_DETAILS_NOT_FOUND(null,null,null),
    ACCOUNT_DETAILS_NOT_FOUND(null,null,null),
    APPLICATION_SUBMITTED(null,null,null),
    PERSONALIZED_SETTINGS_NOT_FOUND(null,null,null),

    ROUTE_NOT_FOUND("CSL-SS-ACCOUNTS-502","No Route Found","Country %s is not allowed to query Account details"),
    //ACCOUNT_DETAILS_NOT_FOUND("CSL-SS-ACCOUNTS-503","No Account Found","Account Details not available"),
    ERR_FETCHING_ACCOUNT("CSL-SS-ACCOUNTS-504","Not able to fetch Account details","Exception while fetching Account details from 24X7"),
    CASA_NO_HEADER("CSL-SS-ACCOUNTS-505","Missing CSL_USER header","Mandatory header is not available"),
    CASA_NO_RELID("CSL-SS-ACCOUNTS-506","Missing RelId","Mandatory RelId is not available"),
    CASA_NO_COUNTRY("CSL-SS-ACCOUNTS-507","Missing country","Mandatory country is not available"),
    CASA_EXCEPTION("CSL-SS-ACCOUNTS-508","Exception Occurred","Reason: %s"),
    CASA_NO_RECORD_EXCEPTION("CSL-SS-ACCOUNTS-509","No Account found","No valid Account found for the provided Rel Id"),
    CASA_ACCOUNT_NOT_FOUND("CSL-SS-ACCOUNTS-510","No Account found","No Account found for the provided Account No"),
    CASA_NO_TRANSACTION_FOUND("CSL-SS-ACCOUNTS-511","No Transaction found","No Transaction found for the provided Account No for the date range provided"),
    INVALID_ACCOUNT_FORMAT("CSL-SS-ACCOUNTS-512","Invalid Account Format","Invalid Account Format"),
    COUNTRY_NOT_ALLOWED("CSL-SS-511","Country is not allowed","Country %s is not allowed for %s"),
    CUSTOMER_NO_HEADER("CSL-SS-CUSTOMER-505","Missing CSL_USER header","Mandatory header is not available"),
    CUSTOMER_NO_RELID("CSL-SS-CUSTOMER-506","Missing RelId","Mandatory RelId is not available"),
    CUSTOMER_NO_COUNTRY("CSL-SS-CUSTOMER-507","Missing country","Mandatory country is not available"),
    SS_NO_CHANNEL("CSL-SS-511","Missing Channel","Mandatory Channel is not available"),
    SS_EMPTY_PAYMENT("CSL-SS-PAYMENTS-501","Missing Payment Object","Mandatory Payment Object is not available"),
    SS_PAYMENT_EXCEPTION("CSL-SS-PAYMENTS-503","Exception in Payment 247x7","Reason: %s"),
    CUSTOMER_NO_RECORD_EXCEPTION("CSL-SS-CUSTOMER-509","No Customer found","No valid Customer found for the provided " +
            "Rel Id"),
    ERR_FETCHING_CUSTOMER("CSL-SS-CUSTOMER-504","Not able to fetch Customer details","Exception while fetching " +
            "Customer details from 24X7"),
    SS_NO_TRANSACTIONID("CSL-SS-PAYMENTS-502","Missing TransactionId","Mandatory TransactionId is not available"),
    SS_NO_PAYMENT("CSL-SS-PAYMENTS-504","Payment not available","Payment not available"),
    SS_PAYMENT_EXISTS("CSL-SS-PAYMENTS-505","Payment exists with same id","Payment exists with same id"),
    ERR_NO_CUSTID("CSL-SS-CUSTOMER-511","Missing CustId","Mandatory CustomerId is not available"),
    UNSUPPORTED_OPERATION("CSL-SS-CUSTOMER-512","Operation Not Supported","This Operation is not supported"),

    AUDIT_NO_REQUESTID("CSL-SS-AUDIT-502","Missing Request Id","Mandatory RequestId is not available"),
    ERR_FETCHING_AUDIT("CSL-SS-AUDIT-504","Not able to fetch Audit details","Exception while fetching " +
            "Audit details from 24X7"),
    AUDIT_NO_HEADER("CSL-SS-AUDIT-505","Missing CSL_USER header","Mandatory header is not available"),
    AUDIT_NO_RELID("CSL-SS-AUDIT-506","Missing RelId","Mandatory RelId is not available"),
    AUDIT_NO_COUNTRY("CSL-SS-AUDIT-507","Missing country","Mandatory country is not available"),
    AUDIT_INFO("CSL-SS-AUDIT-508","Missing audit Info","Mandatory Audit Information is not available"),
    AUDIT_INFO_INVALID("CSL-SS-AUDIT-510","Invalid audit Info","Audit Information is not valid"),
    ERR_INSERTING_AUDIT("CSL-SS-AUDIT-509","Unable to insert the record into DB","Exception while insert into Audit details from 24X7"),
    AUDIT_SERVICE_NOT_ALLOWED("CSL-SS-AUDIT-511","Service is not allowed","Service %s is not allowed for %s"),
    CARD_NO_RECORD_EXCEPTION("CSL-SS-CARDS-509","No Account found","No valid Account found for the provided credit card number"),

    // Added for Credit Card service
    ERR_FETCHING_CREDITCARD("CSL-SS-CREDITCARDS-504","Not able to fetch CreditCard details","Error fetching CreditCard Details"),
    CREDITCARD_NO_HEADER("CSL-SS-CREDITCARD-505","Missing CSL_USER header","Mandatory header is not available"),
    CREDITCARD_NO_RELID("CSL-SS-CREDITCARD-506","Missing RelId","Mandatory RelId is not available"),
    CREDITCARD_NO_COUNTRY("CSL-SS-CREDITCARD-507","Missing country","Mandatory country is not available"),
    CREDITCARD_EXCEPTION("CSL-SS-CREDITCARD-508","Exception Occurred","Reason: %s"),
    CREDITCARD_NO_RECORD_EXCEPTION("CSL-SS-CreditCard-509","No Record found","No valid credit card found for the provided Rel Id"),
    UNIT_TRUST_NO_RELID("CSL-SS-UNITTRUST-501","Missing RelId","Mandatory RelId is not available"),
    UNIT_TRUST_NO_COUNTRY("CSL-SS-UNITTRUST-502","Missing country","Mandatory country is not available"),
    ERR_FETCHING_UNIT_TRUST("CSL-SS-UNITTRUST-503","Not able to fetch Unit Trusts","Exception while fetching Unit Trusts from 24X7"),
    UNIT_TRUST_NOT_FOUND_FOR_RELID("CSL-SS-UNITTRUST-504","No Unit Trust found","No Unit Trust found for the provided Rel Id"),
    LOAN_ACCOUNT_NOT_FOUND_FOR_RELID("CSL-SS-LOAN-501","No Account found","No Loan Account found for the provided Rel Id"),
    LOAN_ACCOUNT_NOT_FOUND("CSL-SS-LOAN-502","No Account found","No Loan Account found for the provided Account No"),
    CREDITCARD_NO_TRANSACTION_FOUND("CSL-SS-CREDITCARD-509","No Transaction found","Transaction Not Found for the provided Card No."),
    HOLIDAY_LIST_NOT_FOUND_FOR_COUNTRY("CSL-SS-HOLIDAY-510","No Holiday List found","No Holiday List found for the provided Country"),
    TRANSACTION_PASSWORD_NOT_FOUND_FOR_EBID("CSL-SS-TP-511","No transaction password found","No transaction password found for the provided EBID"),
    TRANSACTION_PASSWORD_SAVE_FAILED("CSL-SS-TP-512","Error saving transaction password.", "Error saving transaction password."),
    MISSING_FIELDS("CSL-CLICK2CALL-521", "Validation failed", "Missing mandatory field(s) : %s"),
    COUNTRY_ERROR("CSL-CLICK2CALL-522", "Validation failed", "Country value not present"),
    MOBILE_ERROR("CSL-CLICK2CALL-525", "Validation failed", "Mobile Number value not present"),
    SERVICE_UNAVAILABLE("CSL-CLICK2CALL-531", "Service unavailable", "Service unavailable"),
	PRODUCT_DESC_ERROR ("CSL-PRODUCT-001","Product Description not found","Product Description not found"),
    INVALID_FILTER_PARAMS ("CSL-FILTER-001","Received Invalid Filter","Received Invalid Filter"),
    ERR_FETCHING_FXRATE("CSL-SS-LIMITS-501","Not able to fetch FX ratre details","Exception while fetching FX Rate from 24X7"),
	ERR_FETCHING_DEAL("CSL-TD-501","Not able to fetch Deal details","Exception while fetching Deal details from 24X7");

    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    ErrorConstant(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }
}
