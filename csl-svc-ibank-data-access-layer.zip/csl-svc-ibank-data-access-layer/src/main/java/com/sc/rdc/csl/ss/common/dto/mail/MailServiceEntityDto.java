package com.sc.rdc.csl.ss.common.dto.mail;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)

@JsonApiResource(type = "mailbox")
public class MailServiceEntityDto extends SsBaseDto {

    @JsonApiId
    private String id;

    @JsonProperty("messageCategory")
    private String messageCategory;

    @JsonProperty("messageSubject")
    private String messageSubject;

    @JsonProperty("messageBody")
    private String messageBody;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("messageSenderId")
    private String messageSenderId;

    @JsonProperty("messageSenderAddressType")
    private String messageSenderAddressType;
    
    @JsonProperty("messageReceiverId")
	private String messageReceiverId;
    
	@JsonProperty("messageReceiverAddressType")
	private String messageReceiverAddressType;
	
    @JsonProperty("statusDescription")
    private String statusDescription;

    @JsonProperty("statusCode")
    private Integer statusCode;

    @JsonProperty("relNumber")
    private String relNumber;

}
