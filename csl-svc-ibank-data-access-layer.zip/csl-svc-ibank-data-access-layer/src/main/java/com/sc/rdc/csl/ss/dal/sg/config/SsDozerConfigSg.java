package com.sc.rdc.csl.ss.dal.sg.config;

import lombok.Getter;
import lombok.Setter;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class SsDozerConfigSg {

	@Bean("dozerMappingFilesSg")
	public DozerMappingFilesSg dozerMappingFiles() {
		return new DozerMappingFilesSg();
	}



	@Bean("dozerBeanMapperSg")
	public DozerBeanMapper dozerBeanMapper( DozerMappingFilesSg dozerMappingFiles) {
		 dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/sg/dozer/wealth-lending-mappings.xml");
		return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
	}

	@Setter
	@Getter
	private class DozerMappingFilesSg {
 		private List<String> mappingFiles = new ArrayList<>();
	}
        
        
}
