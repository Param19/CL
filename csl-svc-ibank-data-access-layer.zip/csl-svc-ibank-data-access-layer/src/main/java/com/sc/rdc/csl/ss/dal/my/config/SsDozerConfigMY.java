package com.sc.rdc.csl.ss.dal.my.config;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
public class SsDozerConfigMY {

        
	@Bean("dozerMappingFilesMY")
	public DozerMappingFilesMY dozerMappingFiles() {
		return new DozerMappingFilesMY();
	}


	@Bean("dozerBeanMapperMY")
	public DozerBeanMapper dozerBeanMapperMY( DozerMappingFilesMY dozerMappingFiles) {
		dozerMappingFiles.getMappingFiles().add("com/sc/rdc/csl/ss/resource/my/dozer/customer-profile-mappings.xml");
		return new DozerBeanMapper(dozerMappingFiles.getMappingFiles());
	}

	@Setter
	@Getter
	private class DozerMappingFilesMY {
 		private List<String> mappingFiles = new ArrayList<>();
	}
        
        
}
