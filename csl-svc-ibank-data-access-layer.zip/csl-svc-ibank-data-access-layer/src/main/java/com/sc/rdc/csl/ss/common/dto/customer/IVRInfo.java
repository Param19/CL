package com.sc.rdc.csl.ss.common.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * @author Sivaprakasam, Balaji (1347884)
 */
@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonApiResource(type = "ivr-sessions")
public class IVRInfo extends SsBaseDto {

    @JsonApiId
    private String id;

    @NotNull
    @JsonProperty("mobile")
    private String mobile;

    @JsonProperty("country")
    private String country;

    @JsonProperty("name")
    private String name;

    @JsonProperty("segment")
    private String segment;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("armcode")
    private String armcode;

    @JsonProperty("lang")
    private String lang;

    @JsonProperty("customerId")
    private String customerId;

    @JsonProperty("customerIdType")
    private String customerIdType;

    @JsonProperty("active")
    private String active;

    @JsonProperty("datetime")
    private String datetime;

}
