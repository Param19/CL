package com.sc.rdc.csl.ss.main.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.card.CardDto;
import com.sc.rdc.csl.ss.common.dto.card.CreditCardTransactionDto;
import com.sc.rdc.csl.ss.main.service.CrediCardServiceFactory;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.RelationshipRepositoryV2;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class CardToCreditCardTransactionRelationshipRepository
implements RelationshipRepositoryV2<CardDto, String, CreditCardTransactionDto, String> {

	@Autowired
	private CSLRequestContext cslRequestContext;

	@Override
	public Class<CardDto> getSourceResourceClass() {
		return CardDto.class;
	}

	@Override
	public Class<CreditCardTransactionDto> getTargetResourceClass() {
		return CreditCardTransactionDto.class;
	}


	@Autowired
	private CrediCardServiceFactory cardTransactionFactory;

	@Override
	public CreditCardTransactionDto findOneTarget(String id, String fieldName, QuerySpec querySpec) {
		return null;
	}

	@Override
	public void setRelation(CardDto card, String targetId, String fieldName) {
		log.info("setRelation card,targetId,fieldName -{},{},{}", card, targetId, fieldName);
	}

	@Override
	public void setRelations(CardDto card, Iterable<String> targetIds, String fieldName) {
		log.info("setRelations card,targetIds,fieldName -{},{},{}", card, targetIds, fieldName);
	}

	@Override
	public void removeRelations(CardDto source, Iterable<String> targetIds, String fieldName) {
		log.info("removeRelations source,targetIds,fieldName -{},{},{}", source, targetIds, fieldName);
	}

	@Override
	public void addRelations(CardDto source, Iterable<String> targetIds, String fieldName) {
		log.info("addRelations source,targetIds,fieldName -{},{},{}", source, targetIds, fieldName);
	}

	@Override
	public ResourceList<CreditCardTransactionDto> findManyTargets(String sourceId, String fieldName, QuerySpec querySpec) {
		try{
			log.debug("[findManyTargets Entry]");
			log.info("findManyTargets sourceId,fieldName-{},{}", sourceId, fieldName);
			List<CreditCardTransactionDto> transactionDto = cardTransactionFactory.getCreditCardService(cslRequestContext.getCountry()).getTransactionHistory(sourceId);
			if(!transactionDto.isEmpty()) {
				querySpec.setLimit(Long.valueOf(transactionDto.size()));
			}
			return querySpec.apply(transactionDto);
		} finally {
			log.debug("[findManyTargets Exit]");
		}
	}
}