package com.sc.rdc.csl.ss.dal.cn.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Radhakrishnan, Naresh Kumar (1388162)
 */
@Data
@Entity
@Table(name = "FXRATE", schema = "CFE")
public class FXRateEntity implements Serializable {


    @Column(name = "BASE_CCY")
    private String baseCurrencyCode;

    @Column(name = "BASE_DESC")
    private String baseCurrencyDescription;

    @Id
    @Column(name = "FX_CCY")
    private String fxCurrencyCode;

    @Column(name = "FX_CCY_DESC")
    private String fxCurrencyDescription;

    @Column(name = "EFFECTIVE_DATE_TIME")
    private Date effectiveDate;

    @Column(name = "FX_TIER")
    private String fxTier;

    @Column(name = "FX_TIER_AMT")
    private BigDecimal fxTierAmount;

    @Column(name = "FX_UNIT")
    private String fxUnit;

    @Column(name = "FX_SELLING_RATE")
    private BigDecimal sellRate;

    @Column(name = "FX_BUY_RATE")
    private BigDecimal buyRate;

    @Column(name = "MIDRATE")
    private BigDecimal midRate;

    @Column(name = "RATE_TYPE")
    private String rateType;

    @Column(name = "MULTIPLYDIVIDEFLAG")
    private String multiplyDividFlag;

    @Column(name = "STATUSFLAG")
    private String statusFlag;

    @Column(name = "REF_TYPE")
    private String refType;

    @Column(name = "FX_TYPE")
    private String fxType;
}
