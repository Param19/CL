package com.sc.rdc.csl.ss.main.endpoint.jsonapi;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.customer.Profile;
import com.sc.rdc.csl.ss.main.service.CustomerServiceImpl;
import io.katharsis.errorhandling.exception.ResourceNotFoundException;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ProfileEndpoint extends ResourceRepositoryBase<Profile, String> {

    public ProfileEndpoint() {
        super(Profile.class);
    }

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    private CustomerServiceImpl customerService;

    @Override
    public Profile findOne(String id, QuerySpec querySpec) {
        ResourceList<Profile> result = new DefaultResourceList<>();
        result.add(getProfile());
        return querySpec.apply(result).stream().findFirst()
                .orElseThrow(() -> new TechnicalException(new ResourceNotFoundException(id.toString())));
    }

    @Override
    public Profile save(Profile resource) {
        if (resource != null && resource.getCustSeqNo() == null ) {
            resource.setCustSeqNo(getProfile().getCustSeqNo());
        }

        SsCSLUser user = new SsCSLUser(cslRequestContext);
        customerService.updateProfile(user, resource);
        Profile profile=  customerService.getProfile(user);
        return profile;
    }

    @Override
    public ResourceList<Profile> findAll(QuerySpec querySpec) {
        ResourceList<Profile> result = new DefaultResourceList<>();
        result.add(getProfile());
        return querySpec.apply(result);
    }

    private Profile getProfile() {
        return customerService.getProfile(new SsCSLUser(cslRequestContext));
    }

}
