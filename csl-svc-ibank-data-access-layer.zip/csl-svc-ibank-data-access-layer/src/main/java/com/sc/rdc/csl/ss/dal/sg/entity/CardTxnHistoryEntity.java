package com.sc.rdc.csl.ss.dal.sg.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Data
@Table(name = "VW_CARDTXNHIST", schema = "SCBBTH")
public class CardTxnHistoryEntity {

    @Id
    @Column(name = "CARDTXNHIST_ID")
    private Long txnRefNo;

    @Column(name = "ACCOUNTID")
    private String cardNum;

    @Column(name = "STATEMENTDATE")
    private Date statement;

    @Column(name = "ORGCODE")
    private String orgCode;

    @Column(name = "TXNPOSTDATE")
    private Date txnPostDate;

    @Column(name = "TXNDESCRIPTION")
    private String refDesc;

    @Column(name = "TXNCODE")
    private String txnCode;

    @Column(name = "TXNDATE")
    private Date txnDate;

    @Column(name = "TXNAMT")
    private Float actualTxnAmount;

    @Column(name = "TXNCURRENCYCODE")
    private Integer txnCurr;

    @Column(name = " TXNCURRENCYAMT")
    private Float currency;

    @Column(name = "TXNCURRENCYDECIMAL")
    private Integer txnCurrencyDecimal;

    @Column(name = "STATEMENTCODE")
    private String statementCode;

    @Column(name = "SOURCECODE")
    private String sourceCode;

    @Column(name = "MINPAYMENT")
    private Float minPayment;

    @Column(name = " LASTSTMTBALANCE")
    private Float lastStmtBal;

    @Column(name = "MERCHANTCATEGORYCODE")
    private String merchantCategoryCode;

    @Column(name = "DT_UPD")
    private Date dtUpd;

    @Column(name = "UPD_BY")
    private String updatedBy;

    @Column(name = "DT_CREATED")
    private Date dtCreated;

    @Column(name = "CREATED_BY")
    private String createdBy;
}
