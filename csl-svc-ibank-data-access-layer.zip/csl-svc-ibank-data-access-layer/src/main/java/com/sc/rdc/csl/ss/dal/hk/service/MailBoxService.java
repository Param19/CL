package com.sc.rdc.csl.ss.dal.hk.service;

import com.sc.csl.retail.core.log.LogTimeTaken;
import com.sc.rdc.csl.ss.common.dto.SsBaseDto;
import com.sc.rdc.csl.ss.common.dto.SsCSLUser;
import com.sc.rdc.csl.ss.common.dto.mail.MailServiceEntityDto;
import com.sc.rdc.csl.ss.common.helper.CommonHelper;
import com.sc.rdc.csl.ss.common.helper.MailConstant;
import com.sc.rdc.csl.ss.common.service.MailService;
import com.sc.rdc.csl.ss.dal.hk.dao.CustDetailDao;
import com.sc.rdc.csl.ss.dal.hk.dao.MailServiceDao;
import com.sc.rdc.csl.ss.dal.hk.entity.mail.MailServiceEntity;
import com.webmethods.jms.log.Log;
import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

@Slf4j
@Service(value = "mailBoxServiceHK")
public class MailBoxService extends MailService {

    @Qualifier("mailServiceDaoHk")
    @Autowired
    private MailServiceDao mailServiceDao;

    @Qualifier("dozerBeanMapperHk")
    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    @Qualifier("custDetailDaoHk")
    @Autowired
    private CustDetailDao cardCustDao;



    @Transactional("transactionManagerHk")
    @Override
    @LogTimeTaken
    public SsBaseDto submitMailData(MailServiceEntityDto mailServiceEntityDto, SsCSLUser user) {

        Integer mailId = mailServiceDao.getNextSequence();
        String messageSenderId = cardCustDao.getCustomerEBID(user.getCustomerId());

        Log.info("messageSenderId:"+messageSenderId);
        MailServiceEntity mailServiceEntityVO = dozerBeanMapper.map(mailServiceEntityDto, MailServiceEntity.class);

        if(messageSenderId !=null) {
            mailServiceEntityVO.setMessageReceiverId(messageSenderId);
            mailServiceEntityVO.setMessageSenderId("");
        }

        mailServiceEntityVO.setMessageBody(CommonHelper.decodeBase64Value(mailServiceEntityVO.getMessageBody()));
        mailServiceEntityVO.setMessageSubject(CommonHelper.decodeBase64Value(mailServiceEntityVO.getMessageSubject()));
        mailServiceEntityVO.setMessageId(mailId.longValue());
        mailServiceEntityVO.setMessageMasterId(mailId.longValue());
        mailServiceEntityVO.setuUid(String.valueOf(mailId));

        Date currentDateTime = new Date();

        mailServiceEntityVO.setMessageStatusDate(currentDateTime);
        mailServiceEntityVO.setDateCreated(currentDateTime);
        mailServiceEntityVO.setDateRepliedByBO(currentDateTime);
        mailServiceEntityVO.setDateDeletedByBO(currentDateTime);
        mailServiceEntityVO.setMessageStatusDateByBO(currentDateTime);


        mailServiceEntityVO.setMessageReceiverAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_GENERAL);
        if (StringUtils.isBlank(mailServiceEntityVO.getMessageReceiverAddressType())) {
            mailServiceEntityVO.setMessageReceiverAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_ACCOUNTS);
        }

        mailServiceEntityVO.setIsDeletedByCustomer(Boolean.FALSE);
        mailServiceEntityVO.setIsRepliedByBO(Boolean.FALSE);
        mailServiceEntityVO.setIsDeletedByBO(Boolean.FALSE);

        mailServiceEntityVO.setMessageSenderAddressType(MailConstant.CONTACT_MAIL_ADDRESS_TYPE_STANDARD_CHARTERED_BANK);
        mailServiceEntityVO.setMessageStatusByBO(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        mailServiceEntityVO.setMessageStatus(MailConstant.CONTACT_MAIL_STATUS_UNREAD);
        if(messageSenderId !=null) {
            mailServiceDao.insertMailData(mailServiceEntityVO);
        }
        else {
            mailServiceEntityDto.setStatusDescription(MailConstant.EBID_ERROR);
            mailServiceEntityDto.setStatusCode(MailConstant.EBID_ERROR_CODE);
            Log.info("MessageSenderId Empty Not Populated Mail Inbox"+ messageSenderId);
        }
        mailServiceEntityDto.setStatusDescription(MailConstant.STATUS);
        mailServiceEntityDto.setStatusCode(MailConstant.STATUS_CODE);
        return mailServiceEntityDto;

    }
}
